"""Scoped paid calls, durable reservations, exact cache bindings, no implicit approval."""
import argparse
import http.client
import os
import re
import ssl
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor,as_completed
from common import *
from freeze_inputs import SCOPE,verify_inputs

ENDPOINT='api.deepseek.com'
_LOCK=threading.RLock()

def append(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(value,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def validate_authorization(auth):
    if auth.get('authorized') is not True or auth.get('scope')!=SCOPE or auth.get('model')!='deepseek-flash' or type(auth.get('hard_cap_usd')) not in [float,int] or not 0<auth['hard_cap_usd']<=2 or not auth.get('human_authorization_reference'):
        raise ValueError('current scoped human approval required before credential access')
    return True

class Ledger:
    def __init__(self,folder,cap):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True);self.path=self.folder/'ledger.jsonl';self.cap=cap
    def state(self):
        reservations={};settled={}
        for r in rows(self.path) if self.path.exists() else []:
            if r['cap']!=self.cap:raise ValueError('budget cap changed')
            if r['event']=='reserve':
                if r['reservation_id'] in reservations:raise ValueError('duplicate reservation')
                reservations[r['reservation_id']]=r
            else:
                if r['reservation_id'] not in reservations or r['reservation_id'] in settled:raise ValueError('invalid settlement')
                settled[r['reservation_id']]=r['booked_usd']
        return reservations,settled
    def booked(self):
        rs,ss=self.state();return sum(ss.get(i,r['amount']) for i,r in rs.items())
    def reserve(self,phase,pid,amount):
        with _LOCK:
            if not 0<amount or self.booked()+amount>self.cap+1e-12:raise ValueError('budget cap reached; no request sent')
            rid=uuid.uuid4().hex;append(self.path,dict(event='reserve',reservation_id=rid,phase=phase,pair_id=pid,amount=amount,cap=self.cap,utc=utc()));return rid
    def settle(self,rid,cost):
        with _LOCK:
            rs,ss=self.state()
            if rid not in rs or rid in ss:raise ValueError('absent or settled reservation')
            charge=rs[rid]['amount'] if cost is None else cost
            if type(charge) not in [float,int] or charge<0:raise ValueError('invalid charge')
            append(self.path,dict(event='settle',reservation_id=rid,booked_usd=charge,cap=self.cap,unknown_cost=cost is None,utc=utc()))
            if charge>rs[rid]['amount']+1e-12:raise ValueError('observed usage exceeds reservation; stop')

def body(system,data,maximum=512):
    return dict(model='deepseek-flash',thinking={'type':'disabled'},temperature=0,max_tokens=maximum,
        response_format={'type':'json_object'},stream=False,messages=[dict(role='system',content=system),dict(role='user',content=json.dumps(data,ensure_ascii=False))])

def rerank_job(packet,rules):
    data={k:packet[k] for k in ['pair_id','query_text','unit_text']}
    return dict(pair_id=packet['pair_id'],kind='rerank',packet=packet,body=body(rules+'\n只评此一对，输出一个JSON对象。reason和limitation各不超过40字。',data))

def validate_job(job):
    b=job['body']
    if b.get('model')!='deepseek-flash' or b.get('thinking')!={'type':'disabled'} or b.get('stream') is not False or b.get('temperature')!=0 or type(b.get('max_tokens')) is not int or not 1<=b['max_tokens']<=1024:raise ValueError('request configuration outside scope')
    text='\n'.join(m['content'] for m in b['messages'])
    if re.search(r'"(?:expected_state|required_labels|variant_expected_type|target_mechanism|reference_grade|qrels)"\s*:',text):raise ValueError('reference field leaked into inference')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',job['pair_id']):raise ValueError('unsafe task ID')
    return True

RANGES={'specific_direct':(80,100),'concise_direct':(60,79),'partial':(20,59),'topic_only':(1,19),'none':(0,0),'insufficient':(0,0)}

def validate_result(job,value):
    if not isinstance(value,dict) or value.get('pair_id')!=job['pair_id'] or value.get('human_approved') is not False:raise ValueError('result identity/review mismatch')
    if not isinstance(value.get('reason'),str) or not value['reason'].strip():raise ValueError('missing reason')
    if job['kind']=='rerank':
        score=value.get('score');level=value.get('level');quote=value.get('source_quote')
        if quote is None and value.get('quotation_valid') is False:quote=value.get('invalid_model_quote')
        if type(score) is not int or level not in RANGES or not RANGES[level][0]<=score<=RANGES[level][1]:raise ValueError('score/level mismatch')
        if not isinstance(quote,str) or not isinstance(value.get('limitation'),str) or not value['limitation'].strip():raise ValueError('missing quote/limitation')
        if (quote and quote not in job['packet']['unit_text']) or (score>=60 and not quote):
            return {**value,'source_quote':None,'invalid_model_quote':quote,'quotation_valid':False,'evidence_support_validated':False}
        return {**value,'quotation_valid':True}
    if job['kind']=='judgment':
        if value.get('state') not in ['risk','no_clear_risk','insufficient_info']:raise ValueError('invalid state')
        p=job['packet'];preds=value.get('predicates');mids=value.get('mechanism_ids')
        if not isinstance(preds,dict) or set(preds)!=set(p['predicate_ids']):raise ValueError('missing/unknown predicates')
        for pid,item in preds.items():
            if item.get('status') not in ['met','not_met','unknown']:raise ValueError('invalid predicate state')
            quote=item.get('quote')
            if not isinstance(quote,str) or (quote and quote not in p['current_text']):raise ValueError('current fact quotation mismatch')
            if item['status']=='met' and not quote:raise ValueError('positive predicate lacks current quote')
        if not isinstance(mids,list) or len(set(mids))!=len(mids) or not set(mids)<=set(p['mechanism_ids']):raise ValueError('invalid mechanisms')
        for mid in mids:
            if any(preds[pid]['status']!='met' for pid in p['required_by_mechanism'][mid]):raise ValueError('risk mechanism missing required current facts')
        if (value['state']=='risk')!=bool(mids):raise ValueError('state/mechanism inconsistency')
        for field,allowed in [('case_unit_ids',p['case_unit_ids']),('legal_article_ids',p['article_ids'])]:
            if not isinstance(value.get(field),list) or not set(value[field])<=set(allowed):raise ValueError('unregistered citation')
        if not isinstance(value.get('limitations'),list):raise ValueError('missing limitations')
        return value
    if job['kind']=='relevance':
        grade=value.get('grade');ids=value.get('evidence_span_ids');allowed=job['packet']['span_ids']
        if type(grade) is not int or grade not in range(4) or not isinstance(ids,list) or not set(ids)<=set(allowed) or (grade>=2 and not ids):raise ValueError('invalid relevance/source span')
        return value
    raise ValueError('unknown job kind')

def redact(text,key=''):
    if key:text=str(text).replace(key,'[REDACTED]')
    return re.sub(r'sk-[A-Za-z0-9_-]{16,}','[REDACTED]',str(text))

LOCAL=threading.local()
def request(payload,key):
    conn=getattr(LOCAL,'connection',None);sent=False;status=None;raw=None
    try:
        if conn is None or conn.sock is None:
            conn=http.client.HTTPSConnection(ENDPOINT,timeout=20,context=ssl.create_default_context())
            conn.connect();conn.sock.settimeout(90);LOCAL.connection=conn
        sent=True
        conn.request('POST','/chat/completions',body=payload,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        response=conn.getresponse();status=response.status;raw=redact(response.read().decode('utf-8'),key)
        if response.will_close or status!=200:conn.close();LOCAL.connection=None
        return dict(http_status=status,raw_response_text=raw,response=json.loads(raw) if status==200 else None,error=None if status==200 else 'HTTP '+str(status),no_HTTP_body_sent=False)
    except Exception as exc:
        if conn is not None:conn.close()
        LOCAL.connection=None
        return dict(http_status=status,raw_response_text=raw,response=None,error=redact(type(exc).__name__+': '+str(exc),key),no_HTTP_body_sent=not sent)

def usage_bound(usage):
    n,o=usage.get('prompt_tokens'),usage.get('completion_tokens');hit=usage.get('prompt_cache_hit_tokens',usage.get('prompt_tokens_details',{}).get('cached_tokens',0))
    if type(n) is not int or type(o) is not int or type(hit) is not int or not 0<=hit<=n or o<0:raise ValueError('invalid usage')
    return ((n-hit)*.3+hit*.006+o*1.2)/1e6

def audit_scope_jobs(jobs,records,auth,*,allow_uncertain_retry=False):
    """Paid identity and attempts belong to the whole authorization, never a phase."""
    limits=auth['max_unique_tasks'];identities={k:set() for k in limits};attempts={};cache={};uncertain=set()
    for r in records:
        key=(r['pair_id'],r['base_payload_sha256']);kind=r['kind']
        if kind not in limits:raise ValueError('unapproved task kind')
        identities[kind].add(key);attempts[key]=attempts.get(key,0)+1
        if r['status']=='unknown':uncertain.add(key)
        if r['status']=='accepted':
            if key in cache:raise ValueError('duplicate paid accepted identity')
            cache[key]=r
    for j in jobs:
        key=(j['pair_id'],canonical_sha(j['body']));kind=j['kind']
        if kind not in limits:raise ValueError('unapproved task kind')
        identities[kind].add(key)
        if key in uncertain and key not in cache and not allow_uncertain_retry:raise ValueError('cross-phase uncertain dispatch; no automatic repeat')
        if key not in cache and attempts.get(key,0)>=auth['max_attempts_per_job']:raise ValueError('global attempts exhausted; changing phase cannot reset')
    for kind,ids in identities.items():
        if len(ids)>limits[kind]:raise ValueError('authorized unique '+kind+' task cap exceeded')
    return cache,attempts

def prepare(experiment='K',split='development'):
    folder=OUT/('experiment_'+experiment);groups=read(OUT/'evaluation/group_split.json')
    verify_inputs(read(folder/'retrieval_freeze.json')['sha256'])
    if experiment=='R':
        if split!='development':raise ValueError('R requires a new holdout; do not reuse K holdout')
        verify_inputs(read(folder/'context_cache_binding.json')['sha256'])
    mapping={r['pair_id']:r for r in rows(folder/'candidate_map.jsonl')}
    rules=(folder/'rerank_rules.md').read_text(encoding='utf-8')
    jobs=[rerank_job(p,rules) for p in rows(folder/'rerank_inputs.jsonl') if groups[mapping[p['pair_id']]['query_id']]['split']==split]
    for j in jobs:validate_job(j)
    phase=f'{experiment}_{split}_rerank';save(OUT/'api_jobs'/f'{phase}.jsonl',jobs,True)
    save(OUT/'api_jobs'/f'{phase}_freeze.json',dict(sha256={str(OUT/'api_jobs'/f'{phase}.jsonl'):sha(OUT/'api_jobs'/f'{phase}.jsonl')},tasks=len(jobs)))
    print(json.dumps(dict(phase=phase,tasks=len(jobs),new_requests=0)))

def run(phase,*,resume_uncertain=False):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,60}',phase):raise ValueError('unsafe phase')
    auth=read(OUT/'authorization.json');validate_authorization(auth)
    plan_path=OUT/'contracts/api_request_plan.json'
    if sha(plan_path)!=auth.get('request_plan_sha256'):raise ValueError('authorized request plan changed')
    proposed=read(plan_path)
    approved_limits=dict(rerank=proposed['total_max']['rerank_scores'],judgment=proposed['total_max']['judgments'],relevance=proposed['total_max']['relevance_pairs'])
    if auth.get('max_unique_tasks')!=approved_limits or auth.get('max_attempts_per_job')!=3:raise ValueError('authorized limits mismatch')
    if resume_uncertain:
        policy=read(OUT/'contracts/transport_resume_policy.json')
        if policy.get('scope')!=SCOPE or policy.get('max_total_attempts')!=3 or policy.get('retain_every_unknown_reservation') is not True or policy.get('authorization_sha256')!=sha(OUT/'authorization.json'):
            raise ValueError('explicit bounded transport-resume policy required')
    verify_inputs(read(OUT/'evaluation/query_freeze.json')['sha256']);verify_inputs(read(OUT/'api_jobs'/f'{phase}_freeze.json')['sha256'])
    jobs=list(rows(OUT/'api_jobs'/f'{phase}.jsonl'))
    if len({j['pair_id'] for j in jobs})!=len(jobs):raise ValueError('duplicate jobs')
    for j in jobs:validate_job(j)
    if not re.fullmatch(r'[KR]_(development|holdout)_(rerank|judgment|relevance)',phase):raise ValueError('unregistered phase')
    query_split={q['text']:read(OUT/'evaluation/group_split.json')[q['query_id']]['split'] for q in rows(OUT/'evaluation/queries.jsonl')}
    for j in jobs:
        data=json.loads(j['body']['messages'][1]['content']);text=data.get('query_text',data.get('current_text'))
        if text not in query_split or query_split[text] not in phase:raise ValueError('query/split not in frozen inference scope')
        if query_split[text]=='holdout':
            from experiment_k import check_stage
            check_stage('holdout')
    folder=OUT/'api'/phase;folder.mkdir(parents=True,exist_ok=True)
    runner_sha=sha(Path(__file__));runner_source=OUT/'api/runner_sources'/(runner_sha+'.py')
    runner_source.parent.mkdir(parents=True,exist_ok=True)
    if not runner_source.exists():
        with runner_source.open('xb') as f:f.write(Path(__file__).read_bytes())
    # A single OS process owns all shared-ledger phases; never parallelize phases.
    runlock=OUT/'api/run.lock';runlock.parent.mkdir(parents=True,exist_ok=True)
    handle=runlock.open('a+b');handle.seek(0,os.SEEK_END)
    if handle.tell()==0:handle.write(b'0');handle.flush()
    import msvcrt
    handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
    try:
        ledger=Ledger(OUT/'api/budget',auth['hard_cap_usd']);rs,ss=ledger.state()
        if set(rs)-set(ss):raise ValueError('unsettled prior dispatch; inspect before continuation')
        all_records=[]
        for path in (OUT/'api').glob('*/records.jsonl'):
            all_records.extend(rows(path))
        cache,attempts=audit_scope_jobs(jobs,all_records,auth,allow_uncertain_retry=resume_uncertain)
        accepted={};remaining=[]
        for j in jobs:
            digest=canonical_sha(j['body']);cached=cache.get((j['pair_id'],digest))
            if cached:
                accepted[j['pair_id']]=dict(cached,reused=True);validate_result(j,cached['parsed'])
            else:remaining.append(j)
        # All approval/freeze/cache/scope checks precede key access. Never record key path contents.
        matches=set(re.findall(r'sk-[A-Za-z0-9_-]{16,}',Path('C:/Users/11051/Desktop/deepseek.txt').read_text(encoding='utf-8-sig')))
        if len(matches)!=1:raise ValueError('credential file must contain exactly one recognizable key')
        key=next(iter(matches));matches=None;stop=threading.Event();prior_attempts={j['pair_id']:attempts.get((j['pair_id'],canonical_sha(j['body'])),0) for j in jobs}
        def work(j):
            pid=j['pair_id'];feedback=None
            for attempt in range(prior_attempts[pid]+1,4):
                if stop.is_set():return
                b=copy_body(j['body'],feedback);payload=json.dumps(b,ensure_ascii=False,allow_nan=False).encode('utf-8')
                reserve=((len(payload)+1024)*.3+b['max_tokens']*1.2)/1e6
                rid=ledger.reserve(phase,pid,reserve);started=time.perf_counter();obs=request(payload,key)
                response=obs['response'];parsed=None;error=obs['error'];cost=None;fatal=False
                if response is not None:
                    try:
                        if response.get('model') not in ['deepseek-flash','deepseek-v4.1-flash']:fatal=True;raise ValueError('unexpected response model')
                        cost=usage_bound(response['usage'])
                        if len(response['choices'])!=1 or response['choices'][0]['finish_reason']!='stop':raise ValueError('incomplete completion')
                        parsed=validate_result(j,json.loads(response['choices'][0]['message']['content']))
                    except (ValueError,KeyError,TypeError) as exc:error=str(exc)
                if obs['no_HTTP_body_sent']:cost=0
                uncertain=obs['http_status'] is None and not obs['no_HTTP_body_sent']
                record=dict(pair_id=pid,kind=j['kind'],phase=phase,attempt=attempt,reservation_id=rid,
                    runner_source_sha256=runner_sha,
                    base_payload_sha256=canonical_sha(j['body']),payload_sha256=textsha(payload.decode('utf-8')),
                    status='unknown' if uncertain else 'accepted' if parsed is not None else 'rejected',
                    parsed=parsed,booked_peak_bound_usd=cost,reserved_usd=reserve,error=redact(error,key),
                    seconds=time.perf_counter()-started,utc=utc(),**{k:v for k,v in obs.items() if k!='error'})
                with _LOCK:append(folder/'records.jsonl',record)
                ledger.settle(rid,cost)
                if parsed is not None:
                    with _LOCK:
                        accepted[pid]=record
                        if len(accepted)%25==0 or len(accepted)==len(jobs):print(json.dumps(dict(phase=phase,accepted=len(accepted),total=len(jobs),booked_peak_bound_usd=ledger.booked())),flush=True)
                    return
                if uncertain or fatal or obs['http_status'] in [400,401,402,403]:stop.set();raise ValueError('fatal or uncertain response retained; stop')
                feedback=None if obs['no_HTTP_body_sent'] else '仅修正JSON结构或原句：'+str(error)+'。判断标准保持相同，不提供参考答案。'
                if attempt<3:stop.wait(1)
        try:
            with ThreadPoolExecutor(max_workers=12) as pool:
                futures=[pool.submit(work,j) for j in remaining]
                for f in as_completed(futures):
                    try:f.result()
                    except Exception:stop.set();raise
        finally:key=None
        destination=folder/'accepted.jsonl'
        final=[accepted[j['pair_id']] for j in jobs if j['pair_id'] in accepted]
        if not destination.exists():save(destination,final,True)
        elif list(rows(destination))!=final:raise ValueError('accepted cache file differs')
        marker=dict(complete=len(final)==len(jobs),accepted=len(final),tasks=len(jobs),reused=sum(r.get('reused',False) for r in final),
            accepted_sha256=sha(destination),jobs_sha256=sha(OUT/'api_jobs'/f'{phase}.jsonl'),
            missing=[j['pair_id'] for j in jobs if j['pair_id'] not in accepted],booked_peak_bound_usd=ledger.booked(),actual_bill_not_confirmed=True)
        if not (folder/'completion.json').exists():save(folder/'completion.json',marker)
        print(json.dumps(marker),flush=True)
    finally:
        handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1);handle.close()

def copy_body(b,feedback):
    if not feedback:return b
    return {**b,'messages':b['messages']+[dict(role='user',content=feedback)]}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','run']);p.add_argument('--experiment',default='K',choices=['K','R']);p.add_argument('--split',default='development',choices=['development','holdout']);p.add_argument('--phase');p.add_argument('--resume-uncertain',action='store_true')
    a=p.parse_args();prepare(a.experiment,a.split) if a.action=='prepare' else run(a.phase,resume_uncertain=a.resume_uncertain)
