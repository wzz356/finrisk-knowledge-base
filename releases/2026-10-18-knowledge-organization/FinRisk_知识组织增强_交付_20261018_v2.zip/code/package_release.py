"""Create a new complete evidence release and actually verify its extracted copy."""
import re
import shutil
import subprocess
import sys
import zipfile
from common import *

def check_file_policy(folder):
    """Only reviewed artifact formats; reject credential containers and links."""
    allowed={'.txt','.json','.jsonl','.md','.py','.npy','.lock'}
    protected={'.git','.aws','.ssh','.codex','.env','credentials','credentials.json','deepseek.txt','secrets.json'}
    for p in Path(folder).rglob('*'):
        if p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400:raise ValueError('links/reparse points are not release payloads: '+str(p))
        if any(part.lower() in protected or part.lower().startswith('.env.') for part in p.relative_to(folder).parts):raise ValueError('protected path in release: '+str(p))
        if not p.is_file():continue
        if p.relative_to(folder).as_posix()=='api/run.lock':continue  # Runtime lock is omitted from the release.
        if p.suffix.lower() not in allowed:raise ValueError('unreviewed release file format: '+str(p))
        data=p.read_bytes()
        if p.suffix.lower()=='.lock' and data:raise ValueError('nonempty runtime lock is not a payload')
        if p.suffix.lower()=='.npy':
            if not data.startswith(b'\x93NUMPY'):raise ValueError('invalid vector artifact')
        else:
            data.decode('utf-8-sig')
            if re.search(rb'(?<![A-Za-z0-9_-])sk-[A-Za-z0-9_-]{20,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data):raise ValueError('possible secret in delivery: '+str(p))
    return True

def package(source=OUT,*,release_tag='v1'):
    source=Path(source).resolve()
    if source!=OUT.resolve() or not source.is_relative_to((ROOT/'outputs').resolve()):raise ValueError('packaging requires original isolated output')
    if release_tag not in ['v1','v2']:raise ValueError('unknown isolated release tag')
    target=ROOT/('outputs/FinRisk_知识组织增强_交付_20261018'+('' if release_tag=='v1' else '_v2'))
    archive=target.with_suffix('.zip');extracted=WORK/('package_extract_'+release_tag)
    for path,parent in [(target,ROOT/'outputs'),(archive,ROOT/'outputs'),(extracted,WORK)]:
        if not path.resolve().is_relative_to(parent.resolve()) or path.exists():raise ValueError('new in-workspace output required: '+str(path))
    from freeze_inputs import verify_inputs
    verify_inputs(read(source/'contracts/input_freeze.json')['sha256'])
    from verify_release import verify
    verify(source,require_manifest=False)
    check_file_policy(source)
    shutil.copytree(source,target,ignore=shutil.ignore_patterns('*.lock'))
    code=target/'code';code.mkdir()
    for p in sorted(WORK.glob('*.py')):shutil.copyfile(p,code/p.name)
    shutil.copytree(WORK/'tests',code/'tests',ignore=shutil.ignore_patterns('__pycache__'))
    review=target/'review';review.mkdir()
    for folder in ['code_review','query_review','expansion_review']:
        src=WORK/folder
        shutil.copytree(src,review/folder,ignore=shutil.ignore_patterns('__pycache__'))
    for name in ['final_acceptance.json','source_review_report.md']:
        src=WORK/'source_analysis'/name
        if src.exists():shutil.copyfile(src,review/('pilot_'+name))
    for p in sorted((WORK/'maintenance_final_task').glob('*.txt')):
        shutil.copyfile(p,review/('maintenance_'+p.name))
    for p in ['task_plan.md','findings.md','progress.md']:
        shutil.copyfile(WORK/p,target/'reports'/('execution_'+p))
    plan=ROOT/'docs/superpowers/plans/2026-10-18-finrisk-knowledge-organization-plan.md'
    shutil.copyfile(plan,target/'reports/approved_plan.md')
    check_file_policy(target)
    files=[]
    for p in sorted(target.rglob('*')):
        if not p.is_file():continue
        files.append(dict(path=p.relative_to(target).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
    save(target/'manifest.json',dict(schema='finrisk-organization-release-v1',utc=utc(),files=files,
        identity='optional knowledge reading layer plus complete closed-experiment evidence',models_included=False,credential_included=False,
        full_corpus_serving_index_included=False,production_activated=False,human_approved=False))
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(target).as_posix())
    extracted.mkdir()
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            if not (extracted/name).resolve().is_relative_to(extracted.resolve()):raise ValueError('unsafe ZIP entry')
        z.extractall(extracted)
    run=subprocess.run([sys.executable,'-S','-X','utf8','-B',str(extracted/'code/verify_release.py'),'--root',str(extracted)],cwd=extracted,capture_output=True,text=True,encoding='utf-8')
    if run.returncode:raise RuntimeError('extracted verification failed:\n'+run.stdout+run.stderr)
    receipt=dict(passed=True,archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),manifest_sha256=sha(target/'manifest.json'),
        actual_extracted_verification=json.loads(run.stdout),extraction_dir=str(extracted),new_API_calls=0)
    save(archive.with_suffix('.verification.json'),receipt)
    verify_inputs(read(source/'contracts/input_freeze.json')['sha256'])
    return receipt

if __name__=='__main__':print(json.dumps(package(),ensure_ascii=False,indent=2))
