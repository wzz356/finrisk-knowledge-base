"""Descriptive Success@K, mechanism errors and per-arm usage; no new evaluation."""
from collections import Counter
import statistics
from common import *

def calculate(root):
    root=Path(root);success={};errors={};costs={}
    for split in ['development','holdout']:
        ret=list(rows(root/'experiment_K/retrieval_per_query.jsonl'))
        success['K_'+split]={str(k):dict(queries=len(part),successes=sum(r['MRR']>0 for r in part),Success=sum(r['MRR']>0 for r in part)/len(part)) for k in [1,5,10,20] if (part:=[r for r in ret if r['split']==split and r['K']==k])}
        decisions=[r for r in rows(root/'experiment_K/per_query_results.jsonl') if r['split']==split]
        binding={r['pair_id']:r['arm'] for r in rows(root/'experiment_K'/f'judgment_map_{split}.jsonl')}
        records=list(rows(root/'api'/f'K_{split}_judgment/records.jsonl'))
        for arm in ['K0','K1']:
            part=[r for r in decisions if r['arm']==arm];valid=[r for r in part if r['accepted']]
            missed=[sorted(set(r['expected_mechanisms'])-set(r['predicted_mechanisms'])) for r in valid]
            extra=[sorted(set(r['predicted_mechanisms'])-set(r['expected_mechanisms'])) for r in valid]
            errors[split+'_'+arm]=dict(frozen_queries=len(part),accepted=len(valid),format_failures=len(part)-len(valid),
                valid_decisions_with_omissions=sum(bool(x) for x in missed),valid_decisions_with_extra_mechanisms=sum(bool(x) for x in extra),
                omitted_mechanisms=dict(Counter(m for one in missed for m in one)),extra_mechanisms=dict(Counter(m for one in extra for m in one)),
                per_query=[dict(query_id=r['query_id'],omitted=m,extra=e) for r,m,e in zip(valid,missed,extra)])
            attempts=[r for r in records if binding[r['pair_id']]==arm];usage=Counter()
            for r in attempts:
                for k,v in (r.get('response') or {}).get('usage',{}).items():
                    if k in ['prompt_tokens','completion_tokens','prompt_cache_hit_tokens','prompt_cache_miss_tokens']:usage[k]+=v
            costs[split+'_'+arm]=dict(attempts=len(attempts),accepted=sum(r['status']=='accepted' for r in attempts),
                rejected=sum(r['status']=='rejected' for r in attempts),unknown=sum(r['status']=='unknown' for r in attempts),
                known_usage_tokens=dict(usage),attempt_seconds_sum=sum(r['seconds'] for r in attempts),
                median_attempt_seconds=statistics.median(r['seconds'] for r in attempts),
                mean_case_chars=statistics.mean(r['case_chars'] for r in part),mean_knowledge_chars=statistics.mean(r['knowledge_chars'] for r in part))
    ret=list(rows(root/'experiment_R_controlled/per_query_metrics.jsonl'))
    for arm in ['R0','R1']:
        success[arm]={str(k):dict(queries=len(part),successes=sum(r['MRR']>0 for r in part),Success=sum(r['MRR']>0 for r in part)/len(part)) for k in [1,5,10,20] if (part:=[r for r in ret if r['arm']==arm and r['K']==k])}
    return dict(schema='finrisk-additional-descriptive-metrics-v1',Success_at_K=success,mechanism_errors=errors,judgment_usage_by_arm=costs,
        Success_definition='At least one grade-3 directly supporting document in TopK',
        K_retrieval_identical_between_arms=True,full_corpus_true_recall=False,reference='same frozen model-silver qrels',
        timing_limits='Per-HTTP attempt includes retries; parallel seconds sum is not wall-clock or full Agent latency. Retrieval/encoding time is in retrieval receipts.',
        no_new_queries_or_calls=True,human_approved=False)

if __name__=='__main__':
    result=calculate(OUT);save(OUT/'reports/additional_descriptive_metrics.json',result)
    print(json.dumps(result['Success_at_K'],ensure_ascii=False))
