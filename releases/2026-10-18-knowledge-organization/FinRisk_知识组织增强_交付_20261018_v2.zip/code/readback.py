"""Verify exact legacy readings and all new registered evidence offline."""
from common import *
from base_reader import KnowledgeReader
from knowledge_facade import KnowledgeFacade

def main():
    lock=read(OUT/'case_reader/pilot_lock.json')
    facade=KnowledgeFacade(OUT,lock,expected_knowledge_manifest_sha256=read(OUT/'contracts/knowledge_lock.json')['manifest_sha256'])
    oldlock=read(P0OLD/'reader/consumer_lock.json')
    old=KnowledgeReader(P0OLD/'reader/bundle',expected_versions=oldlock['versions'],expected_manifest_sha256=oldlock['manifest_sha256'])
    reference=[];spans=0
    for r in rows(P0OLD/'reference/rankings.jsonl'):
        for rank,h in enumerate(r['ranking'][:20],1):
            before=old.read(h['unit_id']);after=facade.read_case(h['unit_id'])
            if before!=after:raise ValueError('unexpected legacy reading change')
            for s in after['segments']:
                if facade.cases.read_span(s['span_id'])!=s:raise ValueError('registered span mismatch')
                spans+=1
            reference.append(dict(query_id=r['query_id'],arm=r['arm'],rank=rank,unit_id=h['unit_id'],file_id=h['file_id'],expected_read_sha256=canonical_sha(before)))
    for aid in facade.legal.articles:facade.read_article(aid)
    for mid in facade.cards:facade.read_mechanism(mid,level='L2')
    if len(reference)!=960:raise ValueError('old replay positions mismatch')
    save(OUT/'regression/legacy_readings.jsonl',reference,True)
    receipt=dict(passed=True,legacy_positions=960,legacy_spans=spans,case_units=len(facade.cases.units),case_documents=len(facade.cases.sources),
        new_source_spans=len(facade.spans),mechanisms=len(facade.cards),legal_articles=len(facade.legal.articles),
        API_calls=0,human_approved=False,live_Agent_runtime_verified=False)
    save(OUT/'reports/readback_pilot.json',receipt);print(json.dumps(receipt))

if __name__=='__main__':main()
