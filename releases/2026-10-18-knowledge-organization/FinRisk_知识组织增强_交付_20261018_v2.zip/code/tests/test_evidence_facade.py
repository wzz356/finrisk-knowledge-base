import importlib
import importlib.util
from pathlib import Path
import sys
import unittest
import shutil
import tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import OUT,read

class FacadeTests(unittest.TestCase):
    def reader(self):
        self.assertIsNotNone(importlib.util.find_spec('knowledge_facade'),'facade not implemented')
        return importlib.import_module('knowledge_facade').KnowledgeFacade(OUT,read(OUT/'case_reader/pilot_lock.json'),expected_knowledge_manifest_sha256=read(OUT/'contracts/knowledge_lock.json')['manifest_sha256'])

    def test_new_knowledge_payload_requires_pin_and_detects_tampering(self):
        m=importlib.import_module('knowledge_facade')
        lock=read(OUT/'case_reader/pilot_lock.json')
        with self.assertRaises(ValueError):m.KnowledgeFacade(OUT,lock)
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            target=Path(tmp)
            for folder in ['knowledge','navigation','contracts']:shutil.copytree(OUT/folder,target/folder)
            with (target/'knowledge/mechanisms.jsonl').open('a',encoding='utf-8') as f:f.write('\n')
            with self.assertRaises(ValueError):m.KnowledgeFacade(target,lock,expected_knowledge_manifest_sha256=read(OUT/'contracts/knowledge_lock.json')['manifest_sha256'])

    def test_enhancement_cannot_be_combined_with_different_base_versions(self):
        m=importlib.import_module('knowledge_facade');lock=read(OUT/'case_reader/pilot_lock.json')
        lock['versions']['content']='different-content'
        with self.assertRaisesRegex(ValueError,'enhancement.*base version'):
            m.KnowledgeFacade(OUT,lock,expected_knowledge_manifest_sha256=read(OUT/'contracts/knowledge_lock.json')['manifest_sha256'])

    def test_source_only_spans_are_readable_without_fabricating_units(self):
        f=self.reader();allspans=f.read_mechanism('M11',level='L2')['case_evidence']
        self.assertTrue(all(s['current_business_fact_proof'] is False for s in allspans))
        unbound=next(l for l in f.links if l['unit_id'] is None)
        evidence=f.read_mechanism(unbound['mechanism_id'],level='L2')['case_evidence']
        self.assertIn(unbound['span_id'],[s['span_id'] for s in evidence])

    def test_bundle_respects_budgets_and_marks_omissions_partial(self):
        f=self.reader();uids=list(f.cases.units)[:2]
        b=f.get_evidence_bundle(['M11','M01','M02','M04'],uids,case_budget=20,law_budget=100)
        self.assertLessEqual(len(b['case_text']),20);self.assertLessEqual(len(b['law_and_guide_text']),100)
        self.assertEqual(b['coverage']['status'],'partial');self.assertTrue(b['coverage']['omitted_case_unit_ids'])
        self.assertFalse(b['current_input_facts_assessed'])
        self.assertTrue(all(p['status']=='not_assessed' for p in b['facts_to_check']))

    def test_bundle_does_not_add_card_cases_to_fixed_case_evidence(self):
        f=self.reader();uid=next(iter(f.cases.units))
        b=f.get_evidence_bundle(['M04'],[uid])
        self.assertEqual(b['requested_case_unit_ids'],[uid])
        self.assertEqual(b['included_case_unit_ids'],[uid])
        self.assertNotIn('KOSPAN-',b['case_text'])

    def test_unknown_ids_bool_budget_and_invalid_level_refused(self):
        f=self.reader()
        for fn in [lambda:f.read_mechanism('M99'),lambda:f.read_mechanism('M11',level='L9'),
                   lambda:f.get_evidence_bundle(['M11'],['UNKNOWN']),
                   lambda:f.get_evidence_bundle(['M11'],[],case_budget=True)]:
            with self.assertRaises(ValueError):fn()

    def test_roles_validity_cutoff_and_unknown_are_preserved(self):
        f=self.reader();uid=next(iter(f.cases.units));original=f.cases.read(uid)
        self.assertEqual(f.read_case(uid)['associations'],original['associations'])
        self.assertEqual(f.read_case(uid)['may_include_other_actors_or_behaviors'],original['may_include_other_actors_or_behaviors'])
        a=f.read_article('L001-A0116')
        self.assertEqual(a['sources']['L001']['axes']['current_validity']['evidence_cutoff'],'2026-08-28')
        m=f.read_mechanism('M01');m['title']='changed';self.assertNotEqual(f.read_mechanism('M01')['title'],'changed')

if __name__=='__main__':unittest.main()
