import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import sha
from verify_release import verify_payloads

class ReleaseManifestTests(unittest.TestCase):
    def fixture(self,root):
        p=root/'evidence.txt';p.write_text('已登记证据',encoding='utf-8')
        m=dict(schema='finrisk-organization-release-v1',files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p))])
        (root/'manifest.json').write_text(json.dumps(m),encoding='utf-8');return m

    def test_exact_complete_payloads(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            root=Path(tmp);self.fixture(root);self.assertEqual(verify_payloads(root),1)
            (root/'extra.txt').write_text('extra',encoding='utf-8')
            with self.assertRaises(ValueError):verify_payloads(root)

    def test_modified_missing_and_duplicate_payloads_refused(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            root=Path(tmp);m=self.fixture(root);(root/'evidence.txt').write_text('另一份',encoding='utf-8')
            with self.assertRaises(ValueError):verify_payloads(root)
            m=self.fixture(root);m['files'].append(m['files'][0]);(root/'manifest.json').write_text(json.dumps(m),encoding='utf-8')
            with self.assertRaises(ValueError):verify_payloads(root)
            self.fixture(root);(root/'evidence.txt').unlink()
            with self.assertRaises(ValueError):verify_payloads(root)

    def test_escaping_manifest_path_refused(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            root=Path(tmp);m=self.fixture(root);m['files'][0]['path']='../outside.txt'
            (root/'manifest.json').write_text(json.dumps(m),encoding='utf-8')
            with self.assertRaises(ValueError):verify_payloads(root)

if __name__=='__main__':unittest.main()
