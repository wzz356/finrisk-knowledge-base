import importlib
import importlib.util
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import sha

class FreezeTests(unittest.TestCase):
    def load(self):
        self.assertIsNotNone(importlib.util.find_spec('freeze_inputs'),'freeze input protection is not implemented')
        return importlib.import_module('freeze_inputs')

    def test_protected_input_mutation_is_detected(self):
        module=self.load()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            p=Path(directory)/'original.txt';p.write_text('original',encoding='utf-8')
            table={str(p):sha(p)};module.verify_inputs(table)
            p.write_text('changed',encoding='utf-8')
            with self.assertRaises(ValueError):module.verify_inputs(table)

    def test_no_paid_authorization_inherited(self):
        module=self.load();config={'api':{'model':'deepseek-flash','authorization_file':None}}
        self.assertFalse(module.api_authorized(config))

    def test_output_path_cannot_escape_workspace_or_overwrite_input(self):
        module=self.load();root=Path(__file__).resolve().parents[1]
        with self.assertRaises(ValueError):module.safe_output(root,'../outside',[])
        with self.assertRaises(ValueError):module.safe_output(root,'data',['data/input.json'])

if __name__=='__main__':unittest.main()
