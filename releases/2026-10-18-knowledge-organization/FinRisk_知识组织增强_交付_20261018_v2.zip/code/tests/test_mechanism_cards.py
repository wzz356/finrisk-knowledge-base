import copy
import importlib
import importlib.util
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

class CardTests(unittest.TestCase):
    def load(self):
        self.assertIsNotNone(importlib.util.find_spec('mechanism_cards'),'mechanism cards not implemented')
        return importlib.import_module('mechanism_cards')

    def card(self):
        return dict(mechanism_id='M11',identity='assistant_authored_screening_guide',human_approved=False,
            review_origin='current_session_model',label_mapping_is_automatic=False,candidate_label_links=['标签'],
            predicates=[dict(predicate_id='M11.p',description='核查谁作确认',required_for_risk=True,support_article_ids=['A'],support_kind='interpretation')],
            article_ids=['A'],supporting_case_links=[dict(file_id='F1',span_id='S1'),dict(file_id='F2',span_id='S2')],
            adjacent_case_links=[],facts_to_check=['M11.p'],coverage={'status':'complete'},cannot_infer=['不能证明当前输入事实'])

    def test_valid_card_preserves_candidate_label_identity(self):
        self.assertTrue(self.load().validate_card(self.card(),{'A'},{'标签'},{'S1','S2'}))

    def test_empty_required_set_and_automatic_label_refused(self):
        m=self.load()
        for field,value in [('predicates',[]),('label_mapping_is_automatic',True),('human_approved',True)]:
            card=self.card();card[field]=value
            with self.subTest(field=field):
                with self.assertRaises(ValueError):m.validate_card(card,{'A'},{'标签'},{'S1','S2'})

    def test_unsupported_normative_claim_or_forged_quote_link_refused(self):
        m=self.load()
        for mutation in ['norm','span','taxonomy']:
            card=self.card()
            if mutation=='norm':card['predicates'][0]['support_article_ids']=['unknown']
            if mutation=='span':card['supporting_case_links'][0]['span_id']='forged'
            if mutation=='taxonomy':card['candidate_label_links']=['新造官方标签']
            with self.subTest(mutation=mutation):
                with self.assertRaises(ValueError):m.validate_card(card,{'A'},{'标签'},{'S1','S2'})

    def test_missing_case_support_must_be_partial(self):
        card=self.card();card['supporting_case_links']=card['supporting_case_links'][:1]
        with self.assertRaises(ValueError):self.load().validate_card(card,{'A'},{'标签'},{'S1','S2'})
        card['coverage']['status']='partial'
        self.assertTrue(self.load().validate_card(card,{'A'},{'标签'},{'S1','S2'}))
    def test_contract_fact_requirement_is_not_forged_into_a_normative_article(self):
        card=self.card();p=card['predicates'][0];p['support_article_ids']=[]
        with self.assertRaises(ValueError):self.load().validate_card(card,{'A'},{'标签'},{'S1','S2'})
        p.update(support_kind='current_input_fact_requirement',evidence_basis='current_input_or_independently_verified_material',normative_claim=False)
        self.assertTrue(self.load().validate_card(card,{'A'},{'标签'},{'S1','S2'}))

if __name__=='__main__':unittest.main()
