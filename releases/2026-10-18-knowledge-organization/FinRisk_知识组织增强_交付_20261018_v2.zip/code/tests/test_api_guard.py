import importlib
import importlib.util
import tempfile
from pathlib import Path
import unittest
from common import canonical_sha
class ApiGuardTests(unittest.TestCase):
    def module(self):
        self.assertIsNotNone(importlib.util.find_spec('api_jobs'))
        return importlib.import_module('api_jobs')
    def test_old_scope_or_missing_approval_cannot_read_credentials(self):
        fn=self.module().validate_authorization
        for auth in [{},dict(authorized=True,scope='old',model='deepseek-flash',hard_cap_usd=2)]:
            with self.assertRaises(ValueError):fn(auth)
    def test_budget_reserves_unknown_and_refuses_over_cap(self):
        m=self.module()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as t:
            b=m.Ledger(Path(t),2);rid=b.reserve('X','P',1.5);b.settle(rid,None)
            self.assertEqual(b.booked(),1.5)
            with self.assertRaises(ValueError):b.reserve('X','Q',.6)
    def test_rerank_input_rejects_reference_fields(self):
        m=self.module()
        packet=dict(pair_id='P',query_text='客户话术',unit_text='公开处罚原句')
        j=m.rerank_job(packet,'输出JSON评分')
        self.assertTrue(m.validate_job(j))
        j['body']['messages'][1]['content']+='"expected_state":"risk"'
        with self.assertRaises(ValueError):m.validate_job(j)
    def test_cross_phase_unknown_and_attempt_reset_are_refused(self):
        m=self.module();j=m.rerank_job(dict(pair_id='P',query_text='话术',unit_text='原文'),'JSON')
        auth=dict(max_unique_tasks=dict(rerank=6000,judgment=84,relevance=1200),max_attempts_per_job=3)
        base=dict(pair_id='P',kind='rerank',base_payload_sha256=canonical_sha(j['body']),phase='old_phase')
        for records in [[dict(base,status='unknown')],[dict(base,status='rejected',attempt=i) for i in range(1,4)]]:
            with self.assertRaises(ValueError):m.audit_scope_jobs([j],records,auth)
    def test_unique_task_caps_are_enforced_across_phases(self):
        m=self.module();j=m.rerank_job(dict(pair_id='P',query_text='话术',unit_text='原文'),'JSON')
        auth=dict(max_unique_tasks=dict(rerank=1,judgment=84,relevance=1200),max_attempts_per_job=3)
        prior=[dict(pair_id='OLD',kind='rerank',base_payload_sha256='OTHER',status='rejected',attempt=1)]
        with self.assertRaises(ValueError):m.audit_scope_jobs([j],prior,auth)
    def test_invalid_model_quote_stays_unreturned_after_exact_cache_validation(self):
        m=self.module();j=m.rerank_job(dict(pair_id='P',query_text='话术',unit_text='原文'),'JSON')
        v=dict(pair_id='P',score=80,level='specific_direct',source_quote='未出现文字',reason='理由',limitation='限制',human_approved=False)
        saved=m.validate_result(j,v)
        self.assertIsNone(saved['source_quote']);self.assertFalse(saved['quotation_valid'])
        self.assertEqual(m.validate_result(j,saved),saved)
    def test_explicit_transport_resume_retains_global_three_attempt_limit(self):
        m=self.module();j=m.rerank_job(dict(pair_id='P',query_text='话术',unit_text='原文'),'JSON')
        auth=dict(max_unique_tasks=dict(rerank=6000,judgment=84,relevance=1200),max_attempts_per_job=3)
        r=dict(pair_id='P',kind='rerank',base_payload_sha256=canonical_sha(j['body']),status='unknown')
        cache,attempts=m.audit_scope_jobs([j],[r],auth,allow_uncertain_retry=True)
        self.assertEqual(attempts[('P',canonical_sha(j['body']))],1)
        with self.assertRaises(ValueError):m.audit_scope_jobs([j],[r,r,r],auth,allow_uncertain_retry=True)
    def test_review_flag_is_program_metadata_but_human_true_is_refused(self):
        m=self.module();j=dict(pair_id='P',kind='relevance',packet={'span_ids':['S']})
        v=dict(pair_id='P',grade=3,evidence_span_ids=['S'],reason='对应动作')
        self.assertIs(m.validate_result(j,v)['human_approved'],False)
        self.assertIn('human_approval_field_origin',m.validate_result(j,v))
        with self.assertRaises(ValueError):m.validate_result(j,dict(v,human_approved=True))
    def test_compact_predicate_tuple_preserves_canonical_fact_schema(self):
        m=self.module();p=dict(current_text='本人作答',predicate_ids=['M.p'],mechanism_ids=['M'],required_by_mechanism={'M':['M.p']},case_unit_ids=[],article_ids=[],compact_predicate_arrays=True)
        j=dict(pair_id='P',kind='judgment',packet=p)
        v=dict(pair_id='P',state='risk',mechanism_ids=['M'],predicates={'M.p':['met','本人']},case_unit_ids=[],legal_article_ids=[],reason='线索',limitations=[],human_approved=False)
        self.assertEqual(m.validate_result(j,v)['predicates']['M.p'],dict(status='met',quote='本人'))
if __name__=='__main__':unittest.main()
