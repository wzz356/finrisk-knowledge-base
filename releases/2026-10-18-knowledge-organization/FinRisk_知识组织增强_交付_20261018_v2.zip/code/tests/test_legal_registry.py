import hashlib
import importlib.util
import json
import shutil
import sys
import unittest
import uuid
from pathlib import Path

WORK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORK))
from common import OUT, P0OLD, rows, sha


class LegalRegistryTests(unittest.TestCase):
    def api(self):
        spec = importlib.util.find_spec('legal_registry')
        self.assertIsNotNone(spec, 'LegalRegistry implementation is missing')
        import legal_registry
        return legal_registry

    def setUp(self):
        self.tmp = WORK / 'legal_task' / 'test_tmp' / uuid.uuid4().hex
        self.tmp.mkdir(parents=True)

    def tearDown(self):
        self.assertTrue(self.tmp.resolve().is_relative_to((WORK / 'legal_task').resolve()))
        shutil.rmtree(self.tmp)

    def fixture(self):
        raw = '前言\nL010: 第一条　机构应当提示风险。\nL011: 第二条　保留例外。'
        start, end = raw.index('L010:'), raw.index('\nL011:')
        text = '第一条 机构应当提示风险。'
        source = {'source_id': 'S', 'version_id': 'S-v1', 'version': '第一版',
                  'research_reference_allowed': True, 'production_active': False,
                  'human_approved': False, 'review_origin': 'current_session_model'}
        provenance = {'coordinate_system': 'reader_snapshot_char_and_utf8',
                      'snapshot_file': 'snapshots/reader.txt',
                      'span': {'start_char': start, 'end_char': end,
                               'start_byte_utf8': len(raw[:start].encode()),
                               'end_byte_utf8': len(raw[:end].encode()),
                               'span_sha256': hashlib.sha256(raw[start:end].encode()).hexdigest()},
                      'transform': 'remove_line_labels_and_unicode_whitespace'}
        article = {'article_id': 'S-A1', 'source_id': 'S', 'version_id': 'S-v1',
                   'text': text, 'text_sha256': hashlib.sha256(text.encode()).hexdigest(),
                   'production_active': False, 'human_approved': False,
                   'review_origin': 'current_session_model', 'provenance': provenance}
        (self.tmp / 'snapshots').mkdir()
        (self.tmp / 'snapshots/reader.txt').write_bytes(raw.encode())
        for path, value in [('articles.jsonl', [article]), ('source_registry.jsonl', [source]),
                            ('dependencies.jsonl', [])]:
            (self.tmp / path).write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in value), encoding='utf-8')
        (self.tmp / 'verification.json').write_text('{"raw_original_files":0}', encoding='utf-8')
        return self.repin(), article

    def repin(self):
        files = [{'path': p.relative_to(self.tmp).as_posix(), 'sha256': sha(p), 'bytes': p.stat().st_size}
                 for p in sorted(self.tmp.rglob('*')) if p.is_file() and p.name != 'manifest.json']
        (self.tmp / 'manifest.json').write_text(json.dumps({'files': files}), encoding='utf-8')
        return sha(self.tmp / 'manifest.json')

    def change_article(self, transform):
        p = self.tmp / 'articles.jsonl'
        items = list(rows(p))
        transform(items)
        p.write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in items), encoding='utf-8')
        return self.repin()

    def test_checked_slice_rejects_boolean_negative_reversed_and_oob(self):
        checked = self.api().checked_slice
        self.assertEqual('中文', checked('a中文b', 1, 3))
        for bounds in [(True, 2), (0, False), (-1, 2), (2, 1), (0, 9), (1.0, 2), (1, 1)]:
            with self.subTest(bounds=bounds), self.assertRaises(ValueError):
                checked('a中文b', *bounds)

    def test_dependency_closure_cycle_missing_and_strict_inputs(self):
        closure = self.api().dependency_closure
        result = closure(['A'], {'A': ['B'], 'B': ['A', 'M']}, {'A', 'B'})
        self.assertEqual(['A', 'B'], result['resolved'])
        self.assertEqual(['M'], result['missing'])
        self.assertEqual('partial', result['status'])
        for roots, limit in [([], 32), (['A', 'A'], 32), (['A'], True), (['A'], 0), (['A'], 33)]:
            with self.subTest(roots=roots, limit=limit), self.assertRaises(ValueError):
                closure(roots, {}, {'A'}, limit)

    def test_dependency_closure_reports_limit_as_partial_and_unread(self):
        closure = self.api().dependency_closure
        result = closure(['0'], {str(i): [str(i + 1)] for i in range(34)}, {str(i) for i in range(35)})
        self.assertEqual(32, len(result['resolved']))
        self.assertEqual(['32'], result['unread'])
        self.assertEqual('partial', result['status'])
        self.assertEqual('partial', closure(['A'], {}, {'A'}, 1)['status'])

    def test_fixture_utf8_read_preserves_proof_boundaries(self):
        api = self.api()
        pin, article = self.fixture()
        registry = api.LegalRegistry(self.tmp, expected_manifest_sha256=pin)
        result = registry.read_article('S-A1', as_of='1999-01-01')
        self.assertEqual(article['text'], result['article']['text'])
        self.assertEqual([], result['dependencies'])
        self.assertEqual('complete', result['coverage']['status'])
        self.assertFalse(result['coverage']['current_business_fact_proof'])
        self.assertFalse(result['coverage']['historical_case_applicability_confirmed'])
        self.assertEqual(0, result['coverage']['raw_original_files'])
        try:
            registry.read_article('L011-A0001')
        except Exception as exc:
            self.assertIsInstance(exc, ValueError, 'unknown or quarantined IDs must use the rejection contract')
        else:
            self.fail('quarantined article ID was accepted')

    def test_manifest_pin_and_any_payload_tamper_are_rejected(self):
        api = self.api()
        pin, _ = self.fixture()
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256='0' * 64)
        (self.tmp / 'verification.json').write_text('{}', encoding='utf-8')
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=pin)

    def test_duplicate_id_wrong_hash_cross_version_and_quarantine_rejected(self):
        api = self.api()
        mutations = [('duplicate', lambda a: a.append(dict(a[0]))),
                     ('hash', lambda a: a[0].update(text_sha256='0' * 64)),
                     ('version', lambda a: a[0].update(version_id='S-v2'))]
        for label, mutation in mutations:
            with self.subTest(label=label):
                self.fixture()
                pin = self.change_article(mutation)
                with self.assertRaises(ValueError):
                    api.LegalRegistry(self.tmp, expected_manifest_sha256=pin)
                shutil.rmtree(self.tmp)
                self.tmp.mkdir()
        self.fixture()
        p = self.tmp / 'source_registry.jsonl'
        r = list(rows(p))[0]
        r['research_reference_allowed'] = False
        p.write_text(json.dumps(r), encoding='utf-8')
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=self.repin())

    def test_coordinate_systems_and_utf8_offsets_cannot_be_mixed(self):
        api = self.api()
        self.fixture()
        pin = self.change_article(lambda a: a[0]['provenance']['span'].update(start_byte_utf8=1))
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=pin)
        pin = self.change_article(lambda a: a[0]['provenance'].update(coordinate_system='legacy_literal_char'))
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=pin)

    def test_manifest_omitted_snapshot_and_traversal_are_rejected(self):
        api = self.api()
        self.fixture()
        manifest = json.loads((self.tmp / 'manifest.json').read_text())
        manifest['files'] = [f for f in manifest['files'] if f['path'] != 'snapshots/reader.txt']
        (self.tmp / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=sha(self.tmp / 'manifest.json'))
        manifest['files'][0]['path'] = '../outside.txt'
        (self.tmp / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
        with self.assertRaises(ValueError):
            api.LegalRegistry(self.tmp, expected_manifest_sha256=sha(self.tmp / 'manifest.json'))

    def test_real_67_articles_dependency_evidence_and_unchanged_source_data(self):
        api = self.api()
        root = OUT / 'legal'
        self.assertTrue((root / 'manifest.json').is_file(), '67-article bundle has not been built')
        registry = api.LegalRegistry(root, expected_manifest_sha256=sha(root / 'manifest.json'))
        original = list(rows(P0OLD / 'reader/bundle/articles.jsonl')) + list(rows(P0OLD / 'law/supporting_articles.jsonl'))
        self.assertEqual(67, len(registry.articles))
        self.assertEqual({r['article_id'] for r in original}, set(registry.articles))
        for r in original:
            registered = registry.articles[r['article_id']]
            self.assertEqual(r['text'], registered['text'])
            self.assertEqual(r['text_sha256'], registered['text_sha256'])
            self.assertFalse(registered['production_active'])
            if 'source_reader_span' in r:
                self.assertEqual(r['source_reader_span'], registered['source_reader_span'])
                self.assertEqual(r['source_version'], registry.sources[r['source_id']]['version'])
                self.assertEqual('reader_snapshot_char_and_utf8', registered['provenance']['coordinate_system'])
            else:
                self.assertEqual('legacy_literal_char', registered['provenance']['coordinate_system'])
        expected = {(r['article_id'], target) for r in rows(P0OLD / 'law/article_admission_overlay.jsonl') for target in r['required_context_articles']}
        actual = {(r['from_article_id'], r['to_article_id']) for r in registry.edges}
        self.assertEqual(expected, actual)
        result = registry.read_article('L003-A0040')
        self.assertEqual('complete', result['coverage']['status'])
        self.assertIn('L003-A0046', [r['article_id'] for r in result['dependencies']])
        self.assertFalse(registry.sources['L011']['research_reference_allowed'])
        self.assertFalse(registry.sources['L012']['research_reference_allowed'])
        self.assertIn('pending', registry.sources['L007']['axes']['current_validity']['status'])

    def test_real_bundle_is_portable_and_omitting_dependencies_is_explicit(self):
        api = self.api()
        root = OUT / 'legal'
        self.assertTrue((root / 'manifest.json').is_file())
        portable = self.tmp / 'portable'
        shutil.copytree(root, portable)
        registry = api.LegalRegistry(portable, expected_manifest_sha256=sha(root / 'manifest.json'))
        result = registry.read_article('L003-A0040', include_dependencies=False)
        self.assertEqual([], result['dependencies'])
        self.assertEqual('partial', result['coverage']['status'])
        self.assertIn('L003-A0046', result['coverage']['unread'])
        self.assertEqual('complete', registry.read_article('L003-A0040')['coverage']['status'])
        for source in registry.sources.values():
            self.assertFalse(source['production_active'])
            self.assertFalse(source['human_approved'])
            self.assertEqual('current_session_model', source['review_origin'])
            self.assertFalse(source['axes']['original_bytes']['acquired'])
            for evidence in source['evidence']:
                self.assertTrue((portable / evidence['local_file']).is_file())

    def test_real_read_response_preserves_source_validity_cutoff_and_copies_all_objects(self):
        api = self.api()
        root = OUT / 'legal'
        registry = api.LegalRegistry(root, expected_manifest_sha256=sha(root / 'manifest.json'))
        response = registry.read_article('L001-A0017')
        self.assertIn('sources', response, 'read response must carry the actual validity evidence and version')
        source = response['sources']['L001']
        self.assertEqual('2015年修正文本', source['version'])
        self.assertEqual('2026-08-28', source['axes']['current_validity']['evidence_cutoff'])
        self.assertEqual('not_exhaustively_established',
                         source['axes']['current_validity']['post_cutoff_amendment_coverage'])
        self.assertEqual(registry.sources['L001']['evidence'], source['evidence'])
        source['axes']['current_validity']['evidence_cutoff'] = 'changed'
        self.assertEqual('2026-08-28', registry.sources['L001']['axes']['current_validity']['evidence_cutoff'])
        response = registry.read_article('L002-A0029')
        required_sources = {a['source_id'] for a in [response['article']] + response['dependencies']}
        self.assertEqual(required_sources, set(response['sources']))
        self.assertIn('ESIGN', response['sources'])
        self.assertEqual(registry.sources['ESIGN']['version'], response['sources']['ESIGN']['version'])
        dependency_id = response['dependencies'][0]['article_id']
        response['dependencies'][0]['text'] = 'changed'
        response['article']['text'] = 'changed'
        response['coverage']['resolved'].append('changed')
        self.assertNotEqual('changed', registry.articles[dependency_id]['text'])
        self.assertNotEqual('changed', registry.articles['L002-A0029']['text'])
        self.assertNotIn('changed', registry.read_article('L002-A0029')['coverage']['resolved'])


if __name__ == '__main__':
    unittest.main()
