import importlib.util
import importlib
import unittest
class CurrentFactTests(unittest.TestCase):
    def test_historical_and_rule_evidence_cannot_fill_current_input(self):
        self.assertIsNotNone(importlib.util.find_spec('evidence_bundle'))
        fn=importlib.import_module('evidence_bundle').require_current_fact
        for origin in ['historical_case','legal_article','assistant_guide']:
            with self.assertRaises(ValueError):fn(dict(origin=origin,start=0,end=1,quote='甲'),'甲')
        self.assertEqual(fn(dict(origin='current_input',start=0,end=1,quote='甲'),'甲')['quote'],'甲')
        for start,end in [(False,1),(0,99),(1,1)]:
            with self.assertRaises(ValueError):fn(dict(origin='current_input',start=start,end=end,quote='甲'),'甲')
        with self.assertRaises(ValueError):fn(dict(origin='current_input',start=0,end=1,quote='乙'),'甲')

if __name__=='__main__':unittest.main()
