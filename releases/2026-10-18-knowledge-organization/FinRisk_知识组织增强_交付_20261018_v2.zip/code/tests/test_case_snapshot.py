import importlib
import importlib.util
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import canonical_sha,textsha

class SnapshotTests(unittest.TestCase):
    def load(self):
        self.assertIsNotNone(importlib.util.find_spec('case_snapshot'),'case snapshots not implemented')
        return importlib.import_module('case_snapshot')

    def records(self):
        draft={'file_id':'F1','cases':[],'behaviors':[]};digest=canonical_sha(draft)
        return ([{'unit_id':'U1','file_id':'F1','candidate_sha256':digest,'text':'命中原文'}],
            [{'file_id':'F1','draft':draft,'effective_draft_json_sha256':digest}],
            [{'official_file_id':'F1','full_text':'命中原文','source_sha256':'raw','text_sha256':textsha('命中原文')}],[])

    def test_unknown_requested_unit_cannot_shrink_scope_silently(self):
        with self.assertRaises(ValueError):self.load().select_snapshot({'U1','UNKNOWN'},*self.records())

    def test_selected_snapshot_keeps_original_unit_and_current_draft(self):
        records=self.records();result=self.load().select_snapshot({'U1'},*records)
        self.assertEqual(result['units'],records[0]);self.assertEqual(result['candidates'],records[1])
        self.assertEqual(result['sources'][0]['full_text'],'命中原文')

    def test_unreviewed_stale_binding_refused(self):
        records=self.records();records[0][0]['candidate_sha256']='stale'
        with self.assertRaises(ValueError):self.load().select_snapshot({'U1'},*records)

if __name__=='__main__':unittest.main()
