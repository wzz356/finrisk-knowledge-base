import importlib
import importlib.util
import unittest
from common import textsha
class PrefixTests(unittest.TestCase):
    def fn(self):
        self.assertIsNotNone(importlib.util.find_spec('contextual_prefix'))
        fn=importlib.import_module('contextual_prefix').make_prefix
        return lambda u,d,s:fn(u,d,s,expected_original_text_sha256=textsha('代客户答复回访。'))
    def fixtures(self):
        text='机构被罚。张某代客户答复回访。'
        unit=dict(unit_id='U',file_id='F',text='代客户答复回访。',source_sha256=textsha(text))
        doc=dict(file_id='F',full_text=text,text_sha256=textsha(text),source_sha256=textsha(text))
        span=dict(span_id='S',file_id='F',start=5,end=len(text),text=text[5:],text_sha256=textsha(text[5:]),actor_role='unknown')
        return unit,doc,span
    def test_prefix_cannot_replace_original_or_become_case_quote(self):
        u,d,s=self.fixtures();r=self.fn()(u,d,s)
        self.assertEqual(r['original_text'],u['text']);self.assertTrue(r['representation_text'].endswith(u['text']))
        self.assertFalse(r['prefix_is_punishment_quotation']);self.assertEqual(r['actor_role'],'unknown')
    def test_foreign_source_changed_source_and_unquoted_assertions_refused(self):
        for mutation in ['foreign','source','quote','actor','unit_text']:
            u,d,s=self.fixtures()
            if mutation=='foreign':s['file_id']='OTHER'
            if mutation=='source':d['full_text']+='更改'
            if mutation=='quote':s['text']='并无此句'
            if mutation=='actor':s['inferred_actor']='张某是单位负责人并亲自实施'
            if mutation=='unit_text':u['text']='改写成另一行为'
            with self.subTest(mutation=mutation):
                with self.assertRaises(ValueError):self.fn()(u,d,s)
if __name__=='__main__':unittest.main()
