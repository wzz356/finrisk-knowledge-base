import importlib
import importlib.util
import unittest
class EvalProtocolTests(unittest.TestCase):
    def module(self):
        self.assertIsNotNone(importlib.util.find_spec('eval_protocol'))
        return importlib.import_module('eval_protocol')
    def test_story_variants_cannot_cross_split(self):
        validate=self.module().validate_groups
        valid={f'Q{i}':dict(group_id='S',split='development' if i<3 else 'holdout') for i in range(3)}
        self.assertTrue(validate(valid,expected_queries=3,expected_groups=1))
        valid['Q2']['split']='holdout'
        with self.assertRaises(ValueError):validate(valid,expected_queries=3,expected_groups=1)
    def test_unjudged_is_never_counted_as_zero_and_recall_is_not_corpus_recall(self):
        metrics=self.module().ranking_metrics
        with self.assertRaises(ValueError):metrics(['F1','F2'],{'F1':3},k=2)
        m=metrics(['F2','F1'],{'F1':3,'F2':2,'F3':3},k=2)
        self.assertEqual(m['known_pool_recall'],.5);self.assertEqual(m['MRR'],.5)
        self.assertFalse(m['global_true_recall'])
if __name__=='__main__':unittest.main()
