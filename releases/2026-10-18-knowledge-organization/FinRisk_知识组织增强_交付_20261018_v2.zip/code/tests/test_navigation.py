import importlib
import importlib.util
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

class NavigationTests(unittest.TestCase):
    def load(self):
        self.assertIsNotNone(importlib.util.find_spec('navigation'),'navigation not implemented')
        return importlib.import_module('navigation')

    def cards(self):
        return [dict(mechanism_id='M01',title='本人答复',overview='核查本人是否被指导作不实答复。',article_ids=['A'],
            adjacent_mechanism_ids=['M02'],supporting_case_links=[{'unit_id':'U1'}],adjacent_case_links=[],coverage={'status':'partial'}),
            dict(mechanism_id='M02',title='他人代答',overview='核查是否冒名，预约转接须分开。',article_ids=['A','B'],
            adjacent_mechanism_ids=['M01'],supporting_case_links=[{'unit_id':'U2'}],adjacent_case_links=[],coverage={'status':'complete'})]

    def test_shared_article_and_multiple_roles_are_not_collapsed(self):
        n=self.load().build_navigation(self.cards(),{'A','B'},{'U1','U2'})
        self.assertEqual(n['reverse_links']['ARTICLE:A'],['MECHANISM:M01','MECHANISM:M02'])
        self.assertIn('UNIT:U1',n['forward_links']['MECHANISM:M01'])
        self.assertNotIn('UNIT:U2',n['forward_links']['MECHANISM:M01'])

    def test_dangling_article_or_case_is_refused(self):
        m=self.load()
        for articles,units in [({'A'},{'U1','U2'}),({'A','B'},{'U1'})]:
            with self.subTest(articles=articles,units=units):
                with self.assertRaises(ValueError):m.build_navigation(self.cards(),articles,units)

    def test_unbuilt_adjacent_mechanism_has_explicit_pending_status(self):
        n=self.load().build_navigation(self.cards()[:1],{'A','B'},{'U1'})
        self.assertEqual(n['pending_mechanism_ids'],['M02'])
        self.assertNotIn('MECHANISM:M02',n['forward_links']['MECHANISM:M01'])

    def test_reverse_links_are_generated_from_the_same_table(self):
        n=self.load().build_navigation(self.cards(),{'A','B'},{'U1','U2'})
        for owner,targets in n['forward_links'].items():
            for target in targets:self.assertIn(owner,n['reverse_links'][target])

if __name__=='__main__':unittest.main()
