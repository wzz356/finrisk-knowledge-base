import importlib
import importlib.util
import unittest
class ExperimentContracts(unittest.TestCase):
    def fn(self):
        return importlib.import_module('experiment_k').validate_split_rankings
    def test_duplicate_queries_wrong_split_duplicate_files_are_refused(self):
        groups={'A':{'split':'development'},'B':{'split':'development'},'H':{'split':'holdout'}}
        hits=lambda:[dict(unit_id='U1',file_id='F1'),dict(unit_id='U2',file_id='F2')]
        good=[dict(query_id='A',ranking=hits()),dict(query_id='B',ranking=hits())]
        self.assertTrue(self.fn()(good,groups,'development',expected_count=2,min_documents=2))
        cases=[[good[0],good[0]],[good[0],dict(query_id='H',ranking=hits())],
               [dict(query_id='A',ranking=[dict(unit_id='U1',file_id='F1')]*2),good[1]]]
        for case in cases:
            with self.assertRaises(ValueError):self.fn()(case,groups,'development',expected_count=2,min_documents=2)
if __name__=='__main__':unittest.main()
