import importlib.util
import json
import shutil
import sys
import unittest
import uuid
from pathlib import Path

WORK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORK))


class DependencyBuildTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(importlib.util.find_spec('dependency_build'), 'dependency build API is missing')
        import dependency_build
        return dependency_build

    def setUp(self):
        self.tmp = WORK / 'maintenance_task/test_tmp' / uuid.uuid4().hex
        self.tmp.mkdir(parents=True)

    def tearDown(self):
        self.assertTrue(self.tmp.resolve().is_relative_to((WORK / 'maintenance_task').resolve()))
        shutil.rmtree(self.tmp)

    def fixture(self):
        self.source = self.tmp / 'articles.jsonl'
        self.source.write_text(json.dumps({'id': 'A', 'text': '提示风险', 'status': 'dated', 'date': '2026-08-28'}, ensure_ascii=False)+'\n', encoding='utf-8')
        (self.tmp / 'spans.jsonl').write_text(json.dumps({'id': 'S', 'text': '查实代签', 'role': 'agent'}, ensure_ascii=False)+'\n', encoding='utf-8')
        def node(identity, kind, path=None, fields=None, deps=()):
            return {'node_id': identity, 'kind': kind, 'dependencies': list(deps),
                    'input': {'path': path, 'record_key': 'id', 'record_id': 'A' if path == 'articles.jsonl' else 'S', 'fields': fields} if path else None,
                    'status': 'present' if path else 'pending'}
        specs = [node('article', 'text', 'articles.jsonl', ['text']),
                 node('article_meta', 'metadata', 'articles.jsonl', ['status', 'date']),
                 node('span', 'text', 'spans.jsonl', ['text']),
                 node('card', 'card', deps=['article', 'span']),
                 node('review', 'review', deps=['card', 'article_meta']),
                 node('navigation', 'navigation', deps=['review']),
                 node('representation', 'representation', deps=['span']),
                 node('bm25', 'bm25_index', deps=['representation']),
                 node('vector', 'embedding', deps=['representation'])]
        return self.api().DependencyGraph.snapshot(self.tmp, specs)

    def mutate(self, path, **changes):
        p = self.tmp / path
        row = json.loads(p.read_text(encoding='utf-8')); row.update(changes)
        p.write_text(json.dumps(row, ensure_ascii=False)+'\n', encoding='utf-8')

    def test_one_article_changes_only_its_transitive_dependents(self):
        graph = self.fixture()
        self.mutate('articles.jsonl', text='补充风险提示')
        impact = graph.impact(self.tmp)
        self.assertEqual(['article'], impact['changed'])
        self.assertEqual({'article', 'card', 'review', 'navigation'}, set(impact['affected']))
        self.assertEqual(['card'], impact['direct_affected'])
        self.assertFalse(impact['index_rebuild_required'])

    def test_span_text_change_requires_bm25_and_embedding(self):
        graph = self.fixture()
        self.mutate('spans.jsonl', text='查实代签及代抄')
        impact = graph.impact(self.tmp)
        self.assertIn('vector', impact['affected'])
        self.assertIn('bm25', impact['affected'])
        self.assertTrue(impact['index_rebuild_required'])

    def test_metadata_only_change_reviews_reading_without_reencoding(self):
        graph = self.fixture()
        self.mutate('articles.jsonl', date='2026-09-01')
        impact = graph.impact(self.tmp)
        self.assertTrue(impact['metadata_only'])
        self.assertEqual({'article_meta', 'review', 'navigation'}, set(impact['affected']))
        self.assertFalse(impact['index_rebuild_required'])

    def test_unrelated_file_does_not_invalidate_anything(self):
        graph = self.fixture()
        (self.tmp / 'notes.txt').write_text('unrelated', encoding='utf-8')
        self.assertEqual([], graph.impact(self.tmp)['affected'])

    def test_cycles_duplicate_missing_and_bad_input_sha_are_rejected(self):
        api = self.api()
        graph = self.fixture()
        nodes = json.loads(json.dumps(graph.nodes))
        nodes[0]['dependencies'] = ['navigation']
        with self.assertRaises(ValueError):
            api.DependencyGraph(nodes)
        with self.assertRaises(ValueError):
            api.DependencyGraph(graph.nodes + [graph.nodes[0]])
        nodes = json.loads(json.dumps(graph.nodes)); nodes[0]['dependencies'] = ['absent']
        with self.assertRaises(ValueError):
            api.DependencyGraph(nodes)
        nodes = json.loads(json.dumps(graph.nodes)); nodes[0]['input_sha256'] = '0' * 64
        with self.assertRaises(ValueError):
            api.DependencyGraph(nodes).verify_inputs(self.tmp)

    def test_failed_rebuild_never_activates_or_mutates_inputs(self):
        graph = self.fixture()
        self.mutate('spans.jsonl', text='已更改原句')
        before = self.source.read_bytes()
        def fail(*args):
            raise RuntimeError('controlled_builder_failure')
        receipt = self.api().rebuild_affected(graph, self.tmp, self.tmp / 'stage', builders={'representation': fail})
        self.assertEqual('failed', receipt['status'])
        self.assertFalse(receipt['activation_allowed'])
        self.assertIn('representation', receipt['failed'])
        self.assertEqual(before, self.source.read_bytes())
        self.assertFalse((self.tmp / 'active.json').exists())

    def test_missing_index_computation_stays_pending_and_stage_is_not_reusable(self):
        graph = self.fixture()
        self.mutate('spans.jsonl', text='另一原句')
        stage = self.tmp / 'stage'
        receipt = self.api().rebuild_affected(graph, self.tmp, stage)
        self.assertEqual('pending', receipt['status'])
        self.assertFalse(receipt['activation_allowed'])
        self.assertIn('vector', receipt['pending'])
        self.assertIn('bm25', receipt['pending'])
        self.assertTrue(receipt['built'])
        with self.assertRaises(FileExistsError):
            self.api().rebuild_affected(graph, self.tmp, stage)

    def test_staging_cannot_claim_index_recomputation_from_an_arbitrary_builder(self):
        graph = self.fixture()
        self.mutate('spans.jsonl', text='待重新计算的文本')
        receipt = self.api().rebuild_affected(graph, self.tmp, self.tmp / 'stage', builders={
            'representation': lambda *args: {'staged_input': '待重新计算的文本'},
            'embedding': lambda *args: {'claimed_success': True},
            'bm25_index': lambda *args: {'claimed_success': True}})
        self.assertFalse(receipt['embedding_recomputed'])
        self.assertFalse(receipt['bm25_recomputed'])
        self.assertIn('vector', receipt['pending'])
        self.assertIn('bm25', receipt['pending'])

    def test_real_registration_and_copy_mutations_preserve_official_artifacts(self):
        api = self.api()
        from common import OUT, read, rows
        root = OUT / 'maintenance'
        self.assertTrue((root / 'simulation_report.json').is_file(), 'real-copy scenarios have not run')
        graph = api.DependencyGraph(rows(root / 'dependencies.jsonl'))
        self.assertTrue(graph.verify_inputs(OUT))
        self.assertEqual([], graph.impact(OUT)['affected'])
        coverage, report = read(root / 'coverage.json'), read(root / 'simulation_report.json')
        self.assertEqual(67, coverage['actual_scope']['articles'])
        self.assertEqual(591, coverage['actual_scope']['pilot_units'])
        self.assertFalse(coverage['coverage_is_full_corpus_audit'])
        self.assertTrue(report['official_payloads_unchanged'])
        self.assertEqual(report['official_input_hashes_before'], report['official_input_hashes_after'])
        scenarios = {r['scenario']: r for r in report['scenarios']}
        self.assertEqual(0, scenarios['unrelated_file']['affected_count'])
        self.assertFalse(scenarios['source_validity_metadata']['index_rebuild_required'])
        self.assertTrue(scenarios['case_span_text']['index_rebuild_required'])
        self.assertEqual('failed', scenarios['controlled_build_failure']['status'])
        for result in scenarios.values():
            self.assertFalse(result['activation_allowed'])
            self.assertFalse(result['embedding_recomputed'])
            self.assertFalse(result['bm25_recomputed'])


if __name__ == '__main__':
    unittest.main()
