"""Pin assembled candidate knowledge separately from immutable base versions."""
from common import *

def main():
    files={p.relative_to(OUT).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for folder in ['knowledge','navigation'] for p in sorted((OUT/folder).rglob('*')) if p.is_file()}
    save(OUT/'contracts/knowledge_manifest.json',dict(schema='finrisk-enhancement-knowledge-v1',files=files,
        enhancement_version='knowledge-organization-pilot-v1',base_versions=read(OUT/'case_reader/pilot_lock.json')['versions'],human_approved=False))
    save(OUT/'contracts/knowledge_lock.json',dict(manifest_sha256=sha(OUT/'contracts/knowledge_manifest.json'),version='knowledge-organization-pilot-v1'))
    print(json.dumps(dict(payloads=len(files),manifest_sha256=sha(OUT/'contracts/knowledge_manifest.json'))))

if __name__=='__main__':main()
