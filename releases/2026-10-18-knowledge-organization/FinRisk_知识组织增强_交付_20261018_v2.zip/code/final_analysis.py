"""Post-experiment sensitivity, stage coverage, cost and final reader snapshot."""
from collections import Counter, defaultdict
import statistics
from common import *
from eval_protocol import ranking_metrics

def sensitivity(root=OUT):
    root=Path(root)
    effective={(r['query_id'],r['file_id']):r['grade'] for r in rows(root/'experiment_R/qrels_development_shared.jsonl')}
    bindings={r['pair_id']:r for r in rows(root/'experiment_K/relevance_map_development.jsonl')}
    legacy={}
    for r in rows(root/'api/K_development_relevance/accepted.jsonl'):
        m=bindings[r['pair_id']];legacy[m['query_id'],m['file_id']]=r['parsed']['grade']
    for r in rows(root/'experiment_R/qrels_development_shared.jsonl'):
        if (r['query_id'],r['file_id']) not in {(m['query_id'],m['file_id']) for m in bindings.values()}:
            legacy[r['query_id'],r['file_id']]=r['grade']
    changes=[dict(query_id=q,file_id=f,original_grade=g,effective_grade=effective[q,f]) for (q,f),g in legacy.items() if effective[q,f]!=g]
    ranks={a:{r['query_id']:r['ranking'] for r in rows(root/p)} for a,p in [('R0','experiment_K/rankings_development.jsonl'),('R1','experiment_R_controlled/rankings_development.jsonl')]}
    if set(ranks['R0'])!=set(ranks['R1']) or len(ranks['R0'])!=12:raise ValueError('incomplete paired rankings')
    missing={q:sorted({h['file_id'] for a in ranks for h in ranks[a][q][:20] if (q,h['file_id']) not in legacy}) for q in ranks['R0']}
    included=sorted(q for q in ranks['R0'] if not missing[q]);summaries={};per=[]
    for name,ref in [('original',legacy),('first_valid',effective)]:
        grades=defaultdict(dict)
        for (q,f),g in ref.items():grades[q][f]=g
        summaries[name]={}
        for arm,queries in ranks.items():
            summaries[name][arm]={}
            for k in [1,5,10,20]:
                part=[dict(query_id=q,arm=arm,reference=name,K=k,**ranking_metrics([h['file_id'] for h in queries[q]],grades[q],k)) for q in included]
                per.extend(part)
                summaries[name][arm][str(k)]={m:statistics.mean(r[m] for r in part if r[m] is not None) if any(r[m] is not None for r in part) else None for m in ['P','MRR','Top1','known_pool_recall','NDCG_pool']}
                summaries[name][arm][str(k)]['paired_queries']=len(part)
    return dict(schema='metadata-sensitivity-v1',original_shared_pairs=len(legacy),first_valid_shared_pairs=len(effective),
        changed_existing_grades=len(changes),upward=sum(r['effective_grade']>r['original_grade'] for r in changes),downward=sum(r['effective_grade']<r['original_grade'] for r in changes),
        changes=changes,paired_complete_query_ids=included,excluded_unjudged={q:f for q,f in missing.items() if f},summary=summaries,
        unjudged_imputed_as_zero=False,not_a_representation_gain='Comparisons between reference versions describe annotation sensitivity, not retrieval improvement.',per_query=per)

def stage_coverage(root=OUT, bindings=None):
    root=Path(root)
    routes={arm:{r['query_id']:r for r in rows(root/p)} for arm,p in [('R0','experiment_K/routes.jsonl'),('R1','experiment_R_controlled/routes.jsonl')]}
    wanted={h['unit_id'] for data in routes.values() for r in data.values() for route in ['BM25','BGE','RRF'] for h in r[route]}
    if bindings is None:
        bindings={r['unit_id']:r['file_id'] for r in rows(V2/'indexes/all9639_final/structured.jsonl') if r['unit_id'] in wanted}
    if set(bindings)!=wanted:raise ValueError('stage unit-file bindings missing or extra')
    direct=defaultdict(set)
    for r in rows(root/'experiment_R/qrels_development_shared.jsonl'):
        if r['grade']==3:direct[r['query_id']].add(r['file_id'])
    ranks={arm:{r['query_id']:r['ranking'] for r in rows(root/p)} for arm,p in [('R0','experiment_K/rankings_development.jsonl'),('R1','experiment_R_controlled/rankings_development.jsonl')]}
    per=[]
    for arm,data in routes.items():
        for q in ranks[arm]:
            sets={s:{bindings[h['unit_id']] for h in data[q][s]} for s in ['BM25','BGE','RRF']}
            sets['dual_union']=sets['BM25']|sets['BGE'];sets['rerank_Top20']={h['file_id'] for h in ranks[arm][q][:20]}
            for s,found in sets.items():
                gold=direct[q];per.append(dict(query_id=q,arm=arm,stage=s,known_direct=len(gold),found_known_direct=len(gold&found),known_pool_coverage=len(gold&found)/len(gold) if gold else None,
                    missed_known_direct=sorted(gold-found),denominator='shared judged Top20 document union only',global_true_recall=False))
    summary={a:{s:statistics.mean(r['known_pool_coverage'] for r in per if r['arm']==a and r['stage']==s and r['known_pool_coverage'] is not None) for s in ['BM25','BGE','dual_union','RRF','rerank_Top20']} for a in routes}
    return dict(summary=summary,per_query=per,limitation='Selection-biased known pool, not independent initial-retrieval recall or full-corpus recall.'),bindings

def costs(root=OUT):
    root=Path(root);ledger=list(rows(root/'api/budget/ledger.jsonl'))
    reserves={r['reservation_id']:r for r in ledger if r['event']=='reserve'}
    settled={r['reservation_id']:r for r in ledger if r['event']=='settle'}
    if len(reserves)!=sum(r['event']=='reserve' for r in ledger) or len(settled)!=sum(r['event']=='settle' for r in ledger) or set(reserves)!=set(settled):raise ValueError('unsettled/duplicate budget reservations')
    total=sum(r['booked_usd'] for r in settled.values())
    if total>2+1e-12:raise ValueError('budget cap exceeded')
    phases={};all_records=[]
    for p in sorted((root/'api').iterdir()):
        if not p.is_dir() or not (p/'records.jsonl').exists():continue
        records=list(rows(p/'records.jsonl'));all_records.extend(records)
        usage=Counter()
        for r in records:
            u=(r.get('response') or {}).get('usage',{})
            for k in ['prompt_tokens','completion_tokens','prompt_cache_hit_tokens','prompt_cache_miss_tokens']:usage[k]+=u.get(k,0)
        pair_counts=Counter(r['pair_id'] for r in records)
        phases[p.name]=dict(recorded_attempts=len(records),unique_paid_pairs=len(pair_counts),maximum_attempts=max(pair_counts.values(),default=0),statuses=dict(Counter(r['status'] for r in records)),
            seconds_sum=sum(r.get('seconds',0) for r in records),median_attempt_seconds=statistics.median(r.get('seconds',0) for r in records) if records else None,known_usage_tokens=dict(usage),
            booked_peak_bound_usd=sum(s['booked_usd'] for rid,s in settled.items() if reserves[rid]['phase']==p.name))
    if any(p['maximum_attempts']>3 for p in phases.values()):raise ValueError('attempt cap exceeded')
    unknown=[rid for rid,r in settled.items() if r.get('unknown_cost')]
    return dict(schema='finrisk-api-cost-audit-v1',hard_cap_usd=2,booked_peak_bound_usd=total,remaining_bound_usd=2-total,
        actual_vendor_invoice_verified=False,amount_identity='Conservative peak-price bookkeeping, not verified actual vendor billing',
        reserved_attempts=len(reserves),recorded_attempts=len(all_records),settled_attempts=len(settled),unsettled_reservations=0,unknown_cost_reservations=len(unknown),
        phases=phases,parallel_request_seconds_are_not_wall_clock=True,all_failed_and_unused_requests_retained=True,
        price_reference='https://api-docs.deepseek.com/quick_start/pricing/')

def final_snapshot():
    from case_snapshot import build_snapshot
    wanted=set()
    for p in ['experiment_K/rankings_development.jsonl','experiment_K/rankings_holdout.jsonl','experiment_R_controlled/rankings_development.jsonl']:
        wanted.update(h['unit_id'] for r in rows(OUT/p) for h in r['ranking'][:20])
    for p in ['knowledge/case_links.jsonl','expanded/knowledge/case_links.jsonl']:
        wanted.update(r['unit_id'] for r in rows(OUT/p) if r.get('unit_id'))
    return build_snapshot(wanted,OUT/'case_reader/final',include_replay=True)

def main():
    def emit(path,value,jl=False):
        if path.exists():
            if (list(rows(path)) if jl else read(path))!=value:raise ValueError('existing analysis disagrees: '+str(path))
        else:save(path,value,jl)
    emit(OUT/'reports/metadata_sensitivity.json',sensitivity())
    coverage,bindings=stage_coverage();emit(OUT/'reports/known_direct_stage_coverage.json',coverage)
    emit(OUT/'evaluation/stage_unit_file_bindings.jsonl',[dict(unit_id=u,file_id=f) for u,f in sorted(bindings.items())],True)
    emit(OUT/'reports/cost_audit.json',costs())
    if not (OUT/'case_reader/final_lock.json').exists():final_snapshot()
    print(json.dumps(dict(sensitivity=True,stage_coverage=True,cost=costs()['booked_peak_bound_usd'],final_reader=read(OUT/'case_reader/final_receipt.json')),ensure_ascii=False))

if __name__=='__main__':main()
