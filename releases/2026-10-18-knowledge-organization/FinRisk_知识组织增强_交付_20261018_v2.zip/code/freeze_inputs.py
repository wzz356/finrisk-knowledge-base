"""Protect the existing KB and initialize an independent enhancement build."""
import shutil
import subprocess
from common import *

SCOPE='finrisk-knowledge-organization-v1-20261018'

def verify_inputs(table):
    for path,digest in table.items():
        if sha(path)!=digest:raise ValueError('frozen input changed: '+str(path))
    return True

def safe_output(root,relative,input_paths):
    root=Path(root).resolve();output=(root/relative).resolve()
    if not output.is_relative_to(root) or output==root:raise ValueError('output outside isolated task')
    for item in input_paths:
        target=(root/item).resolve()
        if target==output or target.is_relative_to(output) or output.is_relative_to(target):
            raise ValueError('output overlaps input')
    return output

def api_authorized(config):
    path=config['api'].get('authorization_file')
    if not path:return False
    auth=read(path)
    return (auth.get('authorized') is True and auth.get('scope')==SCOPE and
            auth.get('model')==config['api']['model'] and type(auth.get('hard_cap_usd')) in [int,float]
            and 0<auth['hard_cap_usd']<=2 and bool(auth.get('human_authorization_reference')))

def main():
    config=read(WORK/'config.json');inputs=config['inputs']
    if Path(config['project_root']).resolve()!=ROOT.resolve():raise ValueError('root mismatch')
    safe_output(ROOT,config['output_dir'],list(inputs.values()))
    config['retrieval_python']=str(ROOT/'work/finrisk_retrieval_20261012/.venv/Scripts/python.exe')
    if not Path(config['retrieval_python']).is_file():raise ValueError('retrieval runtime missing')
    paths=[ROOT/inputs[k] for k in ['current','documents','structured','raw','official_labels','retrieval_runtime_record']]
    paths += [BASE/p for p in ['auxiliary_lexicon.json','law_review/operational_rules_overlay.json','rerank_rules.md',
        'boundary_evidence_contract.json','qrels_silver.jsonl','rankings.jsonl','retrieval_metrics.json']]
    paths += [p for p in P0OLD.rglob('*') if p.is_file()]
    paths += [ROOT/'work/finrisk_retrieval_20261012/runner.py',ROOT/'work/finrisk_kb_improvements_20261018/retrieve_experiment.py',
        ROOT/'docs/superpowers/plans/2026-10-18-finrisk-knowledge-organization-plan.md']
    table={str(p.resolve()):sha(p) for p in paths}
    labels=read(ROOT/inputs['official_labels'])
    if len(labels)!=27 or len({r['risk_tag'] for r in labels})!=27:raise ValueError('official taxonomy mismatch')
    for r in read(P0OLD/'manifest.json')['files']:
        if sha(P0OLD/r['path'])!=r['sha256']:raise ValueError('old release mismatch')
    baseline=WORK/'baseline_check';shutil.copytree(P0OLD/'code',baseline)
    run=subprocess.run([str(PYTHON),'-S','-X','utf8','-B','-m','unittest','discover','-s',str(baseline),'-p','test_*.py','-v'],
        capture_output=True,text=True,encoding='utf-8',cwd=WORK)
    (WORK/'baseline_tests.txt').write_text(run.stdout+run.stderr,encoding='utf-8')
    if run.returncode:raise RuntimeError('baseline contracts failed')
    replay=subprocess.run([str(PYTHON),'-S','-X','utf8','-B',str(P0OLD/'code/verify_delivery.py'),'--root',str(P0OLD)],
        capture_output=True,text=True,encoding='utf-8',cwd=WORK)
    if replay.returncode:raise RuntimeError(replay.stderr)
    baseline_receipt=__import__('json').loads(replay.stdout)
    verify_inputs(table)
    save(OUT/'contracts/config.json',config)
    save(OUT/'contracts/input_freeze.json',dict(utc=utc(),scope=SCOPE,sha256=table))
    save(OUT/'contracts/protected_assets.json',dict(sha256=table,mutation_allowed=False))
    save(OUT/'contracts/base_versions.json',read(P0OLD/'reader/consumer_lock.json'))
    save(OUT/'contracts/baseline_receipt.json',baseline_receipt)
    save(OUT/'contracts/scope.json',dict(scope=SCOPE,mechanisms=config['pilot_mechanism_ids'],documents_target=48,documents_cap=60,
        source_corpus=9639,structured_units=65475,raw_units=45403,API_authorized=api_authorized(config),
        review_origin='current_session_model',human_approved=False,live_Agent_runtime_modified=False))
    print(__import__('json').dumps(dict(frozen_files=len(table),baseline_contract_tests=14,
        actual_replay_positions=baseline_receipt['ranking_positions'],API_authorized=False),ensure_ascii=False))

if __name__=='__main__':main()
