"""Bounded source-linked contextual index representation; never rewrites quotes."""
import re
from common import *

def make_prefix(unit,document,span,*,expected_original_text_sha256):
    full=document['full_text'];start,end=span['start'],span['end']
    if unit['file_id']!=document['file_id'] or span['file_id']!=unit['file_id']:raise ValueError('foreign source context')
    if not expected_original_text_sha256 or textsha(unit['text'])!=expected_original_text_sha256:raise ValueError('original index text pin mismatch')
    if textsha(full)!=document['text_sha256'] or unit['source_sha256']!=document['source_sha256']:raise ValueError('source binding changed')
    if type(start) is not int or type(end) is not int or not 0<=start<end<=len(full) or full[start:end]!=span['text'] or textsha(span['text'])!=span['text_sha256']:raise ValueError('background has no exact source evidence')
    if 'inferred_actor' in span:raise ValueError('context must not invent actor attribution')
    prefix='监管处罚文书背景（助手编排，仅供检索）：同文书记载“'+span['text']+'”。背景可能涉及其他主体或行为；具体归责、环节和产品按原文核查，未明确内容保持未知。'
    representation=prefix+'\n原检索片段：'+unit['text']
    return dict(unit_id=unit['unit_id'],file_id=unit['file_id'],original_text=unit['text'],original_text_sha256=textsha(unit['text']),
        prefix_text=prefix,prefix_text_sha256=textsha(prefix),representation_text=representation,representation_sha256=textsha(representation),
        representation_id='CTX-'+canonical_sha([unit['unit_id'],representation])[:24],source_sha256=unit['source_sha256'],
        supporting_span_ids=[span['span_id']],supporting_spans=[dict(start=start,end=end,text=span['text'])],
        actor_role=span.get('actor_role','unknown'),attribution_status='context_not_independent_same_actor_proof',
        may_include_other_actors_or_behaviors=True,prefix_is_punishment_quotation=False,original_quote_preserved=True,
        human_approved=False,review_origin='current_session_model')

def main():
    links=list(rows(OUT/'knowledge/case_links.jsonl'));spans={s['span_id']:s for s in rows(OUT/'knowledge/source_spans.jsonl')}
    docs={d['file_id']:d for d in rows(OUT/'knowledge/source_documents.jsonl')}
    unitids={l['unit_id'] for l in links if l['unit_id']};units={u['unit_id']:u for u in rows(OUT/'case_reader/pilot/units.jsonl') if u['unit_id'] in unitids}
    selected=[];prefixes=[]
    for uid,u in sorted(units.items()):
        if len(u['text'])>=160 and not re.search('上述|以上|该公司|代为|回访|签名|返还',u['text']):continue
        choices=[spans[l['span_id']] for l in links if l['file_id']==u['file_id'] and spans[l['span_id']]['text'] not in u['text']]
        # Prefer a short complete registered quotation; do not synthesize an unrecorded product or role.
        choices=[s for s in choices if 10<=len(s['text'])<=120]
        if not choices:continue
        s=min(choices,key=lambda x:(len(x['text']),x['span_id']))
        r=make_prefix(u,docs[u['file_id']],s,expected_original_text_sha256=textsha(u['text']))
        if sum('\u4e00'<=c<='\u9fff' for c in r['prefix_text'])>160:continue
        selected.append(dict(unit_id=uid,file_id=u['file_id'],reason='short_or_context_dependent_fragment_with_distinct_registered_document_background',
            selection_uses_queries_or_answers=False,source_span_id=s['span_id']))
        prefixes.append(r)
        if len(prefixes)==60:break
    save(OUT/'context/selection.jsonl',selected,True);save(OUT/'context/prefixes.jsonl',prefixes,True)
    save(OUT/'context/representation_overlay.jsonl',[{k:r[k] for k in ['unit_id','representation_id','original_text_sha256','representation_sha256','representation_text','source_sha256']} for r in prefixes],True)
    save(OUT/'context/receipt.json',dict(selected_units=len(prefixes),cap=60,pilot_documents=48,available_candidate_units=78,
        queries_or_ranks_read=False,original_index_changed=False,default_enabled=False,
        scope='literal document-context prefix; deliberately no guessed same-actor attribution',new_paid_calls=0))
    print(json.dumps(dict(prefixes=len(prefixes),default_enabled=False)))

if __name__=='__main__':main()
