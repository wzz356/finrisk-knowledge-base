"""Portable, stdlib-only readback and metric replay; never calls a model."""
import argparse
from collections import Counter
from common import *
from knowledge_facade import KnowledgeFacade
from navigation import build_navigation
from eval_protocol import ranking_metrics
from evaluate_k import calculate
from final_analysis import costs,sensitivity,stage_coverage

def verify_payloads(root):
    root=Path(root).resolve();manifest=read(root/'manifest.json')
    if manifest.get('schema')!='finrisk-organization-release-v1':raise ValueError('unsupported release manifest')
    names=set()
    for item in manifest['files']:
        name=item['path'];path=(root/name).resolve()
        if not path.is_relative_to(root) or path==root/'manifest.json' or name in names:raise ValueError('invalid or duplicated payload path')
        names.add(name)
        if not path.is_file() or path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']:raise ValueError('changed or missing payload: '+name)
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'manifest.json'}
    if names!=actual:raise ValueError('payload inventory differs from release manifest')
    return len(names)

def r_replay(root):
    root=Path(root);ranks={a:list(rows(root/p)) for a,p in [('R0','experiment_K/rankings_development.jsonl'),('R1','experiment_R_controlled/rankings_development.jsonl')]}
    groups=read(root/'evaluation/group_split.json');qids={q for q,g in groups.items() if g['split']=='development'}
    if len(qids)!=12:raise ValueError('R development count mismatch')
    grades={};reference=list(rows(root/'experiment_R/qrels_development_shared.jsonl'))
    for r in reference:
        if r['file_id'] in grades.setdefault(r['query_id'],{}):raise ValueError('duplicate shared qrel')
        grades[r['query_id']][r['file_id']]=r['grade']
    union={(r['query_id'],h['file_id']) for rs in ranks.values() for r in rs for h in r['ranking'][:20]}
    if len(reference)!=245 or union!={(q,f) for q,fs in grades.items() for f in fs}:raise ValueError('shared pool differs from actual Top20 union')
    per=[];summary={}
    for a,rs in ranks.items():
        if len(rs)!=12 or {r['query_id'] for r in rs}!=qids:raise ValueError('R ranking query set mismatch')
        for r in rs:
            if len({h['file_id'] for h in r['ranking']})!=len(r['ranking']):raise ValueError('duplicate document rank')
            for k in [1,5,10,20]:per.append(dict(query_id=r['query_id'],arm=a,K=k,**ranking_metrics([h['file_id'] for h in r['ranking']],grades[r['query_id']],k)))
        summary[a]={}
        for k in [1,5,10,20]:
            part=[r for r in per if r['arm']==a and r['K']==k]
            summary[a][str(k)]={n:sum(r[n] for r in part if r[n] is not None)/sum(r[n] is not None for r in part) if any(r[n] is not None for r in part) else None for n in ['P','MRR','Top1','known_pool_recall','NDCG_pool']}
            summary[a][str(k)]['valid_queries']=len(part)
    stored=read(root/'experiment_R_controlled/metrics.json')
    if summary!=stored['summary'] or per!=list(rows(root/'experiment_R_controlled/per_query_metrics.jsonl')):raise ValueError('R metrics replay disagrees')
    p0,p1=summary['R0'],summary['R1']
    gate=p1['5']['P']+1e-12>=p0['5']['P'] and p1['20']['NDCG_pool']+1e-12>=p0['20']['NDCG_pool'] and (round((p1['1']['Top1']-p0['1']['Top1'])*12)>=1 or p1['20']['MRR']-p0['20']['MRR']>=.03-1e-12)
    if gate!=stored['numeric_gate_passed']:raise ValueError('R gate replay disagrees')
    # Scores are rebound to exact request bodies. No network or credentials are accessed.
    from api_jobs import rerank_job,validate_result
    cache={}
    for p in sorted((root/'api').glob('*/records.jsonl')):
        for r in rows(p):
            if r['status']=='accepted' and r['kind']=='rerank':cache[r['pair_id'],r['base_payload_sha256']]=r
    rules=(root/'experiment_R/rerank_rules.md').read_text(encoding='utf-8');scores={}
    for packet in rows(root/'experiment_R_controlled/rerank_inputs.jsonl'):
        job=rerank_job(packet,rules);key=(packet['pair_id'],canonical_sha(job['body']));r=cache[key]
        scores[packet['pair_id']]=validate_result(job,r['parsed'])['score']
    if len(scores)!=1200:raise ValueError('R exact score set incomplete')
    byquery={}
    for m in rows(root/'experiment_R_controlled/candidate_map.jsonl'):byquery.setdefault(m['query_id'],[]).append(dict(m,score=scores[m['pair_id']]))
    rebuilt=[]
    for q,cs in byquery.items():
        seen=set();files=[]
        for c in sorted(cs,key=lambda x:(-x['score'],x['unit_id'])):
            if c['file_id'] not in seen:seen.add(c['file_id']);files.append(dict(c,rank=len(files)+1))
        rebuilt.append(dict(query_id=q,ranking=files,score_count=100))
    if rebuilt!=ranks['R1']:raise ValueError('R ranks differ from exact prior API scores')
    return dict(queries=12,shared_qrels=245,exact_cached_scores=1200,gate_passed=gate)

def verify(root,*,require_manifest=True):
    root=Path(root).resolve();payload_count=verify_payloads(root) if require_manifest else None
    lock=read(root/'case_reader/final_lock.json');facades={};span_count=0
    for profile,folder,count in [('pilot','contracts',4),('expanded','expanded/contracts',12)]:
        facade=KnowledgeFacade(root,lock,expected_knowledge_manifest_sha256=read(root/folder/'knowledge_lock.json')['manifest_sha256'],profile=profile)
        if len(facade.cards)!=count or len(facade.legal.articles)!=67:raise ValueError('knowledge inventory mismatch')
        for mid in facade.cards:facade.read_mechanism(mid,level='L2')
        nav=build_navigation(list(facade.cards.values()),set(facade.legal.articles),set(facade.cases.units),set(facade.spans))
        if nav!=facade.navigation:raise ValueError('navigation replay disagrees')
        facades[profile]=facade
    f=facades['expanded']
    for uid in f.cases.units:
        got=f.read_case(uid)
        for span in got['segments']:
            if f.cases.read_span(span['span_id'])!=span:raise ValueError('registered case span changed')
            span_count+=1
    legacy=list(rows(root/'regression/legacy_readings.jsonl'))
    if len(legacy)!=960:raise ValueError('legacy reference count mismatch')
    for r in legacy:
        if canonical_sha(f.read_case(r['unit_id']))!=r['expected_read_sha256']:raise ValueError('legacy readback disagrees')
    for aid in f.legal.articles:f.read_article(aid)
    k=calculate(root,root/'semantic_review');kper=k.pop('per_query');kret=k.pop('retrieval')
    if k!=read(root/'experiment_K/metrics.json') or kper!=list(rows(root/'experiment_K/per_query_results.jsonl')) or kret!=list(rows(root/'experiment_K/retrieval_per_query.jsonl')):raise ValueError('K metric replay disagrees')
    r=r_replay(root)
    if sensitivity(root)!=read(root/'reports/metadata_sensitivity.json'):raise ValueError('sensitivity replay disagrees')
    bindings={r['unit_id']:r['file_id'] for r in rows(root/'evaluation/stage_unit_file_bindings.jsonl')}
    stage,_=stage_coverage(root,bindings)
    if stage!=read(root/'reports/known_direct_stage_coverage.json') or costs(root)!=read(root/'reports/cost_audit.json'):raise ValueError('coverage/cost replay disagrees')
    from additional_metrics import calculate as additional
    if additional(root)!=read(root/'reports/additional_descriptive_metrics.json'):raise ValueError('additional descriptive metrics replay disagrees')
    from dependency_build import DependencyGraph
    graph=DependencyGraph(rows(root/'maintenance_final/dependencies.jsonl'));graph.verify_inputs(root);impact=graph.impact(root)
    if impact['changed'] or impact['affected']:raise ValueError('maintenance graph baseline changed')
    smoke=read(root/'expanded/regression/smoke_receipt.json')
    if not smoke['passed'] or smoke['total_inputs']!=36 or smoke['model_accuracy_measured']:raise ValueError('expanded smoke identity changed')
    tiny=f.get_evidence_bundle(['M11'],[],budget_chars=2,case_budget=1,law_budget=1)
    if tiny['coverage']['status']!='partial' or tiny['current_input_facts_assessed']:raise ValueError('bundle silently treats omissions as complete')
    return dict(passed=True,payloads_verified=payload_count,case_units=len(f.cases.units),case_documents=len(f.cases.sources),
        case_registered_spans_read=span_count,legacy_positions_replayed=960,legal_articles_read=67,mechanisms_read={'pilot':4,'expanded':12},
        K_decisions=48,K_accepted=41,K_development_failures_retained=7,K_holdout_gate_passed=k['holdout_trial_gate']['passed'],R=r,
        maintenance_nodes=len(graph.nodes),maintenance_baseline_changed=0,expanded_scope_smoke_inputs=36,additional_descriptive_metrics_replayed=True,API_calls=0,
        full_corpus_search_reexecuted=False,models_reexecuted=False,full_corpus_true_recall_measured=False,
        human_approved=False,review_origin='current_session_model',live_Agent_runtime_verified=False)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);a=p.parse_args(argv)
    print(json.dumps(verify(a.root),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
