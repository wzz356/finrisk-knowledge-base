"""Separate 12-card reading profile; pilot evidence/experiment stay immutable."""
import copy
from common import *
from mechanism_cards import validate_card
from navigation import build_navigation
from knowledge_facade import KnowledgeFacade

ADJ=dict(M07=['M05','M08'],M08=['M07'],M05=['M04','M06'],M06=['M05'],M03=['M05'],M09=['M05'],M10=['M11'],M12=['M01'])

def build():
    review=read(WORK/'expansion_review/final_acceptance.json');author=WORK/'expansion_author'
    if not review.get('assembly_accepted'):raise ValueError('expansion independent review not accepted')
    for name,digest in review['data_file_sha256'].items():
        if sha(author/name)!=digest:raise ValueError('accepted expansion data changed')
    cards=list(rows(OUT/'knowledge/mechanisms.jsonl'));links=list(rows(OUT/'knowledge/case_links.jsonl'))
    spans=list(rows(OUT/'knowledge/source_spans.jsonl'));sources={s['file_id']:s for s in rows(OUT/'knowledge/source_documents.jsonl')}
    claims=list(rows(OUT/'knowledge/claim_evidence.jsonl'));units={u['unit_id']:u for u in rows(OUT/'case_reader/pilot/units.jsonl')}
    for d in rows(author/'fulltext_read_set.jsonl'):
        s=dict(file_id=d['file_id'],full_text=d['full_text'],source_sha256=d['source_sha256'],text_sha256=textsha(d['full_text']))
        if s['file_id'] in sources and sources[s['file_id']]!=s:raise ValueError('source reused with different bytes')
        sources[s['file_id']]=s
    newlinks=[]
    for selection in rows(author/'selected_cases.jsonl'):
        source=sources[selection['file_id']]
        for q in selection['quotes']:
            if source['full_text'][q['start']:q['end']]!=q['text'] or textsha(q['text'])!=q['text_sha256']:raise ValueError('expansion source span mismatch')
            sid='T10SPAN-'+canonical_sha([selection['selection_id'],q['quote_id'],q['start'],q['end'],q['text_sha256']])[:24]
            spans.append(dict(span_id=sid,file_id=selection['file_id'],start=q['start'],end=q['end'],text=q['text'],text_sha256=q['text_sha256'],
                source_sha256=source['source_sha256'],identity='historical_case_literal',coordinate_system='unicode_codepoints_half_open',
                actor_role=selection['actor_role'],attribution_limit=selection['attribution_limit'],
                current_business_fact_proof=False,human_approved=False,review_origin='current_session_model'))
            bindings=[b for b in selection['candidate_unit_bindings'] if q['quote_id'] in b['quote_ids']] or [None]
            for b in bindings:
                u=units[b['unit_id']] if b else None
                if u and (u['file_id']!=selection['file_id'] or u['source_sha256']!=source['source_sha256']):raise ValueError('expansion unit binding mismatch')
                link=dict(mechanism_id=selection['mechanism_id'],file_id=selection['file_id'],event_group_id=selection['event_group_id'],
                    span_id=sid,unit_id=b['unit_id'] if b else None,
                    evidence_role='support' if selection['support_kind']=='direct_pattern' else 'adjacent',support_limit=selection['support_limit'],
                    candidate_associations=copy.deepcopy(u.get('associations',[])) if u else [],
                    actor_role=selection['actor_role'],attribution_limit=selection['attribution_limit'],
                    binding_status='literal_unit_span_binding_not_independent_attribution' if b else 'source_span_only_no_matching_unit',
                    human_approved=False,review_origin='current_session_model',current_business_fact_proof=False)
                newlinks.append(link)
    links+=newlinks
    labels=[r['risk_tag'] for r in read(ROOT/'outputs/FinRisk_正式测试集V2_20261017/official_labels.json')]
    aids={a['article_id'] for a in rows(OUT/'legal/articles.jsonl')};spanids={s['span_id'] for s in spans}
    specs=read(author/'extension_specs.json')['mechanisms']
    for spec in specs:
        mid=spec['mechanism_id'];own=[l for l in newlinks if l['mechanism_id']==mid];predicates=[]
        for p0 in spec['predicates']:
            p=copy.deepcopy(p0);p['support_article_ids']=p.pop('article_ids')
            if not p['support_article_ids']:
                p.update(support_kind='current_input_fact_requirement',evidence_basis='current_input_or_independently_verified_material',normative_claim=False)
            else:p['support_kind']='article_text_with_scope_interpretation' if p['support_kind']=='原文' else 'assistant_interpretation_of_registered_articles'
            predicates.append(p)
            claims.append(dict(claim_id=p['predicate_id'],mechanism_id=mid,identity='assistant_screening_predicate',
                support_kind=p['support_kind'],support_article_ids=p['support_article_ids'],context_article_ids=p['context_article_ids'],
                support_explanation=p['support_explanation'],current_business_fact_proof=False,human_approved=False,review_origin='current_session_model'))
        card=dict(mechanism_id=mid,title=spec['title'],overview=spec['overview'],identity='assistant_authored_screening_guide',
            candidate_label_links=spec['candidate_label_links'],label_mapping_is_automatic=False,label_policy=spec['label_policy'],
            predicates=predicates,scope_axes=spec['scope_axes'],source_constraints=spec['source_constraints'],
            adjacent_mechanism_ids=ADJ[mid],article_ids=list(dict.fromkeys(spec['article_ids']+spec['context_article_ids'])),
            supporting_case_links=[l for l in own if l['evidence_role']=='support'],adjacent_case_links=[l for l in own if l['evidence_role']!='support'],
            facts_to_check=[p['predicate_id'] for p in predicates if p['required_for_risk']],cannot_infer=spec['cannot_infer'],
            coverage=dict(spec['coverage'],support_documents=len({l['file_id'] for l in own if l['evidence_role']=='support'})),
            current_input_facts_assessed=False,human_approved=False,review_origin='current_session_model',production_active=False)
        validate_card(card,aids,labels,spanids);cards.append(card)
    target=OUT/'expanded'
    for name,value in [('mechanisms',cards),('case_links',links),('source_spans',spans),('source_documents',list(sources.values())),('claim_evidence',claims)]:save(target/'knowledge'/f'{name}.jsonl',value,True)
    nav=build_navigation(cards,aids,set(units),spanids)
    save(target/'navigation/index.json',nav)
    for c in cards:
        d=target/'navigation/mechanisms'/c['mechanism_id'];d.mkdir(parents=True,exist_ok=False)
        (d/'abstract.md').write_text('# '+c['title']+'\n\n'+c['overview']+'\n',encoding='utf-8')
        text=['# '+c['title'],'',c['overview'],'','## 核查条件','']+['- '+p['predicate_id']+'：'+p['description'] for p in c['predicates']]
        text+=['','## 原文入口','']+['- '+s for s in nav['forward_links']['MECHANISM:'+c['mechanism_id']]]
        text+=['','## 限制','']+['- '+s for s in c['cannot_infer']]
        (d/'overview.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    coverage=[]
    for label in labels:
        matching=[c for c in cards if label in c['candidate_label_links']]
        coverage.append(dict(risk_tag=label,status='partial' if matching else 'uncovered_in_this_enhancement',
            mechanism_ids=[c['mechanism_id'] for c in matching],automatic_assignment=False,full_legal_boundary_coverage=False))
    save(target/'navigation/label_coverage.json',coverage)
    groups=read(OUT/'evaluation/group_split.json');pilot=[q for q in rows(OUT/'evaluation/queries.jsonl') if groups[q['query_id']]['split']=='development']
    smoke=list(rows(author/'smoke_queries.jsonl'));save(target/'regression/queries.jsonl',pilot+smoke,True)
    save(target/'regression/extension_expected.jsonl',list(rows(author/'smoke_expected.jsonl')),True)
    save(target/'regression/pilot_expected.jsonl',[r for r in rows(OUT/'private_reference/expected.jsonl') if groups[r['query_id']]['split']=='development'],True)
    # Range smoke verifies condition logic and reading; it is not an independent model accuracy measurement.
    checks=[]
    byid={c['mechanism_id']:c for c in cards}
    for r in rows(author/'smoke_expected.jsonl'):
        c=byid[r['mechanism_id']];states=[r['predicate_statuses'][p['predicate_id']] for p in c['predicates'] if p['required_for_risk']]
        actual='met' if all(s=='met' for s in states) else 'not_met' if 'not_met' in states else 'unknown'
        if actual!=r['mechanism_status']:raise ValueError('smoke condition/reference logic mismatch')
        checks.append(dict(query_id=r['query_id'],condition_logic_passed=True,purpose='scope_smoke_not_independent_model_accuracy'))
    save(target/'regression/smoke_receipt.json',dict(passed=True,total_inputs=36,extension_condition_checks=len(checks),pilot_inputs=12,model_accuracy_measured=False,checks=checks))
    save(target/'contracts/expansion_batches.json',dict(priority_order=[s['mechanism_id'] for s in specs],batches=[['M07','M08'],['M05','M06','M03'],['M09','M10','M12']],
        source_documents=len(sources),cap=144,all_eight_new_cards_partial=True,index_intervention_expanded=False,
        acceptance_sha256=sha(WORK/'expansion_review/final_acceptance.json')))
    files={p.relative_to(OUT).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(target.rglob('*')) if p.is_file()}
    save(target/'contracts/knowledge_manifest.json',dict(schema='finrisk-enhancement-knowledge-v1',enhancement_version='knowledge-organization-expanded-v1',
        base_versions=read(OUT/'case_reader/pilot_lock.json')['versions'],files=files,human_approved=False))
    lock=dict(manifest_sha256=sha(target/'contracts/knowledge_manifest.json'),version='knowledge-organization-expanded-v1')
    save(target/'contracts/knowledge_lock.json',lock)
    reader=KnowledgeFacade(OUT,read(OUT/'case_reader/pilot_lock.json'),profile='expanded',expected_knowledge_manifest_sha256=lock['manifest_sha256'])
    for mid in reader.cards:reader.read_mechanism(mid,level='L2')
    receipt=dict(passed=True,mechanisms=12,source_documents=len(sources),source_spans=len(spans),case_links=len(links),
        labels_partial=sum(l['status']=='partial' for l in coverage),labels_uncovered=sum(l['status']!='partial' for l in coverage),
        model_accuracy_measured=False,index_intervention_expanded=False,human_approved=False)
    save(OUT/'reports/expanded_readback.json',receipt);print(json.dumps(receipt))

if __name__=='__main__':build()
