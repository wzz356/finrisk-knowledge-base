"""Development-only representation experiment; fresh holdout requires a passing gate."""
import argparse
import re
from common import *
from freeze_inputs import verify_inputs
from api_jobs import validate_result,validate_job,body
from experiment_k import validate_split_rankings,RELEVANCE_SYSTEM
from eval_protocol import ranking_metrics

def rank():
    target=OUT/'experiment_R';verify_inputs(read(target/'retrieval_freeze.json')['sha256']);verify_inputs(read(target/'context_cache_binding.json')['sha256'])
    phase='R_development_rerank';folder=OUT/'api'/phase;completion=read(folder/'completion.json');jobs_path=OUT/'api_jobs'/f'{phase}.jsonl'
    if not completion['complete'] or sha(folder/'accepted.jsonl')!=completion['accepted_sha256'] or sha(jobs_path)!=completion['jobs_sha256']:raise ValueError('R score completeness/binding mismatch')
    jobs={j['pair_id']:j for j in rows(jobs_path)};accepted={r['pair_id']:r for r in rows(folder/'accepted.jsonl')}
    if set(jobs)!=set(accepted) or len(jobs)!=1200:raise ValueError('R scores missing')
    for pid,r in accepted.items():
        if r['base_payload_sha256']!=canonical_sha(jobs[pid]['body']):raise ValueError('R accepted score binding changed')
        validate_result(jobs[pid],r['parsed'])
    byquery={}
    for r in rows(target/'candidate_map.jsonl'):
        byquery.setdefault(r['query_id'],[]).append(dict(r,score=accepted[r['pair_id']]['parsed']['score']))
    ranks=[]
    for qid,candidates in byquery.items():
        seen=set();files=[]
        for r in sorted(candidates,key=lambda r:(-r['score'],r['unit_id'])):
            if r['file_id'] in seen:continue
            seen.add(r['file_id']);files.append(dict(r,rank=len(files)+1))
        ranks.append(dict(query_id=qid,ranking=files,score_count=100))
    validate_split_rankings(ranks,read(OUT/'evaluation/group_split.json'),'development')
    save(target/'rankings_development.jsonl',ranks,True)
    return ranks

def prepare_relevance():
    target=OUT/'experiment_R';ranks=list(rows(target/'rankings_development.jsonl'))
    known={(r['query_id'],r['file_id']) for r in rows(OUT/'experiment_K/qrels_development_effective.jsonl')}
    pairs=[(r['query_id'],h['file_id']) for r in ranks for h in r['ranking'][:20] if (r['query_id'],h['file_id']) not in known]
    if len(set(pairs))!=len(pairs):raise ValueError('duplicate R relevance pairs')
    fids={f for q,f in pairs};docs={d['official_file_id']:d for d in rows(V2/'normalized_final/data/documents.jsonl') if d['official_file_id'] in fids}
    queries={q['query_id']:q for q in rows(OUT/'evaluation/queries.jsonl')};jobs=[];mapping=[]
    for qid,fid in pairs:
        q=queries[qid];full=docs[fid]['full_text'];paragraphs=[]
        for i,m in enumerate(re.finditer(r'[^\n]+(?:\n|$)',full)):
            if m.group().strip():paragraphs.append(dict(span_id=f'P{i:04}',start=m.start(),end=m.end(),text=m.group()))
        pid='KOR_'+canonical_sha([q['text_sha256'],fid,textsha(full)])[:24]
        data=dict(pair_id=pid,current_text=q['text'],source_paragraphs=[{k:s[k] for k in ['span_id','text']} for s in paragraphs])
        job=dict(pair_id=pid,kind='relevance',packet=dict(span_ids=[s['span_id'] for s in paragraphs]),body=body(RELEVANCE_SYSTEM,data,512))
        validate_job(job);jobs.append(job);mapping.append(dict(pair_id=pid,query_id=qid,file_id=fid,source_text_sha256=textsha(full),paragraphs=paragraphs))
    phase='R_development_relevance';save(OUT/'api_jobs'/f'{phase}.jsonl',jobs,True)
    save(OUT/'api_jobs'/f'{phase}_freeze.json',dict(sha256={str(OUT/'api_jobs'/f'{phase}.jsonl'):sha(OUT/'api_jobs'/f'{phase}.jsonl')}))
    save(target/'relevance_map_development.jsonl',mapping,True)
    save(target/'reference_reuse_receipt.json',dict(new_pairs=len(jobs),existing_pairs=len(known),judgment_protocol_identical=True,unjudged_imputed_as_zero=False))
    return dict(new_relevance_jobs=len(jobs))

def collect_qrels():
    qrels=list(rows(OUT/'experiment_K/qrels_development_effective.jsonl'));target=OUT/'experiment_R'
    mapping={r['pair_id']:r for r in rows(target/'relevance_map_development.jsonl')}
    if mapping:
        phase='R_development_relevance';folder=OUT/'api'/phase
        if not read(folder/'completion.json')['complete']:raise ValueError('R blind relevance incomplete')
        for r in rows(folder/'accepted.jsonl'):
            m=mapping[r['pair_id']];p=r['parsed'];spans={s['span_id']:s for s in m['paragraphs']}
            qrels.append(dict(p,query_id=m['query_id'],file_id=m['file_id'],source_text_sha256=m['source_text_sha256'],source_spans=[spans[s] for s in p['evidence_span_ids']],review_origin='deepseek-flash_model_silver'))
    if len({(q['query_id'],q['file_id']) for q in qrels})!=len(qrels):raise ValueError('duplicate shared relevance reference')
    save(target/'qrels_development_shared.jsonl',qrels,True)
    return qrels

def evaluate(target=None):
    target=Path(target) if target is not None else OUT/'experiment_R'
    qrels=collect_qrels() if target==OUT/'experiment_R' else list(rows(OUT/'experiment_R/qrels_development_shared.jsonl'));grades={}
    for r in qrels:grades.setdefault(r['query_id'],{})[r['file_id']]=r['grade']
    base=list(rows(OUT/'experiment_K/rankings_development.jsonl'));new=list(rows(target/'rankings_development.jsonl'))
    per=[];summary={};legacy={}
    original=list(rows(OUT/'api/K_development_relevance/accepted.jsonl'));bind={r['pair_id']:r for r in rows(OUT/'experiment_K/relevance_map_development.jsonl')}
    for r in original:
        m=bind[r['pair_id']];legacy.setdefault(m['query_id'],{})[m['file_id']]=r['parsed']['grade']
    for arm,ranks in [('R0',base),('R1',new)]:
        for r in ranks:
            for k in [1,5,10,20]:per.append(dict(query_id=r['query_id'],arm=arm,K=k,**ranking_metrics([h['file_id'] for h in r['ranking']],grades[r['query_id']],k)))
        summary[arm]={}
        for k in [1,5,10,20]:
            part=[r for r in per if r['arm']==arm and r['K']==k]
            summary[arm][str(k)]={name:sum(r[name] for r in part if r[name] is not None)/sum(r[name] is not None for r in part) if any(r[name] is not None for r in part) else None for name in ['P','MRR','Top1','known_pool_recall','NDCG_pool']}
            summary[arm][str(k)]['valid_queries']=len(part)
    p0,p1=summary['R0'],summary['R1'];topdelta=round((p1['1']['Top1']-p0['1']['Top1'])*12)
    numeric_gate=p1['5']['P']+1e-12>=p0['5']['P'] and p1['20']['NDCG_pool']+1e-12>=p0['20']['NDCG_pool'] and (topdelta>=1 or p1['20']['MRR']-p0['20']['MRR']>=.03-1e-12)
    new_by={r['query_id']:r for r in new}
    changed=[dict(query_id=a['query_id'],top1_changed=a['ranking'][0]['file_id']!=new_by[a['query_id']]['ranking'][0]['file_id'],top20_files_changed=[h['file_id'] for h in a['ranking'][:20]]!=[h['file_id'] for h in new_by[a['query_id']]['ranking'][:20]]) for a in base]
    save(target/'per_query_metrics.jsonl',per,True)
    save(target/'metrics.json',dict(schema='finrisk-R-development-metrics-v1',queries=12,story_groups=4,summary=summary,
        numeric_gate_passed=numeric_gate,adoption_gate_passed=False if not numeric_gate else None,
        role_error_review='not_needed_for_failed_numeric_gate' if not numeric_gate else 'pending_independent_review',
        default_contextual_representation_enabled=False,new_holdout_required=bool(numeric_gate),
        no_global_true_recall=True,reference='model_silver_shared_Top20_union',changes=changed,
        K_metadata_policy='first-valid 240; 87 flags repaired; 10 grades increased; compare legacy sensitivity separately'))
    print(json.dumps(dict(numeric_gate_passed=numeric_gate,top1_count_delta=topdelta,MRR_delta=p1['20']['MRR']-p0['20']['MRR'],new_holdout_required=bool(numeric_gate))))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['rank','relevance','evaluate']);a=p.parse_args()
    if a.action=='rank':print(json.dumps(dict(rankings=len(rank()))))
    elif a.action=='relevance':print(json.dumps(prepare_relevance()))
    else:evaluate()
