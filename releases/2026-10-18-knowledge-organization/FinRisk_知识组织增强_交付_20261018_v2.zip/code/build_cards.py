"""Assemble reviewed source evidence and interpretation guides; no query answers."""
import copy
from collections import Counter
from common import *
from mechanism_cards import validate_card

SELECTED_SHA='1524ab9f0d4cc71d2a884e1e78551493e09f61a7c0cf444e0f7d7b6a7cef67b8'
LEGAL_SHA='371863431348bc80f8bb1cbc707ca5eb672c2ea6149b1379674f3bbcd16409ca'
MIDS=['M11','M01','M02','M04']
ADJ={'M11':['M01','M02'], 'M01':['M02','M11'], 'M02':['M01','M11'], 'M04':['M05']}
SCOPE={
 'M11':dict(subject='保险销售人员与当事人；非销售人员书面受托另核',product='保险；万能险风险告知有专项限制',stage='订立合同有关文书及对应确认',exception='允许解释、展示、放大页面；不能由笼统授权推翻销售人员禁止'),
 'M01':dict(subject='销售辅导人员、实际投保人和保险公司回访人员须分开',product='保险；新型产品知悉项目按具体设计类型核',stage='合同后回访及其准备',exception='真实理解后按实回答不等于不实辅导；已知实际状态与指令冲突方可支持'),
 'M02':dict(subject='投保人、冒名答复者与仅负责转接人员分别登记',product='保险；万能险知悉项目另核',stage='回访身份、知悉确认',exception='公开身份预约转接与冒名完成答复分开；透明代理是否允许仍须另核'),
 'M04':dict(subject='公司工作人员按116条，代理经纪主体按131条；对象为投保人/被保险人/受益人',product='保险',stage='与投保成交相联的承诺或给付',exception='真实合同约定给付不能因赠送措辞变合同外利益；材料缺失保留unknown')}
PREFS={
 'M11.contract_confirmation':['L002-A0029','L002-A0033'],
 'M11.salesperson_substitution':['L002-A0029','L005-A0017'],
 'M11.personal_record_falsified':[],
 'M01.review_context':['L002-A0035','L005-A0016'],
 'M01.false_answer_instruction':['L002-A0035','L005-A0011','L005-A0025'],
 'M02.identity_review':['L002-A0035'],
 'M02.impersonation':['L002-A0035'],
 'M04.covered_recipient':['L001-A0116','L001-A0131'],
 'M04.transaction_offer':['L001-A0116','L001-A0131'],
 'M04.outside_contract':['L001-A0116','L001-A0131']}

def build():
    selected_path=WORK/'source_analysis/selected_cases.jsonl'
    if sha(selected_path)!=SELECTED_SHA:raise ValueError('source analysis not frozen')
    selected=list(rows(selected_path)); wanted={r['file_id'] for r in selected}
    if len(selected)!=48 or len(wanted)!=48:raise ValueError('source pilot must have 48 unique documents')
    docs={r['official_file_id']:r for r in rows(V2/'normalized_final/data/documents.jsonl') if r['official_file_id'] in wanted}
    spans=[];links=[];seen=set();source_docs=[]
    for record in selected:
        doc=docs[record['file_id']];full=doc['full_text']
        if textsha(full)!=record['text_sha256'] or len(full)!=record['full_document_characters_read']:
            raise ValueError('source text/read proof changed')
        source_docs.append(dict(file_id=record['file_id'],full_text=full,text_sha256=textsha(full),source_sha256=doc['source_sha256']))
        for quote in record['evidence_quotes']:
            start,end=quote['start'],quote['end'];text=quote['text']
            if type(start) is not int or type(end) is not int or not 0<=start<end<=len(full) or full[start:end]!=text or textsha(text)!=quote['quote_sha256']:
                raise ValueError('invalid exact source quotation')
            span_id='KOSPAN-'+canonical_sha([record['file_id'],start,end,text])[:24]
            if span_id in seen:raise ValueError('duplicate source span')
            seen.add(span_id)
            span=dict(span_id=span_id,file_id=record['file_id'],start=start,end=end,text=text,text_sha256=textsha(text),
                source_sha256=doc['source_sha256'],identity='historical_case_literal',coordinate_system='unicode_codepoints_half_open',
                actor_role=quote['actor_role'],attribution_limit=quote['attribution_limit'],
                all_identical_text_positions=quote['all_identical_text_positions'],current_business_fact_proof=False,
                human_approved=False,review_origin='current_session_model')
            spans.append(span)
            bindings=quote['candidate_unit_links'] or [None]
            for binding in bindings:
                link=dict(mechanism_id=quote['mechanism_id'],file_id=record['file_id'],event_group_id=record['event_group_id'],
                    span_id=span_id,evidence_role=quote['evidence_role'],selection_role=record['selection_role'],
                    unit_id=binding['unit_id'] if binding else None,
                    candidate_associations=copy.deepcopy(binding['associations']) if binding else [],
                    binding_status=binding['binding_status'] if binding else 'source_span_only_no_matching_unit',
                    actor_role=quote['actor_role'],attribution_limit=quote['attribution_limit'],
                    current_business_fact_proof=False,human_approved=False,review_origin='current_session_model')
                links.append(link)
    rules=read(BASE/'law_review/operational_rules_overlay.json')
    aids={a['article_id'] for a in rows(OUT/'legal/articles.jsonl')}
    labels=read(ROOT/'outputs/FinRisk_正式测试集V2_20261017/official_labels.json')
    if isinstance(labels,dict):labels=labels.get('labels',labels.get('official_labels',[]))
    if labels and isinstance(labels[0],dict):labels=[x['risk_tag'] for x in labels]
    cards=[];claims=[]
    for mid in MIDS:
        rule=next(r for r in rules if r['mechanism_id']==mid)
        own=[l for l in links if l['mechanism_id']==mid]
        support=[l for l in own if l['evidence_role']=='support']
        adjacent=[l for l in own if l['evidence_role']!='support']
        supporting_files={l['file_id'] for l in support}
        target=8 if mid in ['M01','M02'] else 16
        predicates=copy.deepcopy(rule['predicates'])
        for p in predicates:
            p['support_article_ids']=PREFS[p['predicate_id']]
            p['context_article_ids']=['L005-A0016'] if mid=='M02' else []
            p['support_kind']='assistant_interpretation_of_registered_articles' if mid=='M01' else ('case_pattern_optional_fact' if not p['support_article_ids'] else 'article_text_with_scope_interpretation')
            p['current_fact_status']='not_assessed'
            claims.append(dict(claim_id=p['predicate_id'],mechanism_id=mid,identity='assistant_screening_predicate',
                support_kind=p['support_kind'],support_article_ids=p['support_article_ids'],context_article_ids=p['context_article_ids'],
                supporting_span_ids=sorted({l['span_id'] for l in support}),case_support_is_mechanism_level_not_independent_predicate_proof=True,
                current_business_fact_proof=False,human_approved=False,review_origin='current_session_model'))
        scope=dict(SCOPE[mid],behavior_date='由当前输入独立核查，不从历史案例日期补入',rule_version='按来源注册的版本、截止日和待核状态读取；不自动推定现行或历史适用')
        card=dict(mechanism_id=mid,title=rule['title'],overview=rule['boundary'],
            identity='assistant_authored_screening_guide',candidate_label_links=rule['candidate_label_links'],
            label_mapping_is_automatic=False,label_policy=rule.get('label_policy_overlay','候选标签仅作检索提示，须独立核查当前事实；不是违法概率。'),
            predicates=predicates,scope_axes=scope,adjacent_mechanism_ids=ADJ[mid],article_ids=rule['article_refs'],
            supporting_case_links=support,adjacent_case_links=adjacent,
            facts_to_check=[p['predicate_id'] for p in predicates if p['required_for_risk']],
            cannot_infer=[rule['boundary'],'历史案例事实不能补足当前输入；unknown不等于not_met；排除一个机制不等于全面合规。',
                '机构、责任人员、直接实施者分开；候选关联只作定位，不单独证明归责。','法规全文快照不是原始HTTP字节；所有来源尚未生产准入。'],
            coverage=dict(status='partial' if len(supporting_files)<target or mid=='M01' else 'pilot_target_met',
                support_documents=len(supporting_files),planned_support_documents=target,
                support_event_groups=len({l['event_group_id'] for l in support}),
                all_mechanism_cases_exhaustive=False,normative_support='interpretive_screening' if mid=='M01' else 'registered_articles_with_scope_limits'),
            current_input_facts_assessed=False,human_approved=False,review_origin='current_session_model',production_active=False)
        validate_card(card,aids,labels,seen);cards.append(card)
    for name,value in [('mechanisms',cards),('case_links',links),('source_spans',spans),('source_documents',source_docs),('claim_evidence',claims)]:save(OUT/'knowledge'/f'{name}.jsonl',value,True)
    save(OUT/'knowledge/build_receipt.json',dict(passed=True,source_analysis_sha256=SELECTED_SHA,legal_manifest_sha256=LEGAL_SHA,
        documents=48,event_groups=len({r['event_group_id'] for r in selected}),spans=len(spans),case_links=len(links),
        unique_units=len({l['unit_id'] for l in links if l['unit_id']}),source_only_spans=sum(not q['candidate_unit_links'] for r in selected for q in r['evidence_quotes']),
        coverage={c['mechanism_id']:c['coverage'] for c in cards},human_approved=False))
    return cards

if __name__=='__main__':print(json.dumps([dict(mechanism=c['mechanism_id'],coverage=c['coverage']) for c in build()],ensure_ascii=False))
