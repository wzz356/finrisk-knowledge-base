"""T09 dependency impacts and staging only. This module never activates a release."""
import argparse
import copy
import hashlib
import json
import re
from collections import deque
from pathlib import Path, PurePosixPath

from common import OUT, canonical_sha, rows, save, sha


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _path(root, relative):
    _require(isinstance(relative, str) and relative and '\\' not in relative and ':' not in relative,
             'portable relative input path required')
    parsed = PurePosixPath(relative)
    target = (Path(root) / relative).resolve()
    _require(not parsed.is_absolute() and '..' not in parsed.parts and target.is_relative_to(Path(root).resolve()),
             'input path escapes root')
    return target


def _observe(root, spec, cache):
    path = _path(root, spec['path'])
    if spec['path'] not in cache:
        raw = path.read_bytes()
        cache[spec['path']] = {'sha256': hashlib.sha256(raw).hexdigest(), 'raw': raw, 'indexes': {}}
    saved = cache[spec['path']]
    if 'record_key' in spec:
        key = spec['record_key']
        if key not in saved['indexes']:
            records = [json.loads(line) for line in saved['raw'].decode('utf-8-sig').splitlines() if line.strip()]
            index = {r[key]: r for r in records}
            _require(len(index) == len(records), 'duplicate input record ID')
            saved['indexes'][key] = index
        _require(spec['record_id'] in saved['indexes'][key], 'input record is missing')
        value = saved['indexes'][key][spec['record_id']]
        fields = spec.get('fields')
        value = {k: value[k] for k in fields} if fields is not None else {
            k: v for k, v in value.items() if k not in spec.get('exclude_fields', [])}
    else:
        value = {'saved_file_sha256': saved['sha256']}
    return {'input_sha256': canonical_sha(value), 'input_file_sha256': saved['sha256'], 'value': value}


class DependencyGraph:
    def __init__(self, nodes):
        self.nodes = copy.deepcopy(list(nodes))
        self.by_id = {n['node_id']: n for n in self.nodes}
        _require(len(self.by_id) == len(self.nodes), 'duplicate dependency node')
        self.dependents = {identity: [] for identity in self.by_id}
        counts = {}
        for node in self.nodes:
            identity, deps = node['node_id'], node['dependencies']
            _require(isinstance(identity, str) and identity and isinstance(deps, list)
                     and len(deps) == len(set(deps)), 'invalid dependency IDs')
            counts[identity] = len(deps)
            for dep in deps:
                _require(dep in self.by_id, 'missing dependency node: ' + dep)
                self.dependents[dep].append(identity)
            if node.get('input') is not None:
                _path(Path.cwd(), node['input']['path'])
                for key in ['input_sha256', 'input_file_sha256']:
                    _require(isinstance(node.get(key), str) and re.fullmatch('[0-9a-f]{64}', node[key]), 'invalid input SHA256')
        pending = deque(n for n in counts if counts[n] == 0)
        self.order = []
        while pending:
            current = pending.popleft()
            self.order.append(current)
            for dependent in self.dependents[current]:
                counts[dependent] -= 1
                if counts[dependent] == 0:
                    pending.append(dependent)
        _require(len(self.order) == len(self.nodes), 'dependency cycle detected')

    @classmethod
    def snapshot(cls, root, specs):
        nodes, cache = copy.deepcopy(list(specs)), {}
        for node in nodes:
            if node.get('input') is not None:
                node.update({k: v for k, v in _observe(root, node['input'], cache).items() if k != 'value'})
        return cls(nodes)

    def verify_inputs(self, root):
        cache = {}
        for node in self.nodes:
            if node.get('input') is not None:
                observed = _observe(root, node['input'], cache)
                _require(all(observed[k] == node[k] for k in ['input_sha256', 'input_file_sha256']),
                         'input SHA256 mismatch: ' + node['node_id'])
        return True

    def closure(self, changed):
        _require(isinstance(changed, (list, tuple)) and len(changed) == len(set(changed)), 'unique changed IDs required')
        _require(all(n in self.by_id for n in changed), 'unknown changed node')
        visited, pending = set(changed), deque(changed)
        while pending:
            for dependent in self.dependents[pending.popleft()]:
                if dependent not in visited:
                    visited.add(dependent)
                    pending.append(dependent)
        return [n for n in self.order if n in visited]

    def impact(self, root):
        cache, changed, errors, physical_only = {}, [], {}, []
        for node in self.nodes:
            if node.get('input') is None:
                continue
            try:
                observed = _observe(root, node['input'], cache)
                if observed['input_sha256'] != node['input_sha256']:
                    changed.append(node['node_id'])
                elif observed['input_file_sha256'] != node['input_file_sha256']:
                    physical_only.append(node['node_id'])
            except (OSError, ValueError, KeyError) as exc:
                changed.append(node['node_id'])
                errors[node['node_id']] = str(exc)
        affected = self.closure(changed)
        direct = {target for origin in changed for target in self.dependents[origin]} - set(changed)
        return {'changed': changed, 'direct_affected': [n for n in self.order if n in direct],
                'affected': affected, 'topological_order': affected,
                'metadata_only': bool(changed) and all(self.by_id[n]['kind'] == 'metadata' for n in changed),
                'index_rebuild_required': any(self.by_id[n]['kind'] in {'bm25_index', 'embedding', 'contextual_embedding'} for n in affected),
                'pending_nodes': [n for n in affected if self.by_id[n]['status'] == 'pending'],
                'physical_file_changed_but_projection_unchanged': physical_only, 'observation_errors': errors}


def rebuild_affected(graph, root, stage, builders=None):
    """Stage input projections and explicit builders; absent computation stays pending."""
    stage, root, builders = Path(stage), Path(root).resolve(), builders or {}
    stage.mkdir(parents=True, exist_ok=False)
    impact = graph.impact(root)
    built, pending, failed, outputs, cache = [], [], {}, {}, {}
    input_paths = {n['input']['path'] for n in graph.nodes if n.get('input') is not None}
    before = {p: sha(_path(root, p)) for p in sorted(input_paths) if _path(root, p).is_file()}
    for position, identity in enumerate(impact['topological_order']):
        node = graph.by_id[identity]
        builder = builders.get(node['kind'])
        if node['kind'] in {'embedding', 'contextual_embedding', 'bm25_index'}:
            pending.append(identity)
            continue
        if any(d in failed or d in pending for d in node['dependencies']):
            pending.append(identity)
            continue
        try:
            if builder is not None:
                value = builder(copy.deepcopy(node), {'root': root, 'stage': stage, 'dependency_outputs': copy.deepcopy(outputs)})
                _require(value is not None, 'builder must return a concrete JSON payload')
            elif node.get('input') is not None:
                value = {'node_id': identity, 'stage_kind': 'input_projection_only', **_observe(root, node['input'], cache)}
            else:
                pending.append(identity)
                continue
            target = stage / 'payloads' / f'{position:06}.json'
            save(target, value)
            outputs[identity] = {'path': target.relative_to(stage).as_posix(), 'sha256': sha(target)}
            built.append(identity)
        except Exception as exc:
            failed[identity] = type(exc).__name__ + ': ' + str(exc)
    after = {p: sha(_path(root, p)) if _path(root, p).is_file() else None for p in before}
    if before != after:
        failed['__inputs__'] = 'inputs changed during staging'
    receipt = {'status': 'failed' if failed else ('pending' if pending else 'staged'), 'built': built,
        'pending': pending, 'failed': failed, 'outputs': outputs, 'impact': impact,
        'input_files_before': before, 'input_files_after': after, 'activation_allowed': False,
        'activation_blockers': (['failed_build'] if failed else []) + (['pending_computation_or_review'] if pending else []) + ['staging_only_T07_release_gate_not_executed'],
        'embedding_recomputed': False, 'bm25_recomputed': False,
        'human_approved': False, 'review_origin': 'current_session_model'}
    save(stage / 'receipt.json', receipt)
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['impact', 'rebuild-affected'])
    parser.add_argument('--graph', type=Path, default=OUT / 'maintenance/dependencies.jsonl')
    parser.add_argument('--root', type=Path, default=OUT)
    parser.add_argument('--stage', type=Path)
    args = parser.parse_args(argv)
    graph = DependencyGraph(rows(args.graph))
    _require(args.command != 'rebuild-affected' or args.stage is not None, '--stage is required for rebuild-affected')
    result = graph.impact(args.root) if args.command == 'impact' else rebuild_affected(graph, args.root, args.stage)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == '__main__':
    main()
