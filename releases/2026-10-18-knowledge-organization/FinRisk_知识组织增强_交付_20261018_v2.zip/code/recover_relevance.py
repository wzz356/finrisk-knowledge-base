"""Uniform first-valid semantic response; missing human-review flag is program metadata."""
from common import *
from api_jobs import validate_result

def recover(split):
    phase='K_'+split+'_relevance';jobs={j['pair_id']:j for j in rows(OUT/'api_jobs'/f'{phase}.jsonl')}
    records=list(rows(OUT/'api'/phase/'records.jsonl'))
    accepted={r['pair_id']:r['parsed'] for r in rows(OUT/'api'/phase/'accepted.jsonl')}
    effective={};audits=[]
    for r in sorted(records,key=lambda r:(r['attempt'],r['utc'])):
        if r['pair_id'] in effective:continue
        response=r.get('response')
        if not response or response.get('model') not in ['deepseek-flash','deepseek-v4.1-flash']:continue
        try:
            if response['choices'][0]['finish_reason']!='stop':continue
            value=json.loads(response['choices'][0]['message']['content']);parsed=validate_result(jobs[r['pair_id']],value)
        except (ValueError,KeyError,TypeError):continue
        effective[r['pair_id']]=dict(parsed,first_valid_attempt=r['attempt'],source_record_utc=r['utc'],
            review_origin='deepseek-flash_model_silver',response_selection='earliest_semantically_schema_valid_response_not_highest_grade')
        old=accepted.get(r['pair_id'])
        audits.append(dict(pair_id=r['pair_id'],selected_attempt=r['attempt'],model_human_flag_missing='human_approved' not in value,
            old_grade=old['grade'] if old else None,new_grade=parsed['grade'],grade_changed=bool(old and old['grade']!=parsed['grade'])))
    mapping={r['pair_id']:r for r in rows(OUT/'experiment_K'/f'relevance_map_{split}.jsonl')}
    final=[]
    for pid,value in effective.items():
        m=mapping[pid];registry={s['span_id']:s for s in m['paragraphs']}
        final.append(dict(value,query_id=m['query_id'],file_id=m['file_id'],source_text_sha256=m['source_text_sha256'],
            source_spans=[registry[s] for s in value['evidence_span_ids']]))
    save(OUT/'experiment_K'/f'qrels_{split}_effective.jsonl',final,True)
    save(OUT/'experiment_K'/f'qrels_{split}_metadata_audit.jsonl',audits,True)
    receipt=dict(total=len(jobs),effective=len(final),missing=sorted(set(jobs)-set(effective)),
        program_metadata_recovered=sum(a['model_human_flag_missing'] for a in audits),
        grades_changed_from_later_original_acceptance=sum(a['grade_changed'] for a in audits),
        no_new_paid_calls=True,selection_policy='uniform_first_valid_response; no ranking/reference visibility',
        original_records_and_later_accepted_preserved=True,human_approved=False)
    save(OUT/'experiment_K'/f'qrels_{split}_recovery_receipt.json',receipt)
    return receipt

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--split',choices=['development','holdout'],default='development');print(json.dumps(recover(p.parse_args().split)))
