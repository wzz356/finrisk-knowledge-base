"""Current-fact provenance guard, separate from historical and normative evidence."""
from legal_registry import checked_slice

def require_current_fact(fact,current_text):
    if fact.get('origin')!='current_input':raise ValueError('only current input can establish current facts')
    quote=checked_slice(current_text,fact.get('start'),fact.get('end'))
    if quote!=fact.get('quote'):raise ValueError('current fact quote mismatch')
    return dict(fact)
