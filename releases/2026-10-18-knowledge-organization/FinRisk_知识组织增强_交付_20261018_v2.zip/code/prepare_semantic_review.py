"""Blind result review receives cited evidence only, no arm/rank/reference answers."""
import argparse
import copy
from common import *
from knowledge_facade import KnowledgeFacade

def main(split):
    phase='K_'+split+'_judgment';jobs={j['pair_id']:j for j in rows(OUT/'api_jobs'/f'{phase}.jsonl')}
    results=list(rows(OUT/'api'/phase/'accepted.jsonl'));mapping={m['pair_id']:m for m in rows(OUT/'experiment_K'/f'judgment_map_{split}.jsonl')}
    reader=KnowledgeFacade(OUT,read(OUT/'case_reader'/f'{split}_lock.json'),expected_knowledge_manifest_sha256=read(OUT/'contracts/knowledge_lock.json')['manifest_sha256'])
    inputs=[];private=[]
    for n,r in enumerate(sorted(results,key=lambda r:textsha(r['pair_id'])),1):
        anonymous='DEC-'+split[0].upper()+f'{n:03}';pid=r['pair_id'];job=jobs[pid];data=json.loads(job['body']['messages'][1]['content']);decision=copy.deepcopy(r['parsed']);decision.pop('pair_id')
        cases=[];laws=[]
        for uid in decision['case_unit_ids']:
            record=reader.read_case(uid)
            if record['text'] not in data['cases']:raise ValueError('cited case not actually supplied')
            cases.append(dict(unit_id=uid,text=record['text']))
        for aid in decision['legal_article_ids']:
            article=reader.legal.articles[aid];source=reader.legal.sources[article['source_id']]
            if article['text'] not in data['laws_and_guides']:raise ValueError('cited legal text not actually supplied')
            laws.append(dict(article_id=aid,text=article['text'],version=source['version'],current_validity=source['axes']['current_validity'],production_active=False))
        inputs.append(dict(decision_id=anonymous,current_text=data['current_text'],required_by_mechanism=job['packet']['required_by_mechanism'],
            decision=decision,cited_cases=cases,cited_laws=laws,declared_coverage=data['coverage'],model_inputs_do_not_include_reference_answers=True))
        private.append(dict(decision_id=anonymous,pair_id=pid,query_id=mapping[pid]['query_id'],arm=mapping[pid]['arm']))
    save(WORK/'semantic_review'/f'{split}_blind.jsonl',inputs,True)
    save(OUT/'evaluation'/f'semantic_review_mapping_{split}.jsonl',private,True)
    print(json.dumps(dict(split=split,decisions=len(inputs),reference_or_ranking_fields_supplied=False)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--split',choices=['development','holdout'],default='development');main(p.parse_args().split)
