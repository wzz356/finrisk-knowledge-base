"""Input-only BM25+BGE -> equal-weight RRF100 on all 9639 documents."""
import importlib.util
import sys
import time
from collections import defaultdict
from common import *
from freeze_inputs import verify_inputs

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    started=time.perf_counter();verify_inputs(read(OUT/'contracts/input_freeze.json')['sha256'])
    verify_inputs(read(OUT/'evaluation/query_freeze.json')['sha256'])
    target=OUT/'experiment_R';target.mkdir(exist_ok=False)
    groups=read(OUT/'evaluation/group_split.json'); queries=[q for q in rows(OUT/'evaluation/queries.jsonl') if groups[q['query_id']]['split']=='development']
    if len(queries)!=12 or any(set(q)!={'query_id','text','text_sha256'} or textsha(q['text'])!=q['text_sha256'] for q in queries):raise ValueError('exactly 12 development input-only queries required')
    cfg=read(ROOT/'outputs/FinRisk_召回率校准_20261013/retrieval_results.jsonl.run.json')
    sys.path.insert(0,str(ROOT/'work/finrisk_regulation_v1'))
    from law_index import Encoder,PROJECT,MODEL
    runner_path=ROOT/'work/finrisk_retrieval_20261012/runner.py'
    if sha(runner_path)!=cfg['runner_sha256']:raise ValueError('runner changed')
    for filename,key in [('sparse.py','bm25_source_sha256'),('tokenization.py','tokenizer_source_sha256')]:
        if sha(PROJECT/'retrieval'/filename)!=cfg[key]:raise ValueError('sparse implementation changed')
    runner=module('knowledge_validated_runner',runner_path)
    index=V2/'indexes/all9639_final/structured.jsonl'
    manifest=read(index.parent/'manifest.json')
    if sha(index)!=manifest['corpora']['structured']['sha256']:raise ValueError('index changed')
    units=[{k:u[k] for k in ['unit_id','file_id','case_id','text']} for u in rows(index)]
    if len(units)!=65475 or len({u['file_id'] for u in units})!=9639:raise ValueError('not full corpus')
    cache_dir=ROOT/'work/finrisk_recall_calibration_20261013/vector_cache'
    caches=[(p,read(p)) for p in cache_dir.glob('*.json')]
    caches=[(p,m) for p,m in caches if m.get('shape')==[65475,512]]
    if len(caches)!=1:raise ValueError('ambiguous vector cache')
    cache,meta=caches[0];vector_path=cache.with_suffix('.npy');vector_hash=sha(vector_path)
    if meta['npy_sha256']!=vector_hash or meta['ordered_unit_text_sha256']!=runner.ordered_text_sha(units):raise ValueError('vectors not bound to index')
    encoder=Encoder()
    if meta['binding']['model']!=runner.model_fingerprint(MODEL) or meta['binding']['torch']!=encoder.torch.__version__:raise ValueError('model/runtime changed')
    import numpy as np
    vectors=np.load(vector_path,allow_pickle=False,mmap_mode='r')
    if vectors.flags.writeable or vectors.shape!=(65475,512):raise ValueError('read-only vector matrix required')
    overlays=list(rows(OUT/'context/representation_overlay.jsonl')); positions={u['unit_id']:i for i,u in enumerate(units)}; active=[]; excluded=[]
    for item in overlays:
        if item['unit_id'] not in positions or textsha(units[positions[item['unit_id']]]['text'])!=item['original_text_sha256']:raise ValueError('overlay original binding mismatch')
        n=len(encoder.tokenizer(item['representation_text'],truncation=False)['input_ids'])
        if n>512:excluded.append(dict(unit_id=item['unit_id'],tokens=n,reason='refuse hidden truncation'))
        else:active.append(item)
    if not active:raise ValueError('no eligible contextual representations')
    replacement=encoder.encode([r['representation_text'] for r in active],'document',[r['unit_id'] for r in active])
    np.save(target/'context_vectors.npy',replacement,allow_pickle=False)
    overlay_text={r['unit_id']:r['representation_text'] for r in active}
    save(target/'context_token_exclusions.json',excluded)
    qvectors=encoder.encode([q['text'] for q in queries],'query',[q['query_id'] for q in queries])
    np.save(target/'query_vectors.npy',qvectors,allow_pickle=False)
    sys.path.insert(0,str(PROJECT))
    from retrieval.sparse import SparseRetrievalIndex,RetrievalDocument
    sparse=SparseRetrievalIndex([RetrievalDocument(unit_id=u['unit_id'],case_ids=(u['case_id'],),text=overlay_text.get(u['unit_id'],u['text']),source='structured') for u in units],k1=1.5,b=.75)
    routes=[]
    for i,q in enumerate(queries):
        bm=[dict(unit_id=h.document.unit_id,score=float(h.score),rank=h.rank) for h in sparse.search(q['text'],top_k=100)]
        scores=vectors@qvectors[i]
        for j,item in enumerate(active):scores[positions[item['unit_id']]]=float(replacement[j]@qvectors[i])
        order=np.lexsort((np.arange(len(scores)),-scores))[:100]
        dense=[dict(unit_id=units[int(j)]['unit_id'],score=float(scores[j]),rank=k) for k,j in enumerate(order,1)]
        fused=runner.rrf([bm,dense],k=60,top_k=100)
        if len(fused)!=100:raise ValueError('not 100 candidates')
        routes.append(dict(query_id=q['query_id'],BM25=bm,BGE=dense,RRF=fused))
        print(json.dumps(dict(retrieved=i+1,total=12)),flush=True)
    del sparse
    wanted={h['unit_id'] for r in routes for h in r['RRF']};fileids={u['file_id'] for u in units if u['unit_id'] in wanted};del units
    sourceunits=[u for u in rows(index) if u['file_id'] in fileids]
    byid={u['unit_id']:u for u in sourceunits};byfile=defaultdict(list)
    for u in sourceunits:byfile[u['file_id']].append(u)
    sys.path.insert(0,str(ROOT/'work/finrisk_two_layer_validation_20261017'))
    from context_builder import build_context
    packets=[];mapping=[];contexts={}
    for q,r in zip(queries,routes):
        for hit in r['RRF']:
            uid=hit['unit_id'];u=byid[uid]
            if uid not in contexts:contexts[uid]=build_context(u,byfile[u['file_id']],limit=800)
            context=contexts[uid];text=context['unit_text'];binding=(q['query_id'],uid,textsha(text))
            pair_id='KO_'+textsha('|'.join(binding))[:24]
            packets.append(dict(pair_id=pair_id,query_text=q['text'],query_text_sha256=q['text_sha256'],unit_text=text,unit_text_sha256=textsha(text)))
            mapping.append(dict(pair_id=pair_id,query_id=q['query_id'],unit_id=uid,file_id=u['file_id'],rrf_rank=hit['rank'],unit_text_sha256=textsha(text),segments=context['segments']))
    if len(packets)!=1200 or len({p['pair_id'] for p in packets})!=1200:raise ValueError('task binding conflict')
    save(target/'routes.jsonl',routes,True);save(target/'rerank_inputs.jsonl',packets,True);save(target/'candidate_map.jsonl',mapping,True)
    save(target/'query_token_audit.jsonl',encoder.audit,True)
    rules=ROOT/'outputs/FinRisk_机制与片段消融_20261016/mechanism_rules.md'
    (target/'rerank_rules.md').write_bytes(rules.read_bytes())
    save(target/'retrieval_receipt.json',dict(passed=True,seconds=time.perf_counter()-started,queries=12,documents=9639,units=65475,
        candidates_per_query=100,rerank_scores_required=1200,weights=[1,1],rrf_c=60,auxiliary_route_enabled=False,
        answers_read=False,document_vectors_recomputed=len(active),candidate_original_vectors_changed=False,excluded_context_units=len(excluded),new_paid_calls=0,global_true_recall=False))
    paths=[target/n for n in ['routes.jsonl','rerank_inputs.jsonl','candidate_map.jsonl','query_vectors.npy','rerank_rules.md']]
    paths+=[WORK/'retrieve_r.py',OUT/'context/representation_overlay.jsonl',index,vector_path,PROJECT/'retrieval/sparse.py',PROJECT/'retrieval/tokenization.py']
    save(target/'retrieval_freeze.json',dict(utc=utc(),sha256={str(p):sha(p) for p in paths}))
    if sha(vector_path)!=vector_hash:raise ValueError('protected vector changed')
    print(json.dumps(dict(status='complete',scores_required=1200)),flush=True)

if __name__=='__main__':main()
