"""Validate source-linked screening guides, without classifying a current query."""
def validate_card(card,article_ids,official_labels,span_ids):
    if (card.get('identity')!='assistant_authored_screening_guide' or card.get('human_approved') is not False or
        card.get('review_origin')!='current_session_model' or card.get('label_mapping_is_automatic') is not False):
        raise ValueError('candidate guide/review identity mismatch')
    predicates=card['predicates'];required=[p for p in predicates if p.get('required_for_risk')]
    if not required or len({p['predicate_id'] for p in predicates})!=len(predicates):raise ValueError('required predicates missing or duplicated')
    if not set(card['candidate_label_links'])<=set(official_labels):raise ValueError('unregistered official label')
    if not card['article_ids'] or not set(card['article_ids'])<=set(article_ids):raise ValueError('unregistered legal basis')
    for p in predicates:
        if not p.get('description') or not set(p.get('support_article_ids',[]))<=set(article_ids):raise ValueError('invalid predicate legal support')
        fact_only=(p.get('support_kind')=='current_input_fact_requirement' and p.get('evidence_basis')=='current_input_or_independently_verified_material' and p.get('normative_claim') is False)
        if p.get('required_for_risk') and ((not p.get('support_article_ids') and not fact_only) or not p.get('support_kind')):
            raise ValueError('required normative assertion lacks source or interpretation identity')
    if not {p['predicate_id'] for p in required}<=set(card['facts_to_check']):raise ValueError('fact checklist incomplete')
    links=card['supporting_case_links']+card['adjacent_case_links']
    if any(link['span_id'] not in span_ids for link in links):raise ValueError('unregistered case quotation')
    supporting_files={link['file_id'] for link in card['supporting_case_links']}
    if len(supporting_files)<2 and card['coverage']['status']!='partial':raise ValueError('insufficient support must remain partial')
    if not card['cannot_infer']:raise ValueError('scope restrictions required')
    return True
