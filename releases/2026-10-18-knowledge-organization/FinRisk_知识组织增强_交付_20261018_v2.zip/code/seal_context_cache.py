"""Bind the actually computed R vectors to every representation and token audit."""
import ast
import struct
from common import *

def main():
    target=OUT/'experiment_R';vector=target/'context_vectors.npy'
    with vector.open('rb') as f:
        if f.read(8)!=b'\x93NUMPY\x01\x00':raise ValueError('expected safe NPY v1 matrix')
        length=struct.unpack('<H',f.read(2))[0];header=ast.literal_eval(f.read(length).decode('latin1'))
    representations=list(rows(OUT/'context/representation_overlay.jsonl'))
    audit=[r for r in rows(target/'query_token_audit.jsonl') if r['kind']=='document']
    if header['shape']!=(len(representations),512) or header['descr']!='<f4' or header['fortran_order']:raise ValueError('context matrix shape/type mismatch')
    if [r['id'] for r in audit]!=[r['unit_id'] for r in representations] or any(r['truncated'] or r['input_tokens']>512 for r in audit):raise ValueError('context vector audit incomplete')
    paths=[vector,target/'query_token_audit.jsonl',target/'query_vectors.npy',OUT/'context/representation_overlay.jsonl',OUT/'context/prefixes.jsonl',WORK/'retrieve_r.py']
    oldcache=[p for p in (ROOT/'work/finrisk_recall_calibration_20261013/vector_cache').glob('*.json') if read(p).get('shape')==[65475,512]]
    if len(oldcache)!=1:raise ValueError('ambiguous base embedding binding')
    record=dict(schema='finrisk-context-vector-binding-v1',model_runtime_binding=read(oldcache[0])['binding'],
        shape=list(header['shape']),dtype='float32',representations=[{k:r[k] for k in ['unit_id','representation_id','original_text_sha256','representation_sha256']} for r in representations],
        sha256={str(p):sha(p) for p in paths},original_vectors_modified=False,model_calls_replayed=False)
    save(target/'context_cache_binding.json',record);print(json.dumps(dict(context_vectors=len(audit),bound_files=len(paths))))

if __name__=='__main__':main()
