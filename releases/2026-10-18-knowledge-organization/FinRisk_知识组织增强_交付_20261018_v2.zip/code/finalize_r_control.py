"""Rebuild controlled R ranks from exact earlier API responses, with zero calls."""
from common import *
from api_jobs import rerank_job,validate_result
from freeze_inputs import verify_inputs
from experiment_k import validate_split_rankings
from experiment_r import evaluate

def main():
    target=OUT/'experiment_R_controlled'
    for name in ['retrieval_freeze.json','delta_freeze.json']:
        freeze=read(target/name);verify_inputs(freeze['input_sha256']);verify_inputs(freeze['output_sha256'])
    rules=(OUT/'experiment_R/rerank_rules.md').read_text(encoding='utf-8')
    cache={}
    for path in (OUT/'api').glob('*/records.jsonl'):
        for r in rows(path):
            if r['status']=='accepted' and r['kind']=='rerank':cache[(r['pair_id'],r['base_payload_sha256'])]=r
    scores={};audit=[]
    for p in rows(target/'rerank_inputs.jsonl'):
        job=rerank_job(p,rules);key=(p['pair_id'],canonical_sha(job['body']))
        if key not in cache:raise ValueError('controlled candidate lacks exact prior response')
        r=cache[key];parsed=validate_result(job,r['parsed']);scores[p['pair_id']]=parsed['score']
        audit.append(dict(pair_id=p['pair_id'],source_phase=r['phase'],reservation_id=r['reservation_id'],body_sha256=key[1],score=parsed['score'],new_API_call=False))
    grouped={}
    for r in rows(target/'candidate_map.jsonl'):grouped.setdefault(r['query_id'],[]).append(dict(r,score=scores[r['pair_id']]))
    ranks=[]
    for qid,candidates in grouped.items():
        if len(candidates)!=100:raise ValueError('controlled candidate count mismatch')
        seen=set();files=[]
        for r in sorted(candidates,key=lambda x:(-x['score'],x['unit_id'])):
            if r['file_id'] in seen:continue
            seen.add(r['file_id']);files.append(dict(r,rank=len(files)+1))
        ranks.append(dict(query_id=qid,ranking=files,score_count=100))
    validate_split_rankings(ranks,read(OUT/'evaluation/group_split.json'),'development')
    save(target/'cached_scores.jsonl',audit,True);save(target/'rankings_development.jsonl',ranks,True)
    save(target/'cache_replay_receipt.json',dict(passed=True,exact_cache_results=len(audit),new_API_calls=0,
        query_vector_source='original K matrix rows; byte-identical',old_R_rankings_copied=False,
        controlled_candidate_set_used=True,source_response_and_request_binding_verified=True))
    evaluate(target)

if __name__=='__main__':main()
