from common import *

def main():
    cards=list(rows(OUT/'knowledge/mechanisms.jsonl'));links=list(rows(OUT/'knowledge/case_links.jsonl'))
    labels=read(ROOT/'outputs/FinRisk_正式测试集V2_20261017/official_labels.json')
    result=[]
    for label in labels:
        matched=[c for c in cards if label['risk_tag'] in c['candidate_label_links']]
        result.append(dict(risk_tag=label['risk_tag'],status='partial' if matched else 'uncovered_in_this_enhancement',
            mechanism_ids=[c['mechanism_id'] for c in matched],automatic_assignment=False,
            reason='有机制卡和可回源材料；候选标签仍须独立事实，未证明完整法律边界/所有情形覆盖' if matched else '本轮四机制未提供足够独立规范与案例支持；旧库可检索不等于已完成边界审核'))
    report=dict(mechanisms=[dict(mechanism_id=c['mechanism_id'],material_scope=c['coverage'],
        required_predicates=[p['predicate_id'] for p in c['predicates'] if p['required_for_risk']],
        article_ids=c['article_ids'],pending_items=c['cannot_infer']) for c in cards],
        labels=result,material_inventory=dict(reviewed_documents=48,unique_events=45,literal_quotes=62,
            reviewed_candidate_units=78,full_corpus_documents=9639,full_corpus_structured_units=65475,
            full_corpus_review_completed=False),
        reading_dependencies=dict(total_registered_articles=67,all_articles_closure_readable=True,all_articles_supplied_in_every_budget=False),
        normative_applicability='current_input_not_assessed; version/product/subject/stage/date/exception independently required',
        budget_policy='whole blocks only; omissions explicit partial',human_approved=False,review_origin='current_session_model')
    save(OUT/'reports/navigation_coverage.json',report)
    return report

if __name__=='__main__':print(json.dumps(dict(labels=len(main()['labels'])),ensure_ascii=False))
