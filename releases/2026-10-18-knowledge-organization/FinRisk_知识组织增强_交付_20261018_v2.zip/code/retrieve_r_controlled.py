"""R numeric control: reuse K query bytes and R document overlays; no model/API calls."""
import sys, time, importlib.util
from collections import defaultdict
import numpy as np
from common import ROOT, WORK, OUT, V2, rows, read, save, sha, textsha, canonical_sha, utc


def require(condition,message):
    if not condition:raise ValueError(message)


def reuse_query_rows(queries,audit,vectors,desired_ids):
    ids=[q['query_id'] for q in queries]
    audit_ids=[a['id'] for a in audit if a['kind']=='query']
    require(ids==audit_ids,'K query order does not match saved query token audit')
    require(len(ids)==len(set(ids)) and len(desired_ids)==len(set(desired_ids)),'duplicate query ID')
    require(len(vectors)==len(ids),'K query matrix row count mismatch')
    require(all(q['text_sha256']==textsha(q['text']) for q in queries),'query text SHA mismatch')
    index={qid:i for i,qid in enumerate(ids)}
    require(all(qid in index for qid in desired_ids),'query ID absent from K matrix')
    output=vectors[[index[qid] for qid in desired_ids]].copy()
    bindings=[]
    for i,qid in enumerate(desired_ids):
        source=vectors[index[qid]]
        require(source.tobytes()==output[i].tobytes() and source.dtype==output.dtype,'query bytes changed')
        bindings.append(dict(query_id=qid,original_K_row=index[qid],controlled_row=i,
            query_text_sha256=queries[index[qid]]['text_sha256'],
            vector_bytes_sha256=__import__('hashlib').sha256(source.tobytes()).hexdigest(),
            byte_identical_to_K=True))
    return output,bindings


def compare_routes(old,new):
    before={r['query_id']:r for r in old};after={r['query_id']:r for r in new}
    require(set(before)==set(after) and len(before)==len(old) and len(after)==len(new),'route query IDs differ or duplicate')
    comparison=[]
    for row in new:
        qid=row['query_id'];result=dict(query_id=qid)
        for route in ['BM25','BGE','RRF']:
            a=before[qid][route];b=after[qid][route]
            ai=[h['unit_id'] for h in a];bi=[h['unit_id'] for h in b]
            require(len(set(ai))==len(ai) and len(set(bi))==len(bi),'duplicate route candidate')
            ar={u:i+1 for i,u in enumerate(ai)};br={u:i+1 for i,u in enumerate(bi)}
            aset,bset=set(ai),set(bi)
            result[route]=dict(ordered_ids_equal=ai==bi,candidate_set_equal=aset==bset,full_rows_equal=a==b,
                old_ordered_ids_sha256=canonical_sha(ai),controlled_ordered_ids_sha256=canonical_sha(bi),
                added=sorted(bset-aset),removed=sorted(aset-bset),
                position_changes=[dict(unit_id=u,old_rank=ar[u],controlled_rank=br[u]) for u in bi if u in ar and ar[u]!=br[u]])
        comparison.append(result)
    return comparison


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def main():
    started=time.perf_counter();target=OUT/'experiment_R_controlled'
    require(not target.exists(),'refuse overwrite controlled run')
    inputs={}
    def track(path,expected=None):
        path=__import__('pathlib').Path(path);digest=sha(path)
        if expected is not None:require(digest==expected,'frozen SHA mismatch: '+str(path))
        inputs[str(path)]=digest
        return path
    # Retrieval freezes contain technical inputs, not private expected/qrels/metrics.
    for arm in ['experiment_K','experiment_R']:
        freeze_path=track(OUT/arm/'retrieval_freeze.json')
        for name,digest in read(freeze_path)['sha256'].items():
            require(not any(x in name.replace('\\','/').lower() for x in ['/private_reference/','qrels','metrics','rankings_development']), 'refuse private/effect file in retrieval freeze')
            track(name,digest)
    qfreeze=read(track(OUT/'evaluation/query_freeze.json'))['sha256']
    qpath=OUT/'evaluation/queries.jsonl';gpath=OUT/'evaluation/group_split.json'
    for p in [qpath,gpath]:
        entry=next((v for k,v in qfreeze.items() if __import__('pathlib').Path(k)==p),None)
        require(entry is not None,'public query input absent from freeze');track(p,entry)
    queries=list(rows(qpath));groups=read(gpath)
    wanted=[q for q in queries if groups[q['query_id']]['split']=='development']
    require(len(queries)==24 and len(wanted)==12,'fixed K24/R12 development contract required')
    kpath=track(OUT/'experiment_K/query_vectors.npy');kaudit_path=track(OUT/'experiment_K/query_token_audit.jsonl')
    kaudit=list(rows(kaudit_path));kv=np.load(kpath,allow_pickle=False,mmap_mode='r')
    require(not kv.flags.writeable and kv.shape==(24,512),'read-only K matrix shape mismatch')
    qvectors,qbindings=reuse_query_rows(queries,kaudit,kv,[q['query_id'] for q in wanted])
    oldqpath=track(OUT/'experiment_R/query_vectors.npy');oldq=np.load(oldqpath,allow_pickle=False,mmap_mode='r')
    oldaudit_path=track(OUT/'experiment_R/query_token_audit.jsonl');oldaudit=list(rows(oldaudit_path))
    require([a['id'] for a in oldaudit if a['kind']=='query']==[q['query_id'] for q in wanted],'old R query order mismatch')
    require(oldq.shape==qvectors.shape and oldq.dtype==qvectors.dtype,'old R query matrix differs in shape/type')
    for i,b in enumerate(qbindings):
        b['old_R_row_bytes_equal_to_K']=oldq[i].tobytes()==qvectors[i].tobytes()
        b['old_R_max_absolute_element_delta']=float(np.max(np.abs(oldq[i]-qvectors[i])))

    cfg=read(track(ROOT/'outputs/FinRisk_召回率校准_20261013/retrieval_results.jsonl.run.json'))
    runner_path=track(ROOT/'work/finrisk_retrieval_20261012/runner.py',cfg['runner_sha256'])
    runner=module('controlled_frozen_runner',runner_path)
    project=runner.DEFAULT_SRC
    for name,key in [('sparse.py','bm25_source_sha256'),('tokenization.py','tokenizer_source_sha256')]:
        track(project/'retrieval'/name,cfg[key])
    index=V2/'indexes/all9639_final/structured.jsonl';manifest=read(track(index.parent/'manifest.json'))
    track(index,manifest['corpora']['structured']['sha256'])
    units=[{k:u[k] for k in ['unit_id','file_id','case_id','text']} for u in rows(index)]
    require(len(units)==65475 and len({u['file_id'] for u in units})==9639,'full frozen corpus required')
    caches=[]
    for p in (ROOT/'work/finrisk_recall_calibration_20261013/vector_cache').glob('*.json'):
        meta=read(p)
        if meta.get('shape')==[65475,512]:caches.append((p,meta))
    require(len(caches)==1,'ambiguous original vector cache')
    cache,meta=caches[0];track(cache);vector_path=track(cache.with_suffix('.npy'),meta['npy_sha256'])
    require(meta['ordered_unit_text_sha256']==runner.ordered_text_sha(units),'original vectors not bound to ordered text')
    import torch
    require(meta['binding']['torch']==torch.__version__,'frozen torch runtime version mismatch')
    require(meta['binding']['model']==runner.model_fingerprint(runner.DEFAULT_EMBEDDING),'model cache changed')
    vectors=np.load(vector_path,allow_pickle=False,mmap_mode='r')
    require(not vectors.flags.writeable and vectors.shape==(65475,512),'read-only original matrix required')

    overlay_path=track(OUT/'context/representation_overlay.jsonl');overlays=list(rows(overlay_path))
    context_path=track(OUT/'experiment_R/context_vectors.npy');context=np.load(context_path,allow_pickle=False,mmap_mode='r')
    binding_path=track(OUT/'experiment_R/context_cache_binding.json');context_binding=read(binding_path)
    for name,digest in context_binding['sha256'].items():track(name,digest)
    require(context_binding['model_runtime_binding']['model']==meta['binding']['model'],'context model binding differs')
    require(context_binding['model_runtime_binding']['torch']==meta['binding']['torch'],'context torch binding differs')
    require(context.shape==(20,512) and str(context.dtype)==context_binding['dtype']=='float32','context matrix shape/type mismatch')
    docaudit=[a for a in oldaudit if a['kind']=='document']
    require(len(overlays)==20 and [a['id'] for a in docaudit]==[o['unit_id'] for o in overlays],'context vector row order mismatch')
    require(all(a['input_tokens']<=512 and not a['truncated'] for a in docaudit),'hidden context truncation')
    require(read(track(OUT/'experiment_R/context_token_exclusions.json'))==[],'unexpected context exclusions')
    expected_bindings=[{k:o[k] for k in ['unit_id','representation_id','original_text_sha256','representation_sha256']} for o in overlays]
    require(context_binding['representations']==expected_bindings,'context sidecar order/text binding mismatch')
    positions={u['unit_id']:i for i,u in enumerate(units)}
    for o in overlays:
        require(o['unit_id'] in positions,'overlay unit absent')
        require(textsha(units[positions[o['unit_id']]]['text'])==o['original_text_sha256'],'overlay original text mismatch')
        require(textsha(o['representation_text'])==o['representation_sha256'],'overlay representation SHA mismatch')
    require(np.isfinite(qvectors).all() and np.isfinite(context).all(),'nonfinite reused vectors')
    overlay_text={o['unit_id']:o['representation_text'] for o in overlays}
    old_routes=list(rows(track(OUT/'experiment_R/routes.jsonl')))
    require([r['query_id'] for r in old_routes]==[q['query_id'] for q in wanted],'old R route query order mismatch')

    target.mkdir()
    np.save(target/'query_vectors.npy',qvectors,allow_pickle=False)
    saved=np.load(target/'query_vectors.npy',allow_pickle=False)
    require(saved.dtype==qvectors.dtype and saved.tobytes()==qvectors.tobytes(),'saved query vector bytes changed')
    sys.path.insert(0,str(project))
    from retrieval.sparse import SparseRetrievalIndex,RetrievalDocument
    sparse=SparseRetrievalIndex([RetrievalDocument(unit_id=u['unit_id'],case_ids=(u['case_id'],),text=overlay_text.get(u['unit_id'],u['text']),source='structured') for u in units],k1=1.5,b=.75)
    routes=[]
    for i,q in enumerate(wanted):
        bm=[dict(unit_id=h.document.unit_id,score=float(h.score),rank=h.rank) for h in sparse.search(q['text'],top_k=100)]
        scores=vectors@qvectors[i]
        for j,o in enumerate(overlays):scores[positions[o['unit_id']]]=float(context[j]@qvectors[i])
        order=np.lexsort((np.arange(len(scores)),-scores))[:100]
        dense=[dict(unit_id=units[int(j)]['unit_id'],score=float(scores[j]),rank=k) for k,j in enumerate(order,1)]
        fused=runner.rrf([bm,dense],k=60,top_k=100)
        require(len(bm)==len(dense)==len(fused)==100,'Top100 contract failed')
        routes.append(dict(query_id=q['query_id'],BM25=bm,BGE=dense,RRF=fused))
        print(__import__('json').dumps(dict(retrieved=i+1,total=12)),flush=True)
    del sparse
    comparison=compare_routes(old_routes,routes)
    save(target/'routes.jsonl',routes,True);save(target/'query_vector_bindings.jsonl',qbindings,True)
    save(target/'route_comparison.jsonl',comparison,True)

    # Rebuild original source-neighbor reading packets; never inspect API results or qrels.
    wanted_uids={h['unit_id'] for r in routes for h in r['RRF']}
    fileids={u['file_id'] for u in units if u['unit_id'] in wanted_uids};del units
    fullunits=[u for u in rows(index) if u['file_id'] in fileids]
    byid={u['unit_id']:u for u in fullunits};byfile=defaultdict(list)
    for u in fullunits:byfile[u['file_id']].append(u)
    builder_path=track(ROOT/'work/finrisk_two_layer_validation_20261017/context_builder.py')
    builder=module('controlled_original_context_builder',builder_path)
    contexts={};packets=[];mapping=[]
    for q,r in zip(wanted,routes):
        for hit in r['RRF']:
            uid=hit['unit_id'];u=byid[uid]
            if uid not in contexts:contexts[uid]=builder.build_context(u,byfile[u['file_id']],limit=800)
            c=contexts[uid];text=c['unit_text'];pair_id='KO_'+textsha('|'.join((q['query_id'],uid,textsha(text))))[:24]
            packets.append(dict(pair_id=pair_id,query_text=q['text'],query_text_sha256=q['text_sha256'],unit_text=text,unit_text_sha256=textsha(text)))
            mapping.append(dict(pair_id=pair_id,query_id=q['query_id'],unit_id=uid,file_id=u['file_id'],rrf_rank=hit['rank'],unit_text_sha256=textsha(text),segments=c['segments']))
    old_packets={p['pair_id']:p for p in rows(track(OUT/'experiment_R/rerank_inputs.jsonl'))}
    old_mapping=list(rows(track(OUT/'experiment_R/candidate_map.jsonl')))
    require(len(old_packets)==len(old_mapping)==len(packets)==1200,'fixed rerank pair count mismatch')
    for p in old_packets.values():
        require(p['unit_text_sha256']==textsha(p['unit_text']) and p['query_text_sha256']==textsha(p['query_text']),'old packet SHA mismatch')
    old_by_query=defaultdict(set)
    for m in old_mapping:old_by_query[m['query_id']].add(m['pair_id'])
    rules_path=track(OUT/'experiment_R/rerank_rules.md');krules=track(OUT/'experiment_K/rerank_rules.md')
    rules_same=sha(rules_path)==sha(krules)
    require(rules_same,'R/K rerank rules differ')
    per_query=[]
    for c in comparison:
        qid=c['query_id'];subset=[p for p,m in zip(packets,mapping) if m['query_id']==qid]
        same_pairs={p['pair_id'] for p in subset if old_packets.get(p['pair_id'])==p}
        per_query.append(dict(query_id=qid,query_vector_bytes_identical_to_K=True,
            rrf100_candidate_set_equal=c['RRF']['candidate_set_equal'],
            original_rerank_packets_identical=len(same_pairs)==100 and same_pairs==old_by_query[qid],
            matched_identical_pairs=len(same_pairs),new_or_changed_pair_ids=[p['pair_id'] for p in subset if p['pair_id'] not in same_pairs],
            old_pairs_absent=sorted(old_by_query[qid]-{p['pair_id'] for p in subset}),rules_identical=rules_same))
    all_sets=all(c['RRF']['candidate_set_equal'] for c in comparison)
    all_packets=all(c['original_rerank_packets_identical'] for c in per_query)
    reusable=all_sets and all_packets and rules_same
    save(target/'rerank_inputs.jsonl',packets,True);save(target/'candidate_map.jsonl',mapping,True)
    save(target/'per_query_equivalence.jsonl',per_query,True)
    track(WORK/'retrieve_r_controlled.py')
    unchanged={p:sha(p)==digest for p,digest in inputs.items()}
    require(all(unchanged.values()),'protected input mutated during controlled run')
    receipt=dict(schema='finrisk-R-controlled-query-vector-calibration-v1',passed=True,utc=utc(),seconds=time.perf_counter()-started,
        queries=12,documents=9639,units=65475,query_source='K query_vectors.npy rows selected by qid, preserving dtype and bytes',
        all_query_rows_byte_identical_to_K=True,old_R_query_rows_byte_equal_to_K=sum(b['old_R_row_bytes_equal_to_K'] for b in qbindings),
        context_vectors_reused=20,new_query_encodes=0,new_document_encodes=0,new_model_loads=0,new_api_calls=0,
        original_vectors_mmap_readonly=True,original_inputs_unchanged=all(unchanged.values()),
        top_per_route=100,rrf_c=60,weights=[1,1],bm25=dict(k1=1.5,b=.75),auxiliary_route_enabled=False,
        same_BM25_order_queries=sum(c['BM25']['ordered_ids_equal'] for c in comparison),same_BGE_order_queries=sum(c['BGE']['ordered_ids_equal'] for c in comparison),
        same_RRF_order_queries=sum(c['RRF']['ordered_ids_equal'] for c in comparison),same_RRF100_sets_queries=sum(c['RRF']['candidate_set_equal'] for c in comparison),
        all_RRF100_candidate_sets_equal=all_sets,all_1200_rerank_input_packets_equal=all_packets,
        rerank_rules_identical=rules_same,old_rerank_scores_reusable=reusable,old_18_new_scores_reusable=reusable,
        old_ranking_equivalent_under_existing_score_then_unit_id_policy=reusable,
        ranking_equivalence_basis='same query/candidate unit pairs, identical full rerank text and rule bytes; existing scores and stable unit_id tie policy reused, independent of RRF order',
        completed_old_R_scoring_source='parent task states 1200 old R scores completed; score values not read',
        no_expected_qrels_metrics_or_API_results_read=True,parameters_tuned=False,production_active=False,human_approved=False,review_origin='current_session_model')
    save(target/'retrieval_receipt.json',receipt)
    save(target/'cache_binding.json',dict(original_cache=str(cache),original_cache_sha256=inputs[str(cache)],
        original_model_binding=meta['binding'],context_model_binding=context_binding['model_runtime_binding'],
        context_cache_binding_sha256=sha(binding_path),context_vectors_sha256=sha(context_path),
        ordered_representation_bindings=context_binding['representations'],query_row_bindings=qbindings,
        runtime=dict(python=sys.executable,numpy=np.__version__,torch=torch.__version__),no_encoder_instantiated=True))
    outputs={str(p):sha(p) for p in target.iterdir() if p.is_file()}
    save(target/'retrieval_freeze.json',dict(utc=utc(),input_sha256=inputs,output_sha256=outputs,
        protected_inputs_unchanged=unchanged,scope='numeric control only; old K/R frozen artifacts remain unchanged',production_active=False))
    print(__import__('json').dumps({k:receipt[k] for k in ['passed','same_BM25_order_queries','same_BGE_order_queries','same_RRF_order_queries','same_RRF100_sets_queries','old_rerank_scores_reusable','old_ranking_equivalent_under_existing_score_then_unit_id_policy']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
