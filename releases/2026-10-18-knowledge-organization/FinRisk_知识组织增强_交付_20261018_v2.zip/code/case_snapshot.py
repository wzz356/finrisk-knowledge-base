"""Select actual IDs from the full KB; a reader snapshot is not the search corpus."""
import itertools
import shutil
from common import *
from base_reader import KnowledgeReader

def select_snapshot(wanted,unit_rows,draft_rows,document_rows,rebind_rows):
    wanted=set(wanted)
    if not wanted:raise ValueError('empty case snapshot')
    selected=[];counts=dict(units_scanned=0,drafts_scanned=0,documents_scanned=0)
    for row in unit_rows:
        counts['units_scanned']+=1
        if row['unit_id'] in wanted:selected.append(row)
    if len(selected)!=len(wanted) or {r['unit_id'] for r in selected}!=wanted:raise ValueError('requested unit missing or duplicated')
    files={r['file_id'] for r in selected};drafts=[];sources=[]
    for row in draft_rows:
        counts['drafts_scanned']+=1
        if row['file_id'] in files:
            if canonical_sha(row['draft'])!=row['effective_draft_json_sha256']:raise ValueError('current draft hash mismatch')
            drafts.append(row)
    for row in document_rows:
        counts['documents_scanned']+=1
        if row['official_file_id'] in files:
            if row.get('text_sha256') and textsha(row['full_text'])!=row['text_sha256']:raise ValueError('document text changed')
            sources.append(dict(file_id=row['official_file_id'],full_text=row['full_text'],source_sha256=row['source_sha256'],text_sha256=textsha(row['full_text'])))
    if len(drafts)!=len(files) or len(sources)!=len(files) or {r['file_id'] for r in drafts}!={r['file_id'] for r in sources}:raise ValueError('snapshot source/current draft missing or duplicate')
    patches=[r for r in rebind_rows if r['unit_id'] in wanted];patch_by={r['unit_id']:r for r in patches}
    current={r['file_id']:r['effective_draft_json_sha256'] for r in drafts}
    for unit in selected:
        if unit['candidate_sha256']!=current[unit['file_id']] and unit['unit_id'] not in patch_by:
            raise ValueError('stale binding without registered patch')
    return dict(units=sorted(selected,key=lambda r:r['unit_id']),candidates=drafts,sources=sources,rebinds=patches,counts=counts)

def build_snapshot(wanted,target,*,include_replay=False):
    target=Path(target).resolve()
    if not target.is_relative_to((OUT/'case_reader').resolve()) or target.exists():raise ValueError('new isolated snapshot required')
    wanted=set(wanted)
    if include_replay:
        wanted.update(r['unit_id'] for r in rows(P0OLD/'reader/bundle/units.jsonl'))
    indexes=itertools.chain(rows(V2/'indexes/all9639_final/structured.jsonl'),rows(V2/'indexes/all9639_final/raw.jsonl'))
    result=select_snapshot(wanted,indexes,rows(CURRENT),rows(V2/'normalized_final/data/documents.jsonl'),rows(BASE/'handoff_scope/projection_candidate_rebinds.jsonl'))
    if result['counts']!={'units_scanned':110878,'drafts_scanned':9639,'documents_scanned':9639}:raise ValueError('full corpus inventory changed')
    target.mkdir(parents=True,exist_ok=False)
    for key,name in [('units','units.jsonl'),('candidates','candidates.jsonl'),('sources','sources.jsonl'),('rebinds','rebinds.jsonl')]:save(target/name,result[key],True)
    for name in ['articles.jsonl','legal_sources.jsonl']:shutil.copyfile(P0OLD/'reader/bundle'/name,target/name)
    shutil.copytree(P0OLD/'reader/bundle/scope',target/'scope')
    versions=read(P0OLD/'reader/consumer_lock.json')['versions']
    files={p.relative_to(target).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(target.rglob('*')) if p.is_file()}
    save(target/'manifest.json',dict(schema='finrisk-read-consumer-v1',versions=versions,files=files,scope_subdir='scope',
        profile='offline_verified_retrieval_subset',not_a_full_corpus_serving_index=True,
        counts=dict(units=len(result['units']),documents=len(result['sources']),rebinds=len(result['rebinds']),legal_articles=43)))
    lock=dict(manifest_sha256=sha(target/'manifest.json'),versions=versions,bundle=target.relative_to(OUT).as_posix())
    consumer=KnowledgeReader(target,expected_versions=versions,expected_manifest_sha256=lock['manifest_sha256'])
    for uid in consumer.units:consumer.read(uid)
    save(target.with_name(target.name+'_lock.json'),lock)
    save(target.with_name(target.name+'_receipt.json'),dict(passed=True,**result['counts'],selected_units=len(consumer.units),
        selected_documents=len(consumer.sources),selected_rebinds=len(consumer.rebinds),full_corpus_serving_index=False,API_calls=0))
    return lock
