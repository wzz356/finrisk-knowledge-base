"""Stable offline entry point for the closed experiment and optional read layer."""
import argparse
from common import *

def release_root(args):
    if args.root:return args.root.resolve()
    if args.config:
        c=read(args.config);return (Path(c['project_root'])/c['output_dir']).resolve()
    adjacent=Path(__file__).resolve().parents[1]
    return adjacent if (adjacent/'contracts/knowledge_lock.json').exists() else OUT

def facade(root,profile):
    from knowledge_facade import KnowledgeFacade
    folder='contracts' if profile=='pilot' else 'expanded/contracts'
    return KnowledgeFacade(root,read(root/'case_reader/final_lock.json'),expected_knowledge_manifest_sha256=read(root/folder/'knowledge_lock.json')['manifest_sha256'],profile=profile)

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['status','verify','evaluate','bundle-check','impact','rebuild-affected','freeze','legal','cards','navigation','open-holdout','package'])
    parser.add_argument('--root',type=Path);parser.add_argument('--config',type=Path)
    parser.add_argument('--profile',choices=['pilot','expanded'],default='expanded')
    parser.add_argument('--mechanisms',nargs='+',default=['M11']);parser.add_argument('--unit-ids',nargs='*',default=[])
    parser.add_argument('--budget-chars',type=int,default=8000);parser.add_argument('--stage',type=Path)
    parser.add_argument('--workspace-check',action='store_true',help='verify original workspace before sealing; only supported at original OUT')
    args=parser.parse_args(argv);root=release_root(args)
    if args.command=='status':
        result=dict(knowledge_version=read(root/'expanded/contracts/knowledge_lock.json')['version'],
            K_holdout=read(root/'experiment_K/metrics.json')['summary']['holdout'],R=read(root/'experiment_R_controlled/metrics.json')['summary'],
            cost=read(root/'reports/cost_audit.json'),default_contextual_enabled=False,default_organized_judgment_enabled=False)
    elif args.command in ['verify','evaluate']:
        from verify_release import verify
        if args.workspace_check and root.resolve()!=OUT.resolve():raise ValueError('unsealed workspace check only supported at original OUT')
        result=verify(root,require_manifest=not args.workspace_check)
    elif args.command=='bundle-check':
        result=facade(root,args.profile).get_evidence_bundle(args.mechanisms,args.unit_ids,budget_chars=args.budget_chars)
    elif args.command in ['cards','navigation','legal']:
        f=facade(root,args.profile)
        if args.command=='cards':result=[f.read_mechanism(m,level='L2') for m in args.mechanisms]
        elif args.command=='navigation':result=f.navigation
        else:result=dict(articles=[f.read_article(a) for a in f.legal.articles],production_active=False)
    elif args.command in ['impact','rebuild-affected']:
        from dependency_build import DependencyGraph,rebuild_affected
        graph=DependencyGraph(rows(root/'maintenance_final/dependencies.jsonl'))
        if args.command=='impact':result=graph.impact(root)
        else:
            if not args.stage:raise ValueError('--stage is required')
            stage=args.stage.resolve()
            if not stage.is_relative_to(root.parent) or stage.is_relative_to(root) or root.is_relative_to(stage):raise ValueError('stage must be a new sibling directory below root parent, outside sealed inputs')
            result=rebuild_affected(graph,root,stage)
    elif args.command=='freeze':
        if root.resolve()!=OUT.resolve():raise ValueError('original external input audit requires original workspace; use verify for portable package')
        from freeze_inputs import verify_inputs
        table=read(root/'contracts/input_freeze.json')['sha256'];verify_inputs(table)
        result=dict(passed=True,protected_inputs=len(table),modified=False)
    elif args.command=='open-holdout':
        # The historic frozen function returns None; its completed receipt is authoritative.
        path=root/'experiment_K/holdout_open.json'
        if not path.exists():raise ValueError('closed release has no opened holdout; a fresh evaluation protocol is required')
        result=dict(already_opened=True,new_calls=0,receipt=read(path))
    else:
        from package_release import package
        result=package(root)
    print(json.dumps(result,ensure_ascii=False,indent=2));return result

if __name__=='__main__':main()
