import gzip
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
OUT=ROOT/'outputs/FinRisk_知识组织增强_v1_20261018'
P0OLD=ROOT/'outputs/FinRisk_P0P1落实_20261018'
BASE=ROOT/'outputs/FinRisk_知识库增量改进_20261018'
V2=ROOT/'outputs/FinRisk_知识库V2_20261012'
CURRENT=ROOT/'outputs/FinRisk_知识库V2.1轻量收尾_20261015/effective_candidates.jsonl.gz'
PYTHON=Path('C:/Users/11051/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')

def utc():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def textsha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def canonical_sha(v):return textsha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def rows(p):
    p=Path(p);opener=gzip.open if p.suffix=='.gz' else open
    with opener(p,'rt',encoding='utf-8-sig') as f:
        for line in f:
            if line.strip():yield json.loads(line)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v,jl=False):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:
        if jl:
            for r in v:f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
        else:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False)
