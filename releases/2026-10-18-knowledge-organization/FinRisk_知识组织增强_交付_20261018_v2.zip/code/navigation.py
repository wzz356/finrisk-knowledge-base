"""Deterministic navigation and bidirectional links, never a retrieval filter."""
from common import *

def reverse_links(forward):
    result={}
    for owner,targets in forward.items():
        for target in set(targets):result.setdefault(target,[]).append(owner)
    return {key:sorted(value) for key,value in sorted(result.items())}

def build_navigation(cards,article_ids,unit_ids,span_ids=None):
    mids=[r['mechanism_id'] for r in cards]
    if len(mids)!=len(set(mids)):raise ValueError('duplicate mechanism ID')
    forward={};pending=set();index=[]
    for card in cards:
        targets=[]
        for aid in card['article_ids']:
            if aid not in article_ids:raise ValueError('unregistered legal link')
            targets.append('ARTICLE:'+aid)
        for link in card['supporting_case_links']+card['adjacent_case_links']:
            if link.get('span_id'):
                if span_ids is None or link['span_id'] not in span_ids:raise ValueError('unregistered source span')
                targets.append('SPAN:'+link['span_id'])
            if link.get('unit_id'):
                if link['unit_id'] not in unit_ids:raise ValueError('unregistered case link')
                targets.append('UNIT:'+link['unit_id'])
        for other in card['adjacent_mechanism_ids']:
            if other in mids:targets.append('MECHANISM:'+other)
            else:pending.add(other)
        forward['MECHANISM:'+card['mechanism_id']]=sorted(set(targets))
        index.append(dict(mechanism_id=card['mechanism_id'],title=card['title'],overview=card['overview'],
            coverage=card['coverage'],L0='mechanisms/'+card['mechanism_id']+'/abstract.md',
            L1='mechanisms/'+card['mechanism_id']+'/overview.md',L2='registered_articles_and_case_spans'))
    return dict(schema='finrisk-navigation-v1',mechanisms=index,forward_links=forward,
        reverse_links=reverse_links(forward),pending_mechanism_ids=sorted(pending),
        hard_filter=False,human_approved=False,origin='deterministic_build')

def build():
    cards=list(rows(OUT/'knowledge/mechanisms.jsonl'))
    sources=list(rows(OUT/'knowledge/case_links.jsonl'))
    article_ids={r['article_id'] for r in rows(OUT/'legal/articles.jsonl')}
    unit_ids={r['unit_id'] for r in sources if r.get('unit_id')}
    span_ids={r['span_id'] for r in rows(OUT/'knowledge/source_spans.jsonl')}
    navigation=build_navigation(cards,article_ids,unit_ids,span_ids)
    save(OUT/'navigation/index.json',navigation)
    save(OUT/'navigation/reverse_links.jsonl',[dict(target=k,owners=v) for k,v in navigation['reverse_links'].items()],True)
    root_lines=['# 风险机制导航','', '按机制阅读概览，再按登记ID读取法规和案例原句。机制只是候选，不是当前输入事实。','']
    for card in cards:
        mid=card['mechanism_id'];directory=OUT/'navigation/mechanisms'/mid;directory.mkdir(parents=True,exist_ok=True)
        (directory/'abstract.md').write_text('# '+card['title']+'\n\n'+card['overview']+'\n',encoding='utf-8')
        lines=['# '+card['title'],'',card['overview'],'','## 核查条件','']
        lines += ['- '+p['predicate_id']+'：'+p['description'] for p in card['predicates']]
        lines += ['','## 范围与限制','',*['- '+s for s in card['cannot_infer']],'','## 可读取条目','']
        lines += ['- '+target for target in navigation['forward_links']['MECHANISM:'+mid]]
        (directory/'overview.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        root_lines.append(f'- [{mid} {card["title"]}](mechanisms/{mid}/overview.md)')
    (OUT/'navigation/overview.md').write_text('\n'.join(root_lines)+'\n',encoding='utf-8')
    save(OUT/'navigation/coverage.json',dict(mechanism_count=len(cards),declared_mechanisms=[c['mechanism_id'] for c in cards],
        pending_mechanisms=navigation['pending_mechanism_ids'],all_official_27_labels_fully_covered=False,
        link_targets=len(navigation['reverse_links']),hard_filter=False))
    return navigation

if __name__=='__main__':print(__import__('json').dumps(build()['mechanisms'],ensure_ascii=False))
