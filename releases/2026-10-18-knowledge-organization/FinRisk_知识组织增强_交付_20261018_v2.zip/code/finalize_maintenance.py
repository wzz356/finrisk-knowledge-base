"""Append actual contextual vectors and expanded knowledge to the frozen T09 graph."""
import ast
import copy
import hashlib
import json
import math
import shutil
import struct
from collections import Counter
from pathlib import Path

from common import OUT, ROOT, WORK, canonical_sha, read, rows, save, sha, textsha
from dependency_build import DependencyGraph, rebuild_affected


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_npy_rows(path):
    raw = Path(path).read_bytes()
    require(raw[:8] == b'\x93NUMPY\x01\x00' and len(raw) >= 10, 'expected NPY v1 little-endian float32 matrix')
    header_length = struct.unpack('<H', raw[8:10])[0]
    start = 10 + header_length
    header = ast.literal_eval(raw[10:start].decode('latin1'))
    require(header['shape'] == (20, 512) and header['descr'] == '<f4' and header['fortran_order'] is False,
            'expected a C-order (20,512) float32 context matrix')
    require(len(raw) == start + 20 * 2048, 'truncated or trailing matrix bytes')
    records = []
    for index in range(20):
        begin, end = start + index * 2048, start + (index + 1) * 2048
        require(all(math.isfinite(v) for v in struct.unpack('<512f', raw[begin:end])), 'nonfinite vector value')
        records.append({'row': index, 'start_byte': begin, 'end_byte': end,
                        'row_bytes_sha256': hashlib.sha256(raw[begin:end]).hexdigest()})
    return {'shape': [20, 512], 'dtype': 'float32', 'header_bytes': start,
            'file_sha256': hashlib.sha256(raw).hexdigest(), 'rows': records}


def register_final(root=OUT):
    root = Path(root).resolve()
    target = root / 'maintenance_final'
    target.mkdir(parents=True, exist_ok=False)
    old_path = root / 'maintenance/dependencies.jsonl'
    old = DependencyGraph(rows(old_path))
    require(len(old.nodes) == 3950 and old.verify_inputs(root), 'old graph or old input mismatch')
    old_digest = sha(old_path)
    nodes, old_ids = copy.deepcopy(old.nodes), set(old.by_id)

    def add(identity, kind, deps=(), path=None, key=None, value=None, fields=None, exclude=(), pending=False):
        spec = {'path': path} if path else None
        if spec is not None and key:
            spec.update(record_key=key, record_id=value)
            spec['fields' if fields is not None else 'exclude_fields'] = list(fields if fields is not None else exclude)
        nodes.append({'node_id': identity, 'kind': kind, 'dependencies': list(dict.fromkeys(deps)), 'input': spec,
            'status': 'pending' if pending else 'present',
            'materialization': 'future_compute_or_review' if pending else 'existing_artifact_read_only_registration'})
        return identity

    docs = list(rows(root / 'expanded/knowledge/source_documents.jsonl'))
    spans = list(rows(root / 'expanded/knowledge/source_spans.jsonl'))
    cards = list(rows(root / 'expanded/knowledge/mechanisms.jsonl'))
    links = list(rows(root / 'expanded/knowledge/case_links.jsonl'))
    require((len(cards), len(docs), len(spans), len(links)) == (12, 59, 78, 109), 'expanded scope changed')
    dnodes = {d['file_id']: add('EXPANDED_DOCUMENT_TEXT:' + d['file_id'], 'text', path='expanded/knowledge/source_documents.jsonl',
        key='file_id', value=d['file_id'], fields=['full_text']) for d in docs}
    st, sm = {}, {}
    for span in spans:
        identity = span['span_id']
        st[identity] = add('EXPANDED_SPAN_TEXT:' + identity, 'text', [dnodes[span['file_id']]],
            'expanded/knowledge/source_spans.jsonl', 'span_id', identity, fields=['text'])
        sm[identity] = add('EXPANDED_SPAN_META:' + identity, 'metadata', path='expanded/knowledge/source_spans.jsonl',
            key='span_id', value=identity, exclude=['text','text_sha256','source_sha256'])
    legal = list(rows(root / 'legal/dependencies.jsonl'))
    adjacency = {}
    for edge in legal:
        adjacency.setdefault(edge['from_article_id'], []).append(edge['to_article_id'])
    case_links = add('EXPANDED_CASE_LINKS', 'metadata', path='expanded/knowledge/case_links.jsonl')
    claims = add('EXPANDED_CLAIM_EVIDENCE', 'metadata', path='expanded/knowledge/claim_evidence.jsonl')
    reviews = []
    for card in cards:
        mid = card['mechanism_id']
        article_ids = list(card['article_ids'])
        for predicate in card['predicates']:
            article_ids += predicate.get('support_article_ids', []) + predicate.get('context_article_ids', [])
        context, queue = set(article_ids), list(article_ids)
        while queue:
            for target_article in adjacency.get(queue.pop(), []):
                if target_article not in context:
                    context.add(target_article)
                    queue.append(target_article)
        sids = {l['span_id'] for l in links if l['mechanism_id'] == mid}
        fields = ['title','overview','predicates','scope_axes','article_ids','facts_to_check','cannot_infer']
        text = add('EXPANDED_CARD_CONTENT:' + mid, 'card', ['ARTICLE_TEXT:' + a for a in sorted(context)] + [st[s] for s in sorted(sids)],
            'expanded/knowledge/mechanisms.jsonl', 'mechanism_id', mid, fields=fields)
        meta = add('EXPANDED_CARD_META:' + mid, 'metadata', path='expanded/knowledge/mechanisms.jsonl',
            key='mechanism_id', value=mid, exclude=fields)
        review = add('EXPANDED_CARD_REVIEW:' + mid, 'review', [text, meta, case_links, claims]
            + ['ARTICLE_META:' + a for a in sorted(context)] + [sm[s] for s in sorted(sids)], pending=True)
        reviews.append(review)
        nav = add('EXPANDED_NAV:' + mid, 'navigation', [review], 'expanded/navigation/mechanisms/' + mid + '/overview.md')
        add('EXPANDED_ABSTRACT:' + mid, 'navigation', [nav], 'expanded/navigation/mechanisms/' + mid + '/abstract.md')
        add('EXPANDED_READ_BUNDLE:' + mid, 'bundle', [review], pending=True)
    nav_index = add('EXPANDED_NAV_PACKAGE', 'navigation', reviews, 'expanded/navigation/index.json')
    add('EXPANDED_REVERSE_LINKS', 'navigation', [nav_index], 'expanded/navigation/index.json')
    add('EXPANDED_LABEL_COVERAGE', 'metadata', [nav_index], 'expanded/navigation/label_coverage.json')

    prefix_rows = list(rows(root / 'context/prefixes.jsonl'))
    representations = list(rows(root / 'context/representation_overlay.jsonl'))
    context_binding = read(root / 'experiment_R/context_cache_binding.json')
    controlled_binding = read(root / 'experiment_R_controlled/cache_binding.json')
    matrix = read_npy_rows(root / 'experiment_R/context_vectors.npy')
    expected_bindings = [{k: r[k] for k in ['unit_id','representation_id','original_text_sha256','representation_sha256']}
                         for r in representations]
    require(len(prefix_rows) == len(representations) == 20
            and context_binding['representations'] == controlled_binding['ordered_representation_bindings'] == expected_bindings,
            'actual vector representation order mismatch')
    require(controlled_binding['context_cache_binding_sha256'] == sha(root / 'experiment_R/context_cache_binding.json')
            and controlled_binding['context_vectors_sha256'] == matrix['file_sha256'], 'controlled context binding hash mismatch')
    for relative in ['experiment_R/context_vectors.npy','context/prefixes.jsonl','context/representation_overlay.jsonl']:
        require(context_binding['sha256'][str(root / relative)] == sha(root / relative), 'context cache payload binding mismatch')
    require(controlled_binding['context_model_binding'] == context_binding['model_runtime_binding'], 'context model binding mismatch')
    original_cache = Path(controlled_binding['original_cache'])
    require(sha(original_cache) == controlled_binding['original_cache_sha256'], 'read-only original cache metadata mismatch')
    original_meta = read(original_cache)
    original_matrix = original_cache.with_suffix('.npy')
    require(sha(original_matrix) == original_meta['npy_sha256'], 'read-only original vector matrix mismatch')
    external_before = {str(p): sha(p) for p in [original_cache, original_matrix]}
    binding_record = {'binding_id': 'context_model', 'model_runtime_binding': context_binding['model_runtime_binding'],
        'original_cache': str(original_cache.relative_to(ROOT)).replace('\\','/'),
        'original_cache_sha256': external_before[str(original_cache)], 'original_matrix_sha256': external_before[str(original_matrix)],
        'policy': 'read_only_fingerprints_no_encoder_or_model_load'}
    save(root / 'maintenance_final/model_binding.jsonl', [binding_record], jl=True)
    model = add('ACTUAL_MODEL_RUNTIME', 'model_runtime', path='maintenance_final/model_binding.jsonl',
        key='binding_id', value='context_model')
    matrix_bytes = add('ACTUAL_MATRIX_BYTES', 'vector_bytes', path='experiment_R/context_vectors.npy')
    old_spans = {r['span_id']: r for r in rows(root / 'knowledge/source_spans.jsonl')}
    old_units = {r['unit_id']: r for r in rows(root / 'case_reader/pilot/units.jsonl')}
    vector_records, actual_vector_ids = [], []
    for position, (prefix, representation) in enumerate(zip(prefix_rows, representations)):
        uid, rid = prefix['unit_id'], prefix['representation_id']
        require(uid == representation['unit_id'] and rid == representation['representation_id'], 'prefix/representation order mismatch')
        require(prefix['original_text'] == old_units[uid]['text']
            and prefix['original_text_sha256'] == textsha(old_units[uid]['text'])
            and prefix['prefix_text_sha256'] == textsha(prefix['prefix_text'])
            and prefix['representation_text'] == representation['representation_text']
            and prefix['representation_sha256'] == representation['representation_sha256'] == textsha(representation['representation_text']),
            'actual prefix text/hash mismatch')
        require(len(prefix['supporting_span_ids']) == len(prefix['supporting_spans']), 'prefix span binding mismatch')
        for sid, span in zip(prefix['supporting_span_ids'], prefix['supporting_spans']):
            source = old_spans[sid]
            require(all(span[k] == source[k] for k in ['start','end','text']) and source['source_sha256'] == prefix['source_sha256'],
                    'actual literal prefix source mismatch')
        pnode = add('ACTUAL_PREFIX:' + rid, 'prefix', ['UNIT_TEXT:' + uid] + ['SPAN_TEXT:' + s for s in prefix['supporting_span_ids']],
            'context/prefixes.jsonl', 'representation_id', rid, fields=['prefix_text'])
        repnode = add('ACTUAL_REPRESENTATION:' + rid, 'representation', [pnode, 'UNIT_TEXT:' + uid],
            'context/representation_overlay.jsonl', 'representation_id', rid, fields=['representation_text'])
        vector_record = {**matrix['rows'][position], 'representation_id': rid, 'unit_id': uid,
            'representation_sha256': representation['representation_sha256'], 'source_matrix_sha256': matrix['file_sha256'],
            'row_materialization': 'already_computed_float32_vector_read_only', 'bytes_per_row': 2048}
        vector_records.append(vector_record)
        actual_vector_ids.append(add('ACTUAL_VECTOR_ROW:' + rid, 'contextual_embedding', [repnode, model, matrix_bytes],
            'maintenance_final/vector_rows.jsonl', 'representation_id', rid))
    save(root / 'maintenance_final/vector_rows.jsonl', vector_records, jl=True)
    matrix_node = add('ACTUAL_CONTEXT_MATRIX', 'vector_matrix', actual_vector_ids, 'experiment_R/context_vectors.npy')
    context_node = add('ACTUAL_CONTEXT_BINDING', 'computed_binding', [matrix_node], 'experiment_R/context_cache_binding.json')
    add('ACTUAL_CONTROLLED_BINDING', 'computed_binding', [context_node, matrix_node], 'experiment_R_controlled/cache_binding.json')
    # Track other existing context/expanded metadata without reading query results or model caches into the graph.
    already = {n['input']['path'] for n in nodes if n.get('input') is not None}
    paths = [p for directory in ['expanded/knowledge','expanded/navigation','expanded/contracts','context']
             for p in (root / directory).rglob('*') if p.is_file()]
    paths.append(old_path)
    for path in paths:
        rel = path.relative_to(root).as_posix()
        if rel not in already:
            add('FINAL_AUDIT_ASSET:' + rel, 'metadata', path=rel)
    graph = DependencyGraph.snapshot(root, nodes)
    require(all(graph.by_id[n['node_id']] == n for n in old.nodes), 'legacy node changed')
    for identity in graph.order:
        if identity in old_ids:
            continue
        node = graph.by_id[identity]
        node['dependency_input_sha256'] = {d: graph.by_id[d].get('input_sha256', graph.by_id[d].get('dependency_signature_sha256'))
            for d in node['dependencies']}
        node['dependency_signature_sha256'] = canonical_sha(node['dependency_input_sha256'])
    graph.nodes = [graph.by_id[n['node_id']] for n in graph.nodes]
    require(graph.verify_inputs(root) and not graph.impact(root)['affected'], 'final baseline impact must be empty')
    save(target / 'dependencies.jsonl', graph.nodes, jl=True)
    save(target / 'impact.json', graph.impact(root))
    coverage = {'schema': 'finrisk-final-maintenance-coverage-v1', 'old_nodes_preserved': 3950,
        'nodes': len(graph.nodes), 'node_kinds': dict(Counter(n['kind'] for n in graph.nodes)),
        'actual_materialized_prefixes': 20, 'actual_materialized_vector_rows': 20, 'actual_vector_shape': matrix['shape'],
        'actual_vector_matrix_sha256': matrix['file_sha256'], 'actual_expanded_scope': {'cards': 12, 'documents': 59, 'spans': 78, 'case_links': 109},
        'legacy_future_prefix_nodes_still_pending': 78, 'legacy_future_contextual_vectors_still_pending': 78,
        'actual_prefix_dependency_contract': 'only current literal source span text and original pilot unit text; no legal metadata or card text',
        'pending_queue': [{'node_id': n['node_id'], 'kind': n['kind']} for n in graph.nodes if n['status']=='pending'],
        'coverage_is_full_corpus_audit': False, 'production_rebuilders_implemented': False,
        'actual_vectors_recomputed_by_this_task': False, 'default_route_changed': False, 'activation_allowed': False,
        'limits': ['全库9639文书审核仍未覆盖','既有20literal prefixes不随法源元数据无端重新编码',
                  '未来prefix节点与已有20条分开，不据新登记提升旧pending状态','卡片和导航变更后的生产重建/审查仍须显式完成'],
        'old_graph_sha256': old_digest, 'read_K_R_per_query_results': False, 'new_API_calls': 0,
        'human_approved': False, 'review_origin': 'current_session_model'}
    save(target / 'coverage.json', coverage)
    return graph, coverage, external_before


def simulations(graph, root=OUT):
    root = Path(root)
    paths = sorted({n['input']['path'] for n in graph.nodes if n.get('input') is not None})
    before = {p: sha(root / p) for p in paths}
    reports = []
    for code, label in [('p','prefix_text'), ('m','law_source_metadata'), ('u','unrelated_file')]:
        base = WORK / 'maintenance_final_task/s' / code
        clone = base / 'in'
        clone.mkdir(parents=True, exist_ok=False)
        for rel in paths:
            target = clone / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(root / rel, target)
        if code == 'p':
            path = clone / 'context/prefixes.jsonl'
            records = list(rows(path))
            records[0]['prefix_text'] += '〔仅副本变化模拟〕'
            path.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in records), encoding='utf-8')
        elif code == 'm':
            path = clone / 'legal/source_registry.jsonl'
            records = list(rows(path))
            next(r for r in records if r['source_id']=='L001')['axes']['current_validity']['evidence_cutoff'] = '2026-09-01'
            path.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in records), encoding='utf-8')
        else:
            (clone / 'unrelated.txt').write_text('未登记的无关说明', encoding='utf-8')
        impact = graph.impact(clone)
        actual_prefixes = [n for n in impact['affected'] if n.startswith('ACTUAL_PREFIX:')]
        actual_vectors = [n for n in impact['affected'] if n.startswith('ACTUAL_VECTOR_ROW:')]
        expanded_reviews = [n for n in impact['affected'] if n.startswith('EXPANDED_CARD_REVIEW:')]
        if code == 'p':
            require(len(actual_prefixes)==len(actual_vectors)==1 and 'ACTUAL_CONTROLLED_BINDING' in impact['affected'],
                    'prefix mutation must invalidate its row and controlled binding')
        elif code == 'm':
            require(not actual_prefixes and not actual_vectors and bool(expanded_reviews), 'legal metadata incorrectly invalidates literal prefix vectors')
        else:
            require(not impact['affected'], 'unrelated file invalidates graph')
        receipt = rebuild_affected(graph, clone, base / 'st')
        require(receipt['activation_allowed'] is False and receipt['embedding_recomputed'] is False, 'staging activation/compute claim forbidden')
        report = {'scenario': label, 'affected_count': len(impact['affected']), 'changed': impact['changed'],
            'actual_prefixes_affected': len(actual_prefixes), 'actual_vectors_affected': len(actual_vectors),
            'expanded_card_reviews_affected': expanded_reviews, 'status': receipt['status'],
            'staged_input_projections': len(receipt['built']), 'pending_count': len(receipt['pending']),
            'activation_allowed': False, 'embedding_recomputed': False,
            'receipt': str((base / 'st/receipt.json').relative_to(WORK)).replace('\\','/')}
        save(root / 'maintenance_final/scenarios' / (code + '.json'), {'report': report, 'impact': impact})
        reports.append(report)
    after = {p: sha(root / p) for p in paths}
    require(before == after, 'registered official inputs changed during copy simulations')
    return reports, before, after


def main():
    graph, coverage, external_before = register_final()
    reports, before, after = simulations(graph)
    external_after = {p: sha(p) for p in external_before}
    require(external_before == external_after, 'read-only original cache changed')
    old = DependencyGraph(rows(OUT / 'maintenance/dependencies.jsonl'))
    require(old.verify_inputs(OUT) and graph.verify_inputs(OUT) and not graph.impact(OUT)['affected'], 'final verification failed')
    verification = {'schema': 'finrisk-final-maintenance-verification-v1', 'passed': True,
        'old_inputs_unchanged': True, 'all_registered_inputs_unchanged': before == after,
        'old_graph_sha256_unchanged': sha(OUT / 'maintenance/dependencies.jsonl') == coverage['old_graph_sha256'],
        'node_count': len(graph.nodes), 'old_nodes_preserved': 3950, 'graph_acyclic': True, 'baseline_impact_empty': True,
        'actual_prefixes': 20, 'actual_vector_rows': 20, 'vector_row_bytes': 2048,
        'scenarios': reports, 'registered_input_sha256_before': before, 'registered_input_sha256_after': after,
        'external_readonly_cache_sha256_before': external_before, 'external_readonly_cache_sha256_after': external_after,
        'model_or_encoder_instantiated': False, 'read_K_R_per_query_results': False, 'new_API_calls': 0,
        'embedding_recomputed': False, 'activation_allowed': False, 'production_active': False,
        'human_approved': False, 'review_origin': 'current_session_model'}
    save(OUT / 'maintenance_final/verification.json', verification)
    print(json.dumps({k: verification[k] for k in ['passed','node_count','old_nodes_preserved','graph_acyclic','baseline_impact_empty','scenarios']}, ensure_ascii=False, indent=2))
    return verification


if __name__ == '__main__':
    main()
