"""Stable public entry point for the six read APIs."""
from knowledge_facade import KnowledgeFacade
