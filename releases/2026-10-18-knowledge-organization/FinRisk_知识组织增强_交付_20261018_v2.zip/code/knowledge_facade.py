"""Six bounded read operations. No Agent loop and no implicit query facts."""
import copy
from common import *
from base_reader import KnowledgeReader
from legal_registry import LegalRegistry
from build_cards import LEGAL_SHA

def _ids(value,registered,name,allow_empty=True):
    if not isinstance(value,list) or (not allow_empty and not value) or any(not isinstance(x,str) or x not in registered for x in value) or len(set(value))!=len(value):
        raise ValueError('unknown, duplicated or invalid '+name)

def pack_whole(blocks,budget):
    """Count exact serialized Unicode characters; never truncate a legal exception."""
    if type(budget) is not int or not 1<=budget<=8000:raise ValueError('budget must be integer in 1..8000')
    included=[];omitted=[];text=''
    for identity,block in blocks:
        candidate=text+('\n\n' if text else '')+block
        if len(candidate)<=budget:text=candidate;included.append(identity)
        else:omitted.append(identity)
    return text,included,omitted

class KnowledgeFacade:
    def __init__(self,root,case_lock,*,expected_knowledge_manifest_sha256=None,profile='pilot'):
        self.root=Path(root).resolve()
        if profile not in ['pilot','expanded']:raise ValueError('unknown knowledge profile')
        knowledge_root=self.root if profile=='pilot' else self.root/'expanded'
        manifest=knowledge_root/'contracts/knowledge_manifest.json'
        if not expected_knowledge_manifest_sha256 or sha(manifest)!=expected_knowledge_manifest_sha256:raise ValueError('missing or incompatible enhancement manifest fingerprint')
        enhancement=read(manifest)
        if enhancement.get('schema')!='finrisk-enhancement-knowledge-v1' or enhancement.get('enhancement_version')!='knowledge-organization-'+profile+'-v1':raise ValueError('unsupported enhancement version')
        if enhancement.get('base_versions')!=case_lock.get('versions'):raise ValueError('enhancement and case base version mismatch')
        for name,meta in enhancement['files'].items():
            path=(self.root/name).resolve()
            if not path.is_relative_to(self.root) or sha(path)!=meta['sha256']:raise ValueError('knowledge payload changed')
        self.legal=LegalRegistry(self.root/'legal',LEGAL_SHA)
        self.cases=KnowledgeReader(self.root/case_lock['bundle'],expected_versions=case_lock['versions'],expected_manifest_sha256=case_lock['manifest_sha256'])
        self.cards={r['mechanism_id']:r for r in rows(knowledge_root/'knowledge/mechanisms.jsonl')}
        self.links=list(rows(knowledge_root/'knowledge/case_links.jsonl'))
        self.spans={r['span_id']:r for r in rows(knowledge_root/'knowledge/source_spans.jsonl')}
        sources={r['file_id']:r for r in rows(knowledge_root/'knowledge/source_documents.jsonl')}
        for s in self.spans.values():
            full=sources[s['file_id']]['full_text']
            if type(s['start']) is not int or type(s['end']) is not int or not 0<=s['start']<s['end']<=len(full) or full[s['start']:s['end']]!=s['text'] or textsha(s['text'])!=s['text_sha256']:
                raise ValueError('registered literal case evidence changed')
        self.navigation=read(knowledge_root/'navigation/index.json')

    def list_mechanisms(self):
        return copy.deepcopy(self.navigation['mechanisms'])

    def read_mechanism(self,mechanism_id,level='L0'):
        if mechanism_id not in self.cards or level not in ['L0','L1','L2']:raise ValueError('unknown mechanism or reading level')
        card=copy.deepcopy(self.cards[mechanism_id])
        if level=='L0':return {k:card[k] for k in ['mechanism_id','title','overview','identity','coverage','human_approved']}
        if level=='L2':
            spanids=sorted({l['span_id'] for l in self.links if l['mechanism_id']==mechanism_id})
            card.update(case_evidence=[copy.deepcopy(self.spans[s]) for s in spanids],
                        legal_evidence=[self.read_article(a) for a in card['article_ids']])
        return card

    def read_article(self,article_id,include_dependencies=True,as_of=None):
        return self.legal.read_article(article_id,include_dependencies,as_of)

    def read_case(self,unit_id,layer='hit'):
        return self.cases.read(unit_id,layer=layer)

    def get_dependencies(self,article_ids,limit=32):
        return self.legal.dependency_closure(article_ids,limit)

    def coverage(self,mechanism_id):
        if mechanism_id not in self.cards:raise ValueError('unknown mechanism')
        c=self.cards[mechanism_id];closure=self.get_dependencies(c['article_ids'])
        return copy.deepcopy(dict(material_scope=c['coverage'],dependency_reading=closure,
            normative_applicability=dict(status='not_assessed_for_current_input',axes=c['scope_axes']),
            content_budget=dict(status='not_assembled'),full_corpus_relevance_known=False,human_approved=False))

    def get_evidence_bundle(self,mechanism_ids,case_unit_ids,*,budget_chars=8000,case_budget=None,law_budget=None):
        if isinstance(mechanism_ids,str):mechanism_ids=[mechanism_ids]
        if type(budget_chars) is not int or not 2<=budget_chars<=8000:raise ValueError('total budget must be 2..8000')
        case_budget=budget_chars//2 if case_budget is None else case_budget
        law_budget=budget_chars-case_budget if law_budget is None else law_budget
        if type(case_budget) is not int or type(law_budget) is not int or case_budget+law_budget>budget_chars:raise ValueError('component budgets exceed total')
        _ids(mechanism_ids,self.cards,'mechanism IDs',False);_ids(case_unit_ids,self.cases.units,'case IDs')
        records=[self.read_case(u) for u in case_unit_ids]
        caseblocks=[(r['unit_id'],'案例 '+r['unit_id']+'\n'+r['text']) for r in records]
        case_text,case_kept,case_omitted=pack_whole(caseblocks,case_budget)
        cards=[self.cards[m] for m in mechanism_ids]
        roots=list(dict.fromkeys(a for c in cards for a in c['article_ids']))
        closure=self.get_dependencies(roots)
        guideblocks=[]
        for c in cards:
            lines=['机制解释 '+c['mechanism_id']+' '+c['title'],c['overview']]
            lines+=['条件 '+p['predicate_id']+' '+p['description'] for p in c['predicates']]
            lines+=['范围 '+k+'：'+v for k,v in c['scope_axes'].items()]
            # Case-link quotations deliberately excluded: K arms keep identical case evidence.
            guideblocks.append(('GUIDE:'+c['mechanism_id'],'\n'.join(lines)))
        legalblocks=[]
        for aid in closure['resolved']:
            article=self.legal.articles[aid];source=self.legal.sources[article['source_id']]
            restriction=json.dumps(dict(version=source.get('version'),axes=source.get('axes'),production_active=False),ensure_ascii=False,separators=(',',':'))
            legalblocks.append((aid,'法规 '+aid+'\n'+article['text']+'\n来源限制 '+restriction))
        law_text,law_kept,law_omitted=pack_whole(guideblocks+legalblocks,law_budget)
        omitted_articles=[a for a in law_omitted if not a.startswith('GUIDE:')]
        # A fitting child without its required context remains explicitly partial.
        partial=bool(case_omitted or law_omitted or closure['status']!='complete')
        return dict(schema='finrisk-evidence-bundle-v1',mechanism_ids=mechanism_ids,
            requested_case_unit_ids=case_unit_ids,included_case_unit_ids=case_kept,case_text=case_text,
            case_records=[r for r in records if r['unit_id'] in case_kept],law_and_guide_text=law_text,
            included_legal_and_guide_ids=law_kept,legal_article_ids_requested=closure['resolved'],
            facts_to_check=[dict(predicate_id=p['predicate_id'],description=p['description'],status='not_assessed',required_for_risk=p['required_for_risk']) for c in cards for p in c['predicates']],
            coverage=dict(status='partial' if partial else 'complete_for_requested_registered_items',
                dependency_closure=closure,omitted_case_unit_ids=case_omitted,omitted_legal_article_ids=omitted_articles,
                omitted_guide_ids=[a for a in law_omitted if a.startswith('GUIDE:')],unread_dependency_ids=omitted_articles,
                full_corpus_coverage=False),
            budget_chars=dict(cases=case_budget,laws_and_guides=law_budget,case_used=len(case_text),laws_and_guides_used=len(law_text),unit='Unicode codepoints of exact supplied text'),
            current_input_facts_assessed=False,human_approved=False,review_origin='current_session_model',
            score_interpretation='ranking_score_not_violation_probability')
