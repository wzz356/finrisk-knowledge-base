"""Freeze grouped synthetic silver references separately from inference inputs."""
import math
import shutil
from common import *

def validate_groups(groups,expected_queries=24,expected_groups=8):
    if len(groups)!=expected_queries:raise ValueError('query count mismatch')
    story={}
    for q,g in groups.items():
        if g['split'] not in ['development','dev','holdout']:raise ValueError('unknown split')
        story.setdefault(g['group_id'],[]).append(g['split'])
    if len(story)!=expected_groups or any(len(s)!=3 or len(set(s))!=1 for s in story.values()):raise ValueError('story triplets split leakage or incomplete group')
    return True

def ranking_metrics(ranked,qrels,k):
    top=ranked[:k]
    if any(f not in qrels for f in top):raise ValueError('unjudged document; no zero imputation')
    direct={f for f,g in qrels.items() if g==3}
    pos=[i for i,f in enumerate(top,1) if f in direct]
    gains=[0,1,3,7]
    dcg=sum(gains[qrels[f]]/math.log2(i+1) for i,f in enumerate(top,1))
    ideal=sorted(qrels.values(),reverse=True)[:k];idcg=sum(gains[g]/math.log2(i+1) for i,g in enumerate(ideal,1))
    return dict(P=sum(f in direct for f in top)/k,MRR=1/pos[0] if pos else 0,Top1=int(bool(top) and top[0] in direct),
        known_pool_recall=sum(f in direct for f in top)/len(direct) if direct else None,
        NDCG_pool=dcg/idcg if idcg else None,global_true_recall=False,judged_pool_direct_documents=len(direct))

def main():
    acceptance=read(WORK/'query_review/final_acceptance.json')
    if acceptance.get('all_24_freezable') is not True or acceptance.get('human_approved') is not False:raise ValueError('independent query review not accepted')
    source=WORK/'query_author'
    for name,digest in acceptance['file_hashes'].items():
        if sha(source/name)!=digest:raise ValueError('reviewed query snapshot changed')
    queries=list(rows(source/'queries.jsonl'));groups=read(source/'groups.json')
    if 'groups' in groups:groups=groups['groups']
    if isinstance(groups,list):groups={r['query_id']:r for r in groups}
    validate_groups(groups)
    if any(set(q)!={'query_id','text','text_sha256'} or textsha(q['text'])!=q['text_sha256'] for q in queries):raise ValueError('query contamination or SHA mismatch')
    destinations=[(source/'queries.jsonl',OUT/'evaluation/queries.jsonl'),(source/'groups.json',OUT/'private_reference/group_design.json'),
        (source/'expected.jsonl',OUT/'private_reference/expected.jsonl'),(WORK/'query_review/final_acceptance.json',OUT/'private_reference/review_acceptance.json')]
    for old,new in destinations:
        new.parent.mkdir(parents=True,exist_ok=True)
        if new.exists():raise ValueError('refuse to replace frozen query/reference')
        shutil.copyfile(old,new)
    save(OUT/'evaluation/group_split.json',{qid:{'group_id':g['group_id'],'split':'development' if g['split']=='dev' else g['split']} for qid,g in groups.items()})
    protocol=dict(schema='finrisk-K-protocol-v1',utc=utc(),queries=24,story_groups=8,development_queries=12,holdout_queries=12,
        query_generation='synthetic_natural_business_paragraphs_from_independent_author',reference='model_silver_independent_session_review_not_expert_gold',
        human_approved=False,split_unit='story triplet; 8 groups, not 24 independent samples',
        experiment_K=dict(fixed_case_rankings=True,fixed_case_text=True,case_context_chars=4000,law_and_guide_chars=4000,
            available_legal_corpus=67,K0='flat screening rules with main articles',K1='scoped mechanism guide with dependency-aware reading',
            retrieval_gain_claim_allowed=False,holdout_opened=False),
        retrieval=dict(corpus_documents=9639,structured_units=65475,routes=['BM25','BGE'],top_per_route=100,RRF_c=60,weights=[1,1],rerank='deepseek-flash',rerank_count=100),
        metrics=dict(K=[1,5,10,20],direct_relevance=3,graded_gains=[0,1,3,7],ndcg_idcg='judged candidate pool',
            unjudged_policy='refuse complete metrics or report explicit missing; never impute zero',global_true_recall=False,
            case_dedup='query-file; best reranked unit per document',recall_name='known_pool_recall_not_full_corpus_recall'),
        acceptance=dict(K='holdout three-state correct count nondecrease; >=1 fewer boundary error; no new normal/unknown error; no citation decline; budget unchanged',
            R='development P5 and NDCG20 nondecrease; >=1 Top1 or >=.03 MRR gain; no new role error; otherwise stop'),
        failure_policy='keep every frozen query; missing judgments are failures, missing relevance remains unjudged; max3 attempts for format only',
        semantic_review='blinded to ranks/arm/expected labels; model silver; no independent expert claim',
        default_auxiliary_route_enabled=False,production_activated=False)
    save(OUT/'contracts/eval_protocol.json',protocol)
    paths=[new for old,new in destinations]+[OUT/'evaluation/group_split.json',OUT/'contracts/eval_protocol.json',WORK/'eval_protocol.py']
    save(OUT/'evaluation/query_freeze.json',dict(utc=utc(),sha256={str(p):sha(p) for p in paths}))
    print(json.dumps(dict(frozen_queries=len(queries),groups=8,new_paid_calls=0)))

if __name__=='__main__':main()
