"""只读expanded实物和实际L2回读；不读K/R排名、分数或模型逐题结果。"""
import sys,json,hashlib,collections
from pathlib import Path
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(r'C:\Users\11051\Documents\Codex\2026-10-09\c-users-11051-desktop-agent-ai')
W=ROOT/'work/finrisk_knowledge_organization_v1_20261018';A=W/'expansion_author';R=W/'expansion_review';OUT=ROOT/'outputs/FinRisk_知识组织增强_v1_20261018';X=OUT/'expanded'
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def fs(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
check=collections.Counter();errors=[]
def ck(ok,k,c):
 check[k]+=1
 if not ok:errors.append(dict(check=k,context=c))
prior=read(R/'final_acceptance.json');ck(prior['assembly_accepted'] is True,'source_material_review_accepted','prior')
for n,h in prior['data_file_sha256'].items():ck(fs(A/n)==h,'accepted_author_snapshot_unchanged',n)
manifest=read(X/'contracts/knowledge_manifest.json');lock=read(X/'contracts/knowledge_lock.json');case_lock=read(OUT/'case_reader/pilot_lock.json');base_manifest=read(OUT/'contracts/knowledge_manifest.json');base_lock=read(OUT/'contracts/knowledge_lock.json')
ck(fs(X/'contracts/knowledge_manifest.json')==lock['manifest_sha256'] and lock['version']=='knowledge-organization-expanded-v1','expanded_manifest_pin','lock')
ck(manifest['enhancement_version']=='knowledge-organization-expanded-v1' and manifest['base_versions']==case_lock['versions']==base_manifest['base_versions'],'expanded_base_version_pin','case/legal content projection rules scope')
ck(fs(OUT/'contracts/knowledge_manifest.json')==base_lock['manifest_sha256'] and base_manifest['enhancement_version']=='knowledge-organization-pilot-v1','pilot_manifest_pin','unchanged pilot profile')
for profile,man in [('expanded',manifest),('pilot',base_manifest)]:
 for name,meta in man['files'].items():
  p=(OUT/name).resolve();ck(p.is_relative_to(OUT.resolve()) and fs(p)==meta['sha256'] and p.stat().st_size==meta['bytes'],'pinned_payload_hash_and_size',profile+':'+name)
beforeinv=read(R/'input_inventory.json')
pilot_unit_meta=next(x for x in beforeinv if x['path'].replace('\\','/').endswith('/case_reader/pilot/units.jsonl'))
ck(fs(Path(pilot_unit_meta['path']))==pilot_unit_meta['sha256'],'pilot_unit_bytes_match_preassembly_review','pilot units')
base={n:rows(OUT/'knowledge'/f'{n}.jsonl') for n in ['mechanisms','case_links','source_spans','source_documents','claim_evidence']}
expanded={n:rows(X/'knowledge'/f'{n}.jsonl') for n in base}
cards={c['mechanism_id']:c for c in expanded['mechanisms']};sources={s['file_id']:s for s in expanded['source_documents']};spans={s['span_id']:s for s in expanded['source_spans']}
ck(len(cards)==12 and set(cards)=={f'M{i:02}' for i in range(1,13)},'twelve_unique_cards','12')
ck(len(sources)==59 and len(spans)==78 and len(expanded['case_links'])==109,'assembled_counts','59/78/109')
ck(len(sources)<=144,'document_cap','59<=144')
for name in ['mechanisms','case_links','source_spans','claim_evidence']:
 ck(expanded[name][:len(base[name])]==base[name],'base_payload_prefix_preserved',name)
for s in base['source_documents']:ck(sources.get(s['file_id'])==s,'base_source_preserved',s['file_id'])
S=read(A/'extension_specs.json');C=rows(A/'selected_cases.jsonl');F={s['file_id']:s for s in rows(A/'fulltext_read_set.jsonl')};U={u['unit_id']:u for u in rows(OUT/'case_reader/pilot/units.jsonl')}
expected_spans={};expected_links=[];correspondence=[]
for c in C:
 src=sources[c['file_id']];ck(src['full_text']==F[c['file_id']]['full_text'] and src['source_sha256']==c['source_sha256'] and src['text_sha256']==c['text_sha256']==sha(src['full_text']),'new_source_matches_reviewed_fulltext',c['selection_id'])
 for q in c['quotes']:
  sid='T10SPAN-'+canon([c['selection_id'],q['quote_id'],q['start'],q['end'],q['text_sha256']])[:24]
  expected=dict(span_id=sid,file_id=c['file_id'],start=q['start'],end=q['end'],text=q['text'],text_sha256=q['text_sha256'],source_sha256=c['source_sha256'],identity='historical_case_literal',coordinate_system='unicode_codepoints_half_open',actor_role=c['actor_role'],attribution_limit=c['attribution_limit'],current_business_fact_proof=False,human_approved=False,review_origin='current_session_model')
  ck(sid not in expected_spans and spans.get(sid)==expected,'new_span_exact_reviewed_material_match',c['selection_id']+':'+q['quote_id']);expected_spans[sid]=expected
  ck(src['full_text'][q['start']:q['end']]==q['text'] and sha(q['text'])==q['text_sha256'],'new_span_literal_and_hash',sid)
  bindings=[b for b in c['candidate_unit_bindings'] if q['quote_id'] in b['quote_ids']] or [None]
  for b in bindings:
   u=U[b['unit_id']] if b else None
   expected_links.append(dict(mechanism_id=c['mechanism_id'],file_id=c['file_id'],event_group_id=c['event_group_id'],span_id=sid,unit_id=b['unit_id'] if b else None,evidence_role='support' if c['support_kind']=='direct_pattern' else 'adjacent',support_limit=c['support_limit'],candidate_associations=u.get('associations',[]) if u else [],actor_role=c['actor_role'],attribution_limit=c['attribution_limit'],binding_status='literal_unit_span_binding_not_independent_attribution' if b else 'source_span_only_no_matching_unit',human_approved=False,review_origin='current_session_model',current_business_fact_proof=False))
  correspondence.append(dict(selection_id=c['selection_id'],quote_id=q['quote_id'],start=q['start'],end=q['end'],quote_sha256=q['text_sha256'],assembled_span_id=sid,link_unit_ids=[b['unit_id'] if b else None for b in bindings]))
newspans=expanded['source_spans'][len(base['source_spans']):];newlinks=expanded['case_links'][len(base['case_links']):]
ck(len(newspans)==16 and {s['span_id'] for s in newspans}==set(expected_spans),'all_sixteen_new_spans_accounted','16')
ck(len(newlinks)==21 and collections.Counter(canon(x) for x in newlinks)==collections.Counter(canon(x) for x in expected_links),'all_twentyone_new_links_exact_match','21')
f1354=[r for r in correspondence if r['selection_id'] in ['T10-M05-F001354','T10-M09-F001354']]
ck(len(f1354)==2 and len({r['assembled_span_id'] for r in f1354})==2 and len({r['quote_sha256'] for r in f1354})==2,'f001354_local_quote_id_collision_resolved','2 distinct T10SPAN')
ck(not cards['M03']['supporting_case_links'] and all(l['evidence_role']=='adjacent' for l in newlinks if l['mechanism_id']=='M03') and cards['M03']['coverage']['case_evidence']=='partial_related_only','m03_adjacent_only','no direct full mechanism case')
ck(not cards['M12']['supporting_case_links'] and not cards['M12']['adjacent_case_links'] and cards['M12']['coverage']['status']=='partial' and cards['M12']['coverage']['selected_documents']==0,'m12_no_case_partial','0')
fact_only=[]
for spec in S['mechanisms']:
 mid=spec['mechanism_id'];c=cards[mid];ck(c['source_constraints']==spec['source_constraints'] and c['scope_axes']==spec['scope_axes'] and c['overview']==spec['overview'],'normative_scope_preserved',mid)
 ck(c['candidate_label_links']==spec['candidate_label_links'] and c['label_mapping_is_automatic'] is False,'no_automatic_label_mapping',mid)
 own=[l for l in newlinks if l['mechanism_id']==mid]
 ck(c['supporting_case_links']==[l for l in own if l['evidence_role']=='support'] and c['adjacent_case_links']==[l for l in own if l['evidence_role']=='adjacent'],'card_link_partition',mid)
 ck(all(c['coverage'].get(k)==v for k,v in spec['coverage'].items()),'original_partial_coverage_preserved',mid)
 for p0,p in zip(spec['predicates'],c['predicates'],strict=True):
  ck(p['predicate_id']==p0['predicate_id'] and p['description']==p0['description'] and p['support_article_ids']==p0['article_ids'] and p['context_article_ids']==p0['context_article_ids'] and p['support_explanation']==p0['support_explanation'],'predicate_mapping_and_scope_unchanged',p['predicate_id'])
  if not p0['article_ids']:
   ck(p['support_kind']=='current_input_fact_requirement' and p['normative_claim'] is False and p['evidence_basis']=='current_input_or_independently_verified_material','fact_only_no_fabricated_norm',p['predicate_id']);fact_only.append(p['predicate_id'])
  else:ck(p['support_kind']==('article_text_with_scope_interpretation' if p0['support_kind']=='原文' else 'assistant_interpretation_of_registered_articles'),'normative_support_kind_preserved',p['predicate_id'])
ck('M07.known_refund_terms' in fact_only,'m07_empty_norm_ref_accepted_as_fact','not statutory assertion')
readback=rows(R/'assembled_l2_readback.jsonl');ck({c['mechanism_id'] for c in readback}==set(cards) and len(readback)==12,'actual_l2_all_twelve_called','12 actual KnowledgeFacade.read_mechanism L2 calls')
L={r['article_id']:r for r in rows(OUT/'legal/articles.jsonl')};l2receipt=[]
for c in readback:
 mid=c['mechanism_id'];raw={k:v for k,v in c.items() if k not in ['case_evidence','legal_evidence']};ck(raw==cards[mid],'l2_card_matches_registered_payload',mid)
 need={l['span_id'] for l in expanded['case_links'] if l['mechanism_id']==mid}
 ck({s['span_id'] for s in c['case_evidence']}==need and all(s==spans[s['span_id']] for s in c['case_evidence']),'l2_all_literal_spans_preserved',mid)
 ck([e['article']['article_id'] for e in c['legal_evidence']]==c['article_ids'],'l2_all_legal_roots_present',mid)
 for e in c['legal_evidence']:
  a=e['article'];ck(a['text']==L[a['article_id']]['text'] and a['text_sha256']==L[a['article_id']]['text_sha256'],'l2_legal_text_preserved',mid+':'+a['article_id'])
 ck(c['human_approved'] is False and c['production_active'] is False and c['current_input_facts_assessed'] is False and c['coverage']['all_mechanism_cases_exhaustive'] is False,'l2_scope_not_overclaimed',mid)
 l2receipt.append(dict(mechanism_id=mid,l2_read=True,serialized_record_sha256=canon(c),literal_case_count=len(c['case_evidence']),legal_root_count=len(c['legal_evidence']),coverage=c['coverage']))
cover=read(X/'navigation/label_coverage.json');official=[r['risk_tag'] for r in read(ROOT/'outputs/FinRisk_正式测试集V2_20261017/official_labels.json')]
ck(len(cover)==27 and [r['risk_tag'] for r in cover]==official,'official_27_label_vocabulary','27')
ck(sum(r['status']=='partial' for r in cover)==16 and sum(r['status']=='uncovered_in_this_enhancement' for r in cover)==11,'sixteen_partial_eleven_uncovered','16/11')
ck(all(r['automatic_assignment'] is False and r['full_legal_boundary_coverage'] is False and r['status'] in ['partial','uncovered_in_this_enhancement'] for r in cover),'labels_no_full_coverage_or_auto_claim','27')
regq=rows(X/'regression/queries.jsonl');ae=rows(A/'smoke_expected.jsonl');aq=rows(A/'smoke_queries.jsonl');regae=rows(X/'regression/extension_expected.jsonl');pilot_expected_ids=[r['query_id'] for r in rows(X/'regression/pilot_expected.jsonl')]
ck(len(regq)==36 and regq[12:]==aq and len(pilot_expected_ids)==12 and [q['query_id'] for q in regq[:12]]==pilot_expected_ids,'thirtysix_scope_inputs','12 original dev +24 scope smoke')
ck(regae==ae,'smoke_expected_accepted_snapshot','same author scope reference')
for e in ae:
 ps=cards[e['mechanism_id']]['predicates'];states=[e['predicate_statuses'][p['predicate_id']] for p in ps if p['required_for_risk']];actual='not_met' if 'not_met' in states else ('unknown' if 'unknown' in states else 'met');ck(actual==e['mechanism_status'],'twentyfour_condition_logic_checks',e['query_id'])
smoke=read(X/'regression/smoke_receipt.json');ck(smoke['model_accuracy_measured'] is False and smoke['total_inputs']==36 and smoke['extension_condition_checks']==24 and smoke['pilot_inputs']==12,'regression_not_accuracy_claim','36 scope receipt')
batches=read(X/'contracts/expansion_batches.json');ck(batches['index_intervention_expanded'] is False and batches['all_eight_new_cards_partial'] is True and batches['acceptance_sha256']==fs(R/'final_acceptance.json'),'assembly_prior_review_and_scope_pin','source material acceptance')
now=datetime.now(timezone.utc).isoformat()
result=dict(status='accepted' if not errors else 'blocked',assembled_data_accepted=not bool(errors),checks=dict(check),errors=errors,counts=dict(cards=12,full_documents=59,source_spans=78,case_links=109,new_spans=16,new_links=21,labels_partial=16,labels_uncovered=11,scope_regression_inputs=36,extension_condition_checks=24),actual_l2_readback=l2receipt,l2_readback_sha256=fs(R/'assembled_l2_readback.jsonl'),new_span_correspondence=correspondence,accepted_fact_only_predicates=fact_only,expanded_manifest_sha256=lock['manifest_sha256'],expanded_profile_version=lock['version'],base_versions=manifest['base_versions'],pilot_manifest_sha256=base_lock['manifest_sha256'],default_profile_still_pilot_four_cards=True,pilot_payload_matches_pin_and_prior_unit_snapshot=True,source_material_acceptance_sha256=fs(R/'final_acceptance.json'),build_script_sha256=fs(W/'build_expanded.py'),m03_adjacent_only=True,m12_no_case_partial=True,condition_logic_is_model_accuracy=False,read_kr_rankings_scores_or_model_per_query_results=False,source_or_production_files_modified=False,human_approved=False,review_origin='current_session_model',production_active=False,reviewed_at=now,scope='12张L2卡与组装证据、版本隔离、标签/冒烟范围的数据验收；不是模型准确率、独立确认集完成、全面法律覆盖或当前事实判定。')
(R/'assembled_acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(status=result['status'],checks=dict(check),errors=errors,counts=result['counts'],fact_only=fact_only,assembled_acceptance_sha256=fs(R/'assembled_acceptance.json')),ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
