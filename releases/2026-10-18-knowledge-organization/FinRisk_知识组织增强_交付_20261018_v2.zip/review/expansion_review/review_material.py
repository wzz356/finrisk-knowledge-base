"""独立复核T10作者资料；只写expansion_review，不执行作者或生产逻辑。"""
import sys,json,hashlib,collections
from pathlib import Path
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(r'C:\Users\11051\Documents\Codex\2026-10-09\c-users-11051-desktop-agent-ai')
W=ROOT/'work/finrisk_knowledge_organization_v1_20261018';A=W/'expansion_author';O=W/'expansion_review';OUT=ROOT/'outputs/FinRisk_知识组织增强_v1_20261018'
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def sha(t):return hashlib.sha256(t.encode('utf-8')).hexdigest()
def fs(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def canon(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def save(n,x,jl=False):
 with (O/n).open('w',encoding='utf-8',newline='\n') as f:
  if jl:
   for r in x:f.write(json.dumps(r,ensure_ascii=False)+'\n')
  else:json.dump(x,f,ensure_ascii=False,indent=2)
names=['extension_specs.json','selected_cases.jsonl','smoke_queries.jsonl','smoke_expected.jsonl','fulltext_read_set.jsonl','article_review_set.jsonl']
hashes={n:fs(A/n) for n in names}
S=json.loads((A/names[0]).read_text(encoding='utf-8'));C=rows(A/names[1]);Q=rows(A/names[2]);E=rows(A/names[3]);F={r['file_id']:r for r in rows(A/names[4])};AR={r['article_id']:r for r in rows(A/names[5])}
L={r['article_id']:r for r in rows(OUT/'legal/articles.jsonl')};SR={r['source_id']:r for r in rows(OUT/'legal/source_registry.jsonl')};U={r['unit_id']:r for r in rows(OUT/'case_reader/pilot/units.jsonl')}
ORIG={r['file_id']:r for r in rows(ROOT/'outputs/FinRisk_P0P1落实_20261018/reference/judging_sources.jsonl')}
DOCS={r['official_file_id']:r for r in rows(ROOT/'outputs/FinRisk_知识库V2_20261012/normalized_final/data/documents.jsonl') if r['official_file_id'] in F}
old48={r['file_id'] for r in rows(W/'source_analysis/selected_cases.jsonl')}
checks=collections.Counter();errors=[]
def ck(ok,k,c):
 checks[k]+=1
 if not ok:errors.append(dict(check=k,context=c))
now=datetime.now(timezone.utc).isoformat();mids=['M07','M08','M05','M06','M03','M09','M10','M12']
ck(S['priority_order']==mids and [m['mechanism_id'] for m in S['mechanisms']]==mids,'eight_mechanism_priority','priority')
ck(len(C)==13 and len(F)==12 and sum(len(c['quotes']) for c in C)==16,'case_counts','13 links / 12 full docs /16 quotes')
ck(len(Q)==len(E)==24,'smoke_counts','24')
ck(len(set(c['selection_id'] for c in C))==13,'selection_id_unique','13')
refs=set();pred_count=collections.Counter();mechanism_reviews=[]
MNOTES={
'M07':'三个predicate均为解释层事实比对，未把披露义务当具体现金价值事实。已读退款、犹豫期和费用上下文；案例F001348保留“第6年承诺/5年末测算”原文各自时点，不自行重算。',
'M08':'已知合同限制与矛盾/拟隐瞒分开。第17/25/26条和保险法17、116作原文规范锚点，责任主体依条区分；两篇案例仅partial_pattern，不补具体免责条款或每保单必不赔。',
'M05':'未来分红及万能最低保证之上利益与合同保证/已归属利益分开；L00313“违规”禁止不能扩成禁止一切保收益。L005一年期以上及设计类型、L007保证期间和待核状态均保留。',
'M06':'实际保险对象是独立事实，性质混同才是禁止行为；收益简单比较和银行代销不能自动等于性质混同。F002023实际话术与管理责任已区分，F003079仅查实摘要。',
'M03':'两项均解释层；债权撤销按538/539对应条件及540—542范围期限后果，税法4仅保险赔款个人所得税，不延伸所有税种/执行/继承。两例仅partial_related，不能升级为绝对扩大完整案例。',
'M09':'第19条公告前禁止宣称及费率区间例外均保留；真实独立公告、无公告查实、仅口头声称分别处理；广告法须先满足商业广告范围。两例均有从未停售/并未限售查实。',
'M10':'实质受托销售与无所需资格分别支持，机构许可与个人执业登记分开；第五条含销售前招揽，未一概排除。F002544换证申辩与许可失效认定、F001768机构/个人子项分开。',
'M12':'取消及商业电话禁止以条例24为锚点，服务/推销归类为解释；拒绝后的必要理赔服务不自动满足营销。不加入L012六个月条件；零案例保持partial，不声称全库无案。'}
for m in S['mechanisms']:
 mid=m['mechanism_id'];ids=set(m['article_ids']+m['context_article_ids']);refs|=ids
 ck(m['coverage']['status']=='partial' and m['coverage']['independent_confirmation_completed'] is False,'partial_research_coverage',mid)
 ck(set(m['case_selection_ids'])=={c['selection_id'] for c in C if c['mechanism_id']==mid},'case_selection_links',mid)
 for p in m['predicates']:
  pred_count[p['support_kind']]+=1
  ck(p['predicate_id'].startswith(mid+'.') and p['support_kind'] in ['原文','解释'] and p['current_fact_status']=='not_assessed' and p['article_text_is_current_fact_proof'] is False,'predicate_identity_and_fact_limit',p['predicate_id'])
  for aid in p['article_ids']+p['context_article_ids']:
   refs.add(aid);ck(aid in ids and aid in L,'predicate_registered_article',p['predicate_id']+':'+aid)
 for aid in ids:ck(aid in L and L[aid]['source_id'] not in ['L011','L012'],'article_admission_no_quarantine',mid+':'+aid)
 for sid,s in m['source_constraints'].items():
  actual=SR[sid]
  for k in ['version','version_id','as_of','declared_effective_date','date_limitations','axes','scope_review','current_law_assertion_mode','remaining_gaps']:
   ck(s[k]==actual[k],'source_constraint_exact_registered_value',mid+':'+sid+':'+k)
 ck({L[i]['source_id'] for i in ids}<=set(m['source_constraints']),'all_article_sources_constrained',mid)
 ck(m['human_approved'] is False and m['production_active'] is False and m['review_origin']=='current_session_model' and m['current_business_fact_proof'] is False and m['historical_case_applicability_confirmed'] is False,'mechanism_research_identity',mid)
 mechanism_reviews.append(dict(mechanism_id=mid,decision='accept_for_research_assembly',predicate_reviews=[dict(predicate_id=p['predicate_id'],support_kind=p['support_kind'],decision='accept') for p in m['predicates']],semantic_review=MNOTES[mid],case_coverage=m['coverage'],human_approved=False,review_origin='current_session_model'))
ck(sum(pred_count.values())==17 and pred_count=={'原文':7,'解释':10},'predicate_support_kind_totals',dict(pred_count))
for aid,a in AR.items():
 ck(aid in L and a['text']==L[aid]['text'] and sha(a['text'])==a['text_sha256']==L[aid]['text_sha256'],'author_article_snapshot_matches_registry',aid)
 ck(a['source_id']==L[aid]['source_id'] and a['version_id']==L[aid]['version_id'],'author_article_version',aid)
for aid in refs:ck(sha(L[aid]['text'])==L[aid]['text_sha256'],'all_47_article_hashes',aid)
case_reviews=[];proof=[];occurrences=[];global_qids=collections.defaultdict(list)
for fid,f in F.items():
 t=f['full_text'];o=ORIG[fid];d=DOCS[fid]
 ck(t==o['full_text']==d['full_text'] and sha(t)==f['source_sha256']==o['source_sha256']==d['text_sha256']==d['source_sha256'],'three_way_fulltext_source_identity',fid)
 proof.append(dict(file_id=fid,full_document_characters_read=len(t),read_ranges=[dict(start=0,end=len(t))],text_sha256=sha(t),source_sha256=f['source_sha256'],model_read_method='本轮逐批完整展示通读，再与原judging_sources及9639当前normalized全文逐字比较',human_approved=False,review_origin='current_session_model'))
for c in C:
 fid=c['file_id'];t=F[fid]['full_text'];sid=c['selection_id'];qd={q['quote_id']:q for q in c['quotes']}
 ck(c['source_sha256']==c['text_sha256']==sha(t),'case_record_hash',sid)
 ck(c['reused_existing_48']==(fid in old48),'case_reuse_flag',sid)
 ck(len(qd)==len(c['quotes']),'quote_id_unique_within_selection',sid)
 for q in c['quotes']:
  ck(0<=q['start']<q['end']<=len(t) and t[q['start']:q['end']]==q['text'],'exact_case_quote_span',sid+':'+q['quote_id'])
  ck(sha(q['text'])==q['text_sha256'] and q['coordinate_system']=='unicode_codepoints_half_open','case_quote_hash_and_coordinates',sid+':'+q['quote_id'])
  ps=[];i=0
  while (i:=t.find(q['text'],i))>=0:ps.append(dict(start=i,end=i+len(q['text'])));i+=1
  ck(any(p['start']==q['start'] and p['end']==q['end'] for p in ps),'case_quote_occurrence_position',sid+':'+q['quote_id'])
  occurrences.append(dict(selection_id=sid,quote_id=q['quote_id'],all_identical_text_positions=ps))
  global_qids[q['quote_id']].append(dict(selection_id=sid,text_sha256=q['text_sha256']))
 ck(c['source_only']==(not c['candidate_unit_bindings']),'source_only_binding_status',sid)
 for b in c['candidate_unit_bindings']:
  u=U[b['unit_id']]
  ck(u['file_id']==b['file_id']==fid and u['source_sha256']==b['source_sha256']==c['source_sha256'],'binding_source_identity',sid+':'+b['unit_id'])
  ck(sha(u['text'])==b['unit_text_sha256'],'binding_unit_text_hash',sid+':'+b['unit_id'])
  ck(b['source_spans']==u['source_spans'],'binding_actual_source_spans',sid+':'+b['unit_id'])
  for qid in b['quote_ids']:
   q=qd[qid];ck(any(s['start']<=q['start'] and q['end']<=s['end'] for s in u['source_spans']),'binding_quote_fully_contained',sid+':'+qid)
  ck(set(b['case_ids'])<=set(u.get('case_ids',[]))|{a['case_id'] for a in u.get('associations',[])},'binding_actual_case_ids',sid)
  ck(set(b['behavior_ids'])<=set(u.get('behavior_ids',[]))|{a['behavior_id'] for a in u.get('associations',[])},'binding_actual_behavior_ids',sid)
  ck(b['actor_role_in_unit']==u.get('actor_role') and b['case_behavior_associations_are_not_independent_actor_proof'] is True,'binding_actor_not_independent_proof',sid)
 ck(c['human_approved'] is False and c['review_origin']=='current_session_model' and c['production_active'] is False and c['historical_case_applicability_confirmed'] is False,'case_research_identity',sid)
 case_reviews.append(dict(selection_id=sid,file_id=fid,mechanism_id=c['mechanism_id'],decision='accept_at_declared_support_level',accepted_support_kind=c['support_kind'],actor=c['actor'],actor_role=c['actor_role'],attribution_review=c['attribution_limit'],product_date_and_strength_review=c['support_limit']+'；行为日期按原文及behavior_date_or_limit保留，处罚日期不冒充销售日期。',source_only=c['source_only'],source_sha256=c['source_sha256'],quote_count=len(c['quotes']),human_approved=False,review_origin='current_session_model'))
ck(all(c['support_kind']=='partial_related' for c in C if c['mechanism_id']=='M03'),'m03_related_only','2 links')
ck(not any(c['mechanism_id']=='M12' for c in C) and next(m for m in S['mechanisms'] if m['mechanism_id']=='M12')['coverage']['selected_documents']==0,'m12_no_case_partial','0 cases')
both=[c for c in C if c['file_id']=='F001354'];ck(len(both)==2 and len({c['event_group_id'] for c in both})==1,'shared_event_not_double_counted','F001354')
EQ={e['query_id']:e for e in E};SPECS={m['mechanism_id']:m for m in S['mechanisms']};smoke_reviews=[];stories=collections.defaultdict(list)
SMNOTES={
'M07':'具体时点现金价值与无损退保保证相冲突；准确说明损失为not_met；没取得现金价值/费用不当成已知损失。',
'M08':'真实90天等待期及无例外独立给定，拟隐瞒/相反陈述为met；准确说明为not_met；缺合同和独立等待期不能补90天。',
'M05':'未来非保证红利的固定最低承诺为met；区分保证和非保证为not_met；unknown修订已删除开头红利对象限定，产品可同时有保证生存金和非保证红利，现可保持对象unknown。',
'M06':'合同独立确认保险与说成存款冲突；准确区分不成立；缺合同/发行人不能由“存款”反推保险对象。',
'M03':'绝对所有债务/全部税种属解释层过度扩大；条件性说明不成立；单一给付款性质不明只能unknown，不补具体税务结论。',
'M09':'独立无公告/仍销售、独立真实公告、仅说话人自称公告三者分别met/not_met/unknown；未联网不是推翻给定事实的理由。',
'M10':'实质销售、资格缺失为不同事实；只打印证和摆桌椅不自动销售；未给证件和受托方自述不能证明有证/无证。',
'M12':'已取消且拟推销为met；消费者请求的必要理赔服务无夹带为not_met；目的/内容缺失unknown。met修订已将明天改今天，与10月18日对齐。'}
for q in Q:
 id=q['query_id'];e=EQ[id];mid=q['mechanism_id'];stories[q['story_id']].append(q['variant']);spec=SPECS[mid]
 ck(e['mechanism_id']==mid and e['story_id']==q['story_id'] and q['split']=='scope_smoke_only','smoke_target_story_identity',id)
 ck(set(e['predicate_statuses'])=={p['predicate_id'] for p in spec['predicates']},'smoke_predicate_map',id)
 statuses=[e['predicate_statuses'][p['predicate_id']] for p in spec['predicates'] if p['required_for_risk']]
 state='not_met' if 'not_met' in statuses else ('unknown' if 'unknown' in statuses else 'met')
 ck(e['mechanism_status']==state==q['variant'],'smoke_three_state_formal_logic',id)
 ck(e['expected_candidate_labels']==([spec['canonical_label']] if state=='met' else []),'smoke_candidate_label_policy',id)
 ck(q['human_approved'] is False and e['human_approved'] is False and q['review_origin']==e['review_origin']=='current_session_model' and e['external_verification']=='not_performed' and e['purpose']=='same_author_scope_reference_not_independent_confirmation','smoke_not_results_identity',id)
 smoke_reviews.append(dict(query_id=id,story_id=q['story_id'],mechanism_id=mid,query_text_sha256=sha(q['text']),expected_record_sha256=canon(e),decision='accept_for_scope_smoke_only',mechanism_status=state,predicate_statuses=e['predicate_statuses'],semantic_review=SMNOTES[mid],independent_result_evaluation=False,human_approved=False,review_origin='current_session_model'))
ck(len(stories)==8 and all(sorted(v)==['met','not_met','unknown'] for v in stories.values()),'eight_whole_story_triplets','8x3')
rev=json.loads((A/'smoke_review_revision.json').read_text(encoding='utf-8'));before=json.loads((A/'smoke_review_revision_before.json').read_text(encoding='utf-8'));BQ={q['query_id']:q for q in before['queries']};BE={e['query_id']:e for e in before['expected']}
changed=[q['query_id'] for q in Q if q!=BQ[q['query_id']]]
ck(changed==['T10-SMOKE-M05-unknown','T10-SMOKE-M12-met'] and changed==rev['changed_query_ids'],'only_two_smoke_queries_changed',changed)
ck(all(e==BE[e['query_id']] for e in E) and hashes['smoke_expected.jsonl']==before['expected_sha256'],'all_smoke_expected_unchanged','24')
ck(hashes['smoke_queries.jsonl']==rev['queries_sha256_after'] and before['queries_sha256']==rev['queries_sha256_before'],'smoke_revision_hash_chain','before/after')
ck('话题是明年分配的保单红利' not in next(q['text'] for q in Q if q['query_id']=='T10-SMOKE-M05-unknown'),'m05_unknown_conflicting_header_removed','fixed')
ck('今天仍用客户关怀' in next(q['text'] for q in Q if q['query_id']=='T10-SMOKE-M12-met'),'m12_met_date_aligned','fixed')
ck(all(fs(A/n)==h for n,h in hashes.items()),'author_inputs_not_modified_during_review','6 files')
collision={k:v for k,v in global_qids.items() if len({x['text_sha256'] for x in v})>1}
advisories=[dict(id='ER-A01',severity='nonblocking_assembly_requirement',note='F001354-Q01在M05和M09两条selection内指向不同原句。quote_id是selection局部标识，组装时必须用(selection_id,quote_id)作为复合键，或另做通过验证的命名空间转换；不能全局只按quote_id合并。',affected=collision),dict(id='ER-A02',severity='nonblocking_wording',note='M07冒烟的介绍/现在投保与“已交保费”可按拟投保保单年度表理解；可在展示时写“按拟合同第二年末累计已交12000”使时间口径更顺。主机制判断不受影响。'),dict(id='ER-A03',severity='mandatory_limit_preservation',note='M03仅partial_related、M08仅partial_pattern、M12无案例partial；F001348保留第6年承诺与5年末测算区别；5条source-only不得借不相关unit；L007现行待核及L001/8/9/10目录截止2026-08-28须保留。')]
validation=dict(status='passed' if not errors else 'failed',checks=dict(checks),errors=errors,full_document_count=len(F),full_document_characters_read=sum(len(f['full_text']) for f in F.values()),selected_link_count=len(C),quote_count=sum(len(c['quotes']) for c in C),unique_quote_text_count=len({q['text_sha256'] for c in C for q in c['quotes']}),source_only_links=sum(c['source_only'] for c in C),actual_unit_binding_count=sum(len(c['candidate_unit_bindings']) for c in C),reviewed_article_count=len(refs),author_article_snapshots=len(AR),mechanism_count=8,predicate_count=17,smoke_count=24,author_files_modified=False,read_rankings_or_model_results=False,network_or_paid_api_used=False,human_approved=False,review_origin='current_session_model',reviewed_at=now)
save('literal_verification.json',validation);save('mechanism_reviews.jsonl',mechanism_reviews,True);save('case_reviews.jsonl',case_reviews,True);save('smoke_reviews.jsonl',smoke_reviews,True);save('fulltext_read_proof.jsonl',proof,True);save('quote_occurrence_inventory.json',occurrences);save('assembly_advisories.json',advisories)
inventory=[dict(path=str(A/n),sha256=h,bytes=(A/n).stat().st_size) for n,h in hashes.items()]
for p in [OUT/'legal/articles.jsonl',OUT/'legal/source_registry.jsonl',OUT/'legal/manifest.json',OUT/'case_reader/pilot/units.jsonl',ROOT/'outputs/FinRisk_P0P1落实_20261018/reference/judging_sources.jsonl',ROOT/'outputs/FinRisk_知识库V2_20261012/normalized_final/data/documents.jsonl',A/'smoke_review_revision.json',A/'smoke_review_revision_before.json']:
 inventory.append(dict(path=str(p),sha256=fs(p),bytes=p.stat().st_size))
save('input_inventory.json',inventory)
acceptance=dict(status='accepted_for_research_assembly' if not errors else 'blocked',assembly_accepted=not bool(errors),blocking_issues_remaining=errors,accepted_mechanism_ids=mids,accepted_case_selection_ids=[c['selection_id'] for c in C],accepted_smoke_query_ids=[q['query_id'] for q in Q],data_file_sha256={n:hashes[n] for n in names[:4]},fulltext_snapshot_sha256=hashes[names[4]],article_snapshot_sha256=hashes[names[5]],resolved_review_issues=[dict(issue='M05-unknown开头提前限定红利对象',status='resolved_by_author_minimal_revision'),dict(issue='M12-met明天与10月18日判断日期不一致',status='resolved_by_author_minimal_revision')],assembly_conditions=['逐predicate保留原文/解释区分，法规不证明当前业务事实','保留来源版本、目录截止、L007待核、历史适用未确认及全部partial','source-only保持全文证据入口，不猜unit或责任人','以selection_id与quote_id复合识别原句，F001354不能全局按Q01并句','24条仅三态范围冒烟，同作者参考；本审核不是独立模型结果评测，未完成独立确认集'],independent_result_evaluation=False,independent_confirmation_completed=False,production_active=False,human_approved=False,review_origin='current_session_model',reviewed_at=now)
save('final_acceptance.json',acceptance)
print(json.dumps(dict(status=validation['status'],assembly_accepted=acceptance['assembly_accepted'],checks=dict(checks),data_file_sha256=acceptance['data_file_sha256'],errors=errors,final_acceptance_sha256=fs(O/'final_acceptance.json')),ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
