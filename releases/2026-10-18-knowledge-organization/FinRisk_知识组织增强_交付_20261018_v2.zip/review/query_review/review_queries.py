"""独立模型审核的只读输入校验及逐题意见。仅写query_review。"""
import sys,json,hashlib,collections
from pathlib import Path
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(r'C:\Users\11051\Documents\Codex\2026-10-09\c-users-11051-desktop-agent-ai')
W=ROOT/'work/finrisk_knowledge_organization_v1_20261018';A=W/'query_author';O=W/'query_review'
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def file_sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def canon(r):return sha(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':')))
inputs=[A/'queries.jsonl',A/'expected.jsonl',A/'groups.json']
input_before={str(p):file_sha(p) for p in inputs}
Q=rows(inputs[0]);E=rows(inputs[1]);G=json.loads(inputs[2].read_text(encoding='utf-8'))
Q0={r['query_id']:r for r in Q};E0={r['query_id']:r for r in E}
law_paths=[ROOT/'outputs/FinRisk_P0P1落实_20261018/reader/bundle/articles.jsonl',ROOT/'outputs/FinRisk_P0P1落实_20261018/law/supporting_articles.jsonl']
L={a['article_id']:a for p in law_paths for a in rows(p)}
admit=ROOT/'outputs/FinRisk_P0P1落实_20261018/law/article_admission_overlay.jsonl'
AD={r['article_id']:r for r in rows(admit)}
counts=collections.Counter();errors=[];duplicates=[]
def ck(ok,k,c):
 counts[k]+=1
 if not ok:errors.append(dict(check=k,context=c))
def positions(t,s):
 out=[];i=0
 while (i:=t.find(s,i))>=0:out.append(i);i+=1
 return out
def evidence_check(t,v,ctx):
 st=v['start_char'];en=v['end_char'];s=v['quote']
 ck(0<=st<en<=len(t) and t[st:en]==s,'exact_unicode_half_open',ctx)
 ck(v['quote_sha256']==sha(s),'quote_sha256',ctx)
 ck(v['offset_unit']=='unicode_codepoint' and v['interval']=='zero_based_half_open','coordinate_system',ctx)
 ps=positions(t,s)
 if len(ps)>1:duplicates.append(dict(context=ctx,positions=ps))
ck(len(Q)==len(E)==len(G)==24,'row_counts',24)
ck(set(Q0)==set(E0)==set(G)=={f'KO_K{i:03}' for i in range(1,25)},'query_expected_group_ids','24 exact IDs')
for q in Q:
 id=q['query_id'];t=q['text'];r=E0[id]
 ck(set(q)=={'query_id','text','text_sha256'},'query_metadata_separation',id)
 ck(sha(t)==q['text_sha256']==r['text_sha256'],'query_text_hash',id)
 facts={f['fact_id']:f for f in r['facts']}
 ck(len(facts)==len(r['facts']),'unique_fact_ids',id)
 for f in r['facts']:evidence_check(t,f['evidence'],id+':'+f['fact_id'])
 ck(len(r['required_predicate_assessments'])==12 and len({x['mechanism_id'] for x in r['required_predicate_assessments']})==12,'twelve_mechanism_rows',id)
 for m in r['required_predicate_assessments']:
  required=[p['status'] for p in m['predicates'] if p['required_for_risk']]
  state='no_clear_risk' if 'not_met' in required else ('insufficient_info' if 'unknown' in required else 'risk')
  ck(state==m['state'],'predicate_state_formal_logic',id+':'+m['mechanism_id'])
  for p in m['predicates']:
   ck(all(fid in facts for fid in p.get('evidence_fact_ids',[])),'predicate_fact_reference',id+':'+p['predicate_id'])
   for e in p.get('evidence_spans',[]):
    evidence_check(t,e,id+':'+p['predicate_id'])
    ck(any(e==facts[fid]['evidence'] for fid in p['evidence_fact_ids']),'predicate_evidence_matches_fact',id+':'+p['predicate_id'])
 risk=[m['mechanism_id'] for m in r['required_predicate_assessments'] if m['state']=='risk'];unc=[m['mechanism_id'] for m in r['required_predicate_assessments'] if m['state']=='insufficient_info']
 ck(risk==r['mechanism_ids'] and unc==r['uncertain_mechanism_ids'],'state_mechanism_lists',id)
 overall='risk' if risk else ('insufficient_info' if unc else 'no_clear_risk')
 ck(overall==r['overall_state']==G[id]['variant_expected_type'],'overall_state_formal_logic',id)
 ck(r['norm_article_ids']==[n['article_id'] for n in r['norm_basis']],'norm_ids_match_basis',id)
 for n in r['norm_basis']:
  aid=n['article_id'];a=L[aid]
  ck(n['article_text_sha256']==a['text_sha256']==sha(a['text']),'article_text_hash',id+':'+aid)
  evidence_check(a['text'],n['evidence'],id+':'+aid)
  ck(AD[aid]['research_reference_allowed'] is True and AD[aid]['production_active'] is False,'research_admission',id+':'+aid)
 ck(all(a in L for a in r['context_article_ids_read']),'context_article_existence',id)
 ck(r['human_approved'] is False and r['review_origin']=='current_session_model' and r['production_active'] is False,'nonhuman_research_identity',id)
 ck(r['scope']['rule_snapshot_cutoff']=='2026-10-18','dated_rule_cutoff',id)

# 下列为独立模型逐题语义判断，不由author的state自动生成结论。
REASONS={
1:'销售员亲自代点两份订约材料；客户口头请求及透明备注均不能豁免销售人员代确认禁止。没有额外推定客户信息不真实。',
2:'本人阅读、自主选择、亲自确认独立给定；放大字体及解释只属辅助，no_clear_risk仅限M11。',
3:'投保文书环节确定，但“帮着弄好”没有确定操作者；缺过程记录只支持unknown。',
4:'纸质投保声明及免责说明由本人自主签名；代理人员只解释，不能因有免责材料就误判隐瞒免责。',
5:'代理机构从业人员属于销售人员；以自己姓名签并公开旁注代确认，仍是替投保人确认订约材料，不要求先有冒签。',
6:'销售代确认已知；文书可能是投保声明也可能是保单送达后服务单，订约阶段unknown；不能仅凭“确认”触发。',
7:'只保留指导答“知道不确定”的话，未给实际知悉状态；不能由缺失复述认定不懂，也不能认定已懂。',
8:'现有“没弄懂红利为何不确定”仅说明原因理解不足，不必然否定知道红利不确定这一命题；指导答“知道不确定”与真实状态未形成唯一逻辑冲突。',
9:'已准确复述假设与红利不确定，且要求不懂时如实说；无不实指导，不据此宣告全部披露合规。',
10:'明确具体客户明日回访的执行安排；未收费用文件、未了解比例与要求已收已懂直接冲突，不是抽象反面培训材料。',
11:'经理“她肯定早懂”是说话人断言；没有独立交付/理解事实，不能当成真，也不能因资料缺失反推未收未懂。',
12:'完整交付与本人说明费用比例独立给定；要求据实回答并核差异，没有不实指导。',
13:'女儿公开身份只预约、调音量，母亲本人独立答复；主状态正确，但L005第16条费用知悉摘句仅可作万能险回访背景。',
14:'录音自称陈女士只证明身份表述；实际说话者未知，历史女儿接过电话不能补成本次冒名。主状态正确，需调整第16条引用角色。',
15:'女儿以母亲身份独自完成回访且母亲未参与，直接满足冒名机制；不等于已确定女儿违反公司工作人员职责条款。需调整第16条引用角色。',
16:'代理销售人员在合同后回访冒称投保人完成答复，M02成立；销售身份不把该环节转为M11。',
17:'销售员报明身份约回拨、只提示页码，本人自主答复；没有冒名，不据此保证所有辅助安排制度均合法。',
18:'“替他办好”可指预约、转接或冒名答问；题面明确缺通话身份与答问材料，impersonation应unknown。',
19:'投保人及成交一千元承诺确定；“合同计划”是销售口头自述，缺真合同，不足以判合同外或内。',
20:'真实合同内第六周年生存年金已给定，销售说明条件且无额外返钱；M04不成立，客户“送”字不能改合同性质。',
21:'真实完整合同无开单现金/券，工作人员另向投保人承诺成交券；公司工作人员主体对应116条，承诺无须兑现。',
22:'真实合同内按意外事故和等级给付保险金，说明条件且否认另给成交奖励；本机制不成立，一年期产品未套L005长期规则。',
23:'代理人员承诺给投保人两百元且成交绑定；所称“方案已写”未获独立证实，合同内外应unknown。',
24:'代理从业人员明确以佣金给投保人额外成交补贴，完整合同无该约定；对应131条，资金来自私人佣金不豁免。'}
REVISION={
8:[dict(issue_id='QR-001',severity='must_fix_before_freeze',field='queries.text and expected.facts/F02 + M01.false_answer_instruction',problem='为何不确定的解释能力与是否知道不确定是两个不同事实。当前risk参考不能唯一成立。',recommended_action='优先最小改题以维持三状态平衡：将“林女士直到结束仍没弄懂红利为何不确定”改为“林女士直到结束仍认为每年的红利金额是确定的，并明确说自己不知道红利可能变化”；保留要求答已知及隐瞒未懂的话。随后重建该题text_sha256、事实引文及全部偏移。若不改题，当前严格M01应保留insufficient_info，不可强冻risk。',expected_state_after_recommended_text_change='risk')],
13:[dict(issue_id='QR-002',severity='must_fix_before_freeze',field='norm_article_ids/norm_basis L005-A0016',problem='费用扣除知悉摘句不直接支持本人身份/冒名条件。当前support_kind“条文文字支持”及通用basis未标此局限。',recommended_action='主依据保留L002-A0035；将L005-A0016从norm_basis及norm_article_ids移至context_article_ids_read，或明确support_kind=product_callback_content_context_only、basis=仅说明万能型产品回访知悉项目，不支持非本人冒名事实/身份条款；不得改变no_clear_risk主状态。')],
14:[dict(issue_id='QR-002',severity='must_fix_before_freeze',field='norm_article_ids/norm_basis L005-A0016',problem='费用知悉项目不能作为身份不明/冒名的直接依据。',recommended_action='同K013处理第16条为背景；保留L002-A0035直接身份依据与insufficient_info状态。')],
15:[dict(issue_id='QR-002',severity='must_fix_before_freeze',field='norm_article_ids/norm_basis L005-A0016',problem='费用知悉项目不能直接证明冒名身份；也不能据公司回访职责直接归责女儿。',recommended_action='同K013处理第16条为背景；保留risk为回访身份机制筛查，明确个体法律责任不在本题判定范围。')]
}
ADVISORIES=[
 dict(issue_id='QR-A01',scope=['KO_K001','KO_K002','KO_K003'],severity='nonblocking_precision',note='L005-A0004现摘句仅“由投保人通过线上或者线下形式”，缺少确认栏/录入/并签字确认；完整条文已读且L002-A0029直接支持足够。可扩大为完整第四条，避免把单纯录入与确认混为一谈。'),
 dict(issue_id='QR-A02',scope=[f'KO_K{i:03}' for i in range(7,13)],severity='nonblocking_precision',note='L002-A0035已标解释层，良好。L005-A0011/A0025也只是回访知悉项目的直接文字，不是对销售预先辅导的独立专项罚则；建议在basis明确“回访内容背景+模型不实辅导推导”。'),
 dict(issue_id='QR-A03',scope=['KO_K020','KO_K022'],severity='nonblocking_predicate_definition',note='transaction_offer=met采用广义经济利益/保险合同给付的解释，最终outside_contract=not_met故主结论正确。若该谓词定义严格限成交奖励，应改为not_met；冻结时应保留一项解释口径，避免把正常条件保险金叫作成交赠礼。'),
 dict(issue_id='QR-A04',scope=[f'KO_K{i:03}' for i in range(1,25)],severity='nonblocking_scope_limit',note='非目标机制的默认not_met只接受为“当前限定输入未出现该触发安排”的筛查门控，不作为真实世界不存在该行为的事实结论。尤M10.substantive_sales不能因无资格事实缺失就否认实质销售；本审核不将12机制全部默认负项提升为逐谓词独立法律金标。'),
 dict(issue_id='QR-A05',scope=['KO_K013','KO_K014','KO_K015'],severity='nonblocking_attribution',note='L002-A0035是保险公司回访职责；M02是身份风险机制，不据此直接判女儿个人违反公司工作人员职责或公司已具备处罚责任全部条件。')
]
now=datetime.now(timezone.utc).isoformat();reviews=[]
for i in range(1,25):
 id=f'KO_K{i:03}';r=E0[id];n=G[id];issues=REVISION.get(i,[])
 target=next(x for x in r['required_predicate_assessments'] if x['mechanism_id']==n['target_mechanism'])
 reviews.append(dict(query_id=id,query_text_sha256=Q0[id]['text_sha256'],expected_record_sha256=canon(r),group_id=n['group_id'],split=n['split'],target_mechanism=n['target_mechanism'],provided_state=r['overall_state'],review_decision='requires_revision' if issues else 'accept',query_natural_business_language=True,query_rule_qa=False,query_text_accept=i!=8,target_state_accept=i!=8,predicate_and_boundary_review=REASONS[i],law_quote_literal_check='passed',law_scope_accept=i not in [13,14,15],story_split_accept=True,accepted_predicate_statuses={p['predicate_id']:p['status'] for p in target['predicates']} if i!=8 else {'M01.review_context':'met','M01.false_answer_instruction':'unknown_on_current_text'},required_revisions=issues,advisory_ids=[a['issue_id'] for a in ADVISORIES if id in a['scope']],freeze_approved=not bool(issues),human_approved=False,review_origin='current_session_model',review_identity='独立资料分析者，本轮未参与query_author题目编写；已接触过案例材料但未读检索/实验结果',reviewed_at=now))
groups=collections.defaultdict(list)
for id,g in G.items():groups[g['group_id']].append((id,g))
story=[]
anchors={
'KO_G01':'周女士、小李、柜面平板、十年期分红保险、投保单及提示书',
'KO_G02':'魏先生、阿岑、村里纸质材料、代理机构、长期养老保险',
'KO_G03':'林女士、销售晨会、十年期分红保险、红利不确定知悉',
'KO_G04':'许女士、培训经理执行交接、八年期投连、费用文件和扣费比例',
'KO_G05':'陈女士与女儿、五年期万能保险、家中电话回访',
'KO_G06':'杜先生与小赵、代理机构门店和车间、长期寿险、销售代接/预约',
'KO_G07':'罗女士与许姐、公司工作人员、长期养老、开单一千元/年金',
'KO_G08':'马先生与老贺、代理机构、一年期意外、交通补贴/事故保险金'}
for gid,members in sorted(groups.items()):
 splits={g['split'] for _,g in members};states={g['variant_expected_type'] for _,g in members}
 ck(len(members)==3 and len(splits)==1 and states=={'risk','no_clear_risk','insufficient_info'},'whole_story_three_variants_single_split',gid)
 story.append(dict(group_id=gid,query_ids=sorted(id for id,_ in members),split=next(iter(splits)),story_anchors=anchors[gid],same_story_kept_in_one_split=True))
dev={q['text'] for q in Q if G[q['query_id']]['split']=='dev'};hold={q['text'] for q in Q if G[q['query_id']]['split']=='holdout'}
ck(not(dev&hold),'no_cross_split_exact_duplicate','query text')
ck(all(not any(s in q['text'] for s in ['M01','M02','M04','M11','risk','insufficient_info','no_clear_risk','第29条','第35条','第116条','第131条']) for q in Q),'no_explicit_reference_answer_in_query_text','all 24')
story_report=dict(status='passed',story_groups=story,manual_cross_split_review='每机制dev/holdout分属两个具不同人物、产品/渠道、操作介质或代答角色的故事；未发现同一人物同一故事的反事实版本跨split。',limitation='8组三变体仍共享任务句式和规则结构，24题只作边界检查，不足以宣称广泛业务泛化或统计独立性；expected、groups、审核意见不得进入实际待检索query文本。',human_approved=False,review_origin='current_session_model')
all_inputs=inputs+law_paths+[admit,ROOT/'outputs/FinRisk_知识库增量改进_20261018/law_review/operational_rules_overlay.json',ROOT/'outputs/FinRisk_P0P1落实_20261018/law/reader_L002.txt']
inventory=[dict(path=str(p),file_sha256=file_sha(p),bytes=p.stat().st_size) for p in all_inputs]
ck(all(file_sha(p)==input_before[str(p)] for p in inputs),'query_author_inputs_unchanged','before/after')
validation=dict(status='passed' if not errors else 'failed',checks=dict(counts),errors=errors,duplicate_quote_contexts=duplicates,query_count=len(Q),expected_count=len(E),norm_article_count=len({a for r in E for a in r['norm_article_ids']}),all_read_article_count=len({a for r in E for a in r['norm_article_ids']+r['context_article_ids_read']}),literal_check_limit='字面/哈希/形式逻辑通过不等于语义或法律范围全部通过；QR-001/002单独阻止4题冻结',query_author_inputs_unchanged=True,human_approved=False,review_origin='current_session_model',reviewed_at=now)
manifest=dict(status='partial_do_not_freeze_entire_set',accepted_query_ids=[r['query_id'] for r in reviews if r['freeze_approved']],requires_revision_query_ids=[r['query_id'] for r in reviews if not r['freeze_approved']],requires_re_review_after_revision=True,entire_set_freeze_approved=False,input_snapshot=inventory[:3],per_query_snapshot=[dict(query_id=r['query_id'],query_text_sha256=r['query_text_sha256'],expected_record_sha256=r['expected_record_sha256'],freeze_approved=r['freeze_approved']) for r in reviews],human_approved=False,review_origin='current_session_model')
def save(name,value,jl=False):
 with (O/name).open('w',encoding='utf-8',newline='\n') as f:
  if jl:
   for r in value:f.write(json.dumps(r,ensure_ascii=False)+'\n')
  else:json.dump(value,f,ensure_ascii=False,indent=2)
save('per_query_review.jsonl',reviews,True);save('literal_checks.json',validation);save('story_split_review.json',story_report);save('freeze_manifest.json',manifest);save('input_inventory.json',inventory);save('advisories.json',ADVISORIES)
print(json.dumps(dict(literal_validation=validation['status'],accepted_count=len(manifest['accepted_query_ids']),requires_revision=manifest['requires_revision_query_ids'],story_split_check='passed',errors=errors),ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
