"""仅定向复审作者四题修订；保留原始审核记录，不覆盖初审意见。"""
import sys,json,hashlib,collections
from datetime import datetime,timezone
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(r'C:\Users\11051\Documents\Codex\2026-10-09\c-users-11051-desktop-agent-ai')
W=ROOT/'work/finrisk_knowledge_organization_v1_20261018';A=W/'query_author';O=W/'query_review'
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def fs(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def save(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
Q={r['query_id']:r for r in rows(A/'queries.jsonl')};E={r['query_id']:r for r in rows(A/'expected.jsonl')};G=json.loads((A/'groups.json').read_text(encoding='utf-8'))
old={r['query_id']:r for r in rows(O/'per_query_review.jsonl')};oldinv=json.loads((O/'input_inventory.json').read_text(encoding='utf-8'))
rv=json.loads((A/'revision_validation.json').read_text(encoding='utf-8'))
hashes={n:fs(A/n) for n in ['queries.jsonl','expected.jsonl','groups.json']}
checks=collections.Counter();errors=[]
def ck(ok,k,c):
 checks[k]+=1
 if not ok:errors.append(dict(check=k,context=c))
ck(hashes['queries.jsonl']=='8d0eb6f80d125b6095294ee01b66e0c39fc6fb8a4de5367732a23733e5ce85ce','requested_queries_snapshot','queries.jsonl')
ck(hashes['expected.jsonl']=='87c2ca25c4ea6344adad1895cba02d6362c141eab6b3242566306019ebcc79b7','requested_expected_snapshot','expected.jsonl')
ck(hashes['groups.json']==oldinv[2]['file_sha256'],'groups_original_file_hash','groups.json')
ck(len(Q)==len(E)==len(G)==24 and set(Q)==set(E)==set(G)==set(old),'complete_id_set','24 IDs')
revised=['KO_K008','KO_K013','KO_K014','KO_K015'];prior=[q for q in sorted(Q) if q not in revised]
ck(rv['revised_ids']==revised and rv['accepted_20_byte_identical'] is True and rv['groups_byte_identical'] is True,'author_revision_validation_claims','4 changes / 20 unchanged')
for n in hashes:
 before=next(x['file_sha256'] for x in oldinv[:3] if Path(x['path']).name==n)
 ck(rv['file_hashes'][n]['before']==before and rv['file_hashes'][n]['after']==hashes[n],'revision_validation_hash_chain',n)
for id in prior:
 ck(sha(Q[id]['text'])==Q[id]['text_sha256']==old[id]['query_text_sha256'],'prior_accepted_query_snapshot_unchanged',id)
 ck(canon(E[id])==old[id]['expected_record_sha256'] and old[id]['freeze_approved'] is True,'prior_accepted_expected_snapshot_unchanged',id)
for id in revised[1:]:ck(Q[id]['text_sha256']==old[id]['query_text_sha256'],'citation_only_revision_query_unchanged',id)
law={r['article_id']:r for r in rows(ROOT/'outputs/FinRisk_P0P1落实_20261018/reader/bundle/articles.jsonl')}
def ev(t,e,ctx):
 ck(t[e['start_char']:e['end_char']]==e['quote'] and e['end_char']-e['start_char']==len(e['quote']),'targeted_literal_span',ctx)
 ck(sha(e['quote'])==e['quote_sha256'],'targeted_quote_hash',ctx)
 ck(e['offset_unit']=='unicode_codepoint' and e['interval']=='zero_based_half_open','targeted_coordinates',ctx)
for id in revised:
 q=Q[id];r=E[id];t=q['text'];facts={f['fact_id']:f for f in r['facts']}
 ck(sha(t)==q['text_sha256']==r['text_sha256'],'revised_query_hash',id)
 for f in r['facts']:ev(t,f['evidence'],id+':'+f['fact_id'])
 for m in r['required_predicate_assessments']:
  req=[p['status'] for p in m['predicates'] if p['required_for_risk']]
  state='no_clear_risk' if 'not_met' in req else ('insufficient_info' if 'unknown' in req else 'risk')
  ck(m['state']==state,'targeted_mechanism_formal_logic',id+':'+m['mechanism_id'])
  for p in m['predicates']:
   ck(all(fid in facts for fid in p.get('evidence_fact_ids',[])),'targeted_fact_references',id+':'+p['predicate_id'])
   for e in p.get('evidence_spans',[]):
    ev(t,e,id+':'+p['predicate_id'])
    ck(any(e==facts[fid]['evidence'] for fid in p['evidence_fact_ids']),'targeted_predicate_evidence_identity',id+':'+p['predicate_id'])
 ck(r['norm_article_ids']==[n['article_id'] for n in r['norm_basis']],'revised_norm_list',id)
 for n in r['norm_basis']:
  a=law[n['article_id']]
  ck(sha(a['text'])==a['text_sha256']==n['article_text_sha256'],'targeted_article_hash',id+':'+a['article_id'])
  ev(a['text'],n['evidence'],id+':'+a['article_id'])
 ck(r['human_approved'] is False and r['production_active'] is False and r['review_origin']=='current_session_model','targeted_identity',id)
 for n in ['L005-A0016','L005-A0029']:
  if id!='KO_K008':ck(n in r['context_article_ids_read'] and n not in r['norm_article_ids'],'product_content_background_not_identity_norm',id+':'+n)
 if id!='KO_K008':ck(r['norm_article_ids']==['L002-A0035'],'sole_direct_identity_norm',id)

k8=E['KO_K008'];m8={m['mechanism_id']:m for m in k8['required_predicate_assessments']}
ck(set(m8)=={f'M{i:02}' for i in range(1,13)} and k8['overall_state']=='risk' and k8['mechanism_ids']==['M01'] and not k8['uncertain_mechanism_ids'],'k008_all_twelve_states','M01 only risk')
ck(all(m['state']=='no_clear_risk' for mid,m in m8.items() if mid!='M01'),'k008_other_eleven_states','no new false positive')
ck('实际上并不知道红利分配具有不确定性' in Q['KO_K008']['text'] and '就答已经知道' in Q['KO_K008']['text'],'k008_same_proposition_conflict','not know uncertainty / claim know uncertainty')
ck({p['predicate_id']:p['status'] for p in m8['M01']['predicates']}=={'M01.review_context':'met','M01.false_answer_instruction':'met'},'k008_m01_predicates','met/met')
for id,state in [('KO_K013','no_clear_risk'),('KO_K014','insufficient_info'),('KO_K015','risk')]:
 ck(E[id]['overall_state']==state,'m02_states_retained',id)
 ck(next(m for m in E[id]['required_predicate_assessments'] if m['mechanism_id']=='M02')['state']==state,'m02_target_states_retained',id)
ck(all(fs(A/n)==h for n,h in hashes.items()),'input_not_mutated_during_recheck','three data files')
now=datetime.now(timezone.utc).isoformat()
validation=dict(status='passed' if not errors else 'failed',targeted_query_ids=revised,checks=dict(checks),errors=errors,file_hashes=hashes,author_revision_validation_sha256=fs(A/'revision_validation.json'),prior20_canonical_snapshot_and_query_hash_unchanged=True,author_prior20_byte_identity_proof_accepted=True,groups_byte_hash_unchanged=True,inspected_retrieval_or_experiment_outputs=False,human_approved=False,review_origin='current_session_model',reviewed_at=now)
save('recheck_validation.json',validation)
if errors:
 print(json.dumps(validation,ensure_ascii=False,indent=2));raise SystemExit(1)
notes={
'KO_K008':'修订已独立给定客户不知道红利分配不确定，与销售要求答已知道是同一命题的真答冲突，M01 risk可唯一成立。客户自己的错误认知不是销售保证收益，M05仍no_clear_risk；本人答访非M02，合同后安排非M11。全部12机制状态已重核。',
'KO_K013':'直接身份规范仅L002-A0035；万能险费用知悉L005-A0016及一年期以上范围L005-A0029已移到context。公开身份预约与本人独立答复，no_clear_risk保留。',
'KO_K014':'规范与产品背景已分开；实际说话者仍未知，自称身份和历史女儿接电话没有被当成当前真实身份，insufficient_info保留。',
'KO_K015':'规范与产品背景已分开；女儿冒称母亲完成身份及知悉确认，risk保留；仅认定身份机制，不据公司职责条文直接确定女儿或公司处罚责任。'}
decisions=[]
for id in sorted(Q):
 decisions.append(dict(query_id=id,group_id=G[id]['group_id'],split=G[id]['split'],overall_state=E[id]['overall_state'],target_mechanism=G[id]['target_mechanism'],query_text_sha256=Q[id]['text_sha256'],expected_record_sha256=canon(E[id]),decision='accept',acceptance_basis='targeted_revision_recheck' if id in revised else 'prior_accepted_unchanged_snapshot',review_note=notes.get(id,'沿用初审接受意见；题面哈希及expected规范化记录哈希与已接受快照一致。')))
accept=dict(status='accepted',freeze_status='accepted_for_research_evaluation_freeze',all_24_freezable=True,entire_set_freeze_approved=True,model_review_acceptance=True,query_count=24,accepted_query_ids=sorted(Q),file_hashes=hashes,data_files=[dict(name=n,path=str(A/n),sha256=h) for n,h in hashes.items()],targeted_recheck_query_ids=revised,prior_accepted_unchanged_query_ids=prior,query_acceptance=decisions,blocking_issues_remaining=[],resolved_issue_ids=['QR-001','QR-002'],supersedes=['query_review/freeze_manifest.json','query_review/review_summary.md中的修订前阻断状态'],initial_review_records_retained=True,recheck_validation_file='recheck_validation.json',recheck_validation_sha256=fs(O/'recheck_validation.json'),scope='全部24题在本次三文件SHA快照上可冻结为本轮合成业务边界研究评测参考；冻结接受不是人工批准、独立专家金标、外部真实性核验或生产启用。原非阻断口径/范围建议保留，no_clear_risk仅限题面筛查。',rule_snapshot_cutoff='2026-10-18',inspected_retrieval_or_experiment_outputs=False,query_author_files_modified=False,human_approved=False,review_origin='current_session_model',production_active=False,reviewed_at=now)
save('final_acceptance.json',accept)
print(json.dumps(dict(status='accepted',all_24_freezable=True,file_hashes=hashes,checks=dict(checks),final_acceptance_sha256=fs(O/'final_acceptance.json')),ensure_ascii=False,indent=2))
