# 封包前代码只读审核

2026-10-18。审查 `verify_release.py`、`cli.py`、`package_release.py`、`tests/test_release_manifest.py`。**当前受审文件树通过，无已知封包阻断。** 本审查未运行正式package、未写交付目标、未读真实凭据、未调用API；正式便携交付是否完成，以随后实际解压验证回执为准。

## 指定根目录与重放

将已载入模块中48处ROOT/OUT/V2等全局路径替换为不存在的目录后，`verify(explicit_root, require_manifest=False)` 在 `-S -B` 标准库环境仍真实通过。验证读取732个unit、481份文书、740个登记span、960个旧读取位置、67条法规、pilot4/expanded12张卡；维护图4313节点、无变化。

K实际重新计算并比较完整metrics/per_query/retrieval输出；两阶段各24条判断、accepted共41、开发7次失败保留，保留门槛false。R重放245共享参考、1200份exact请求/响应绑定和控制版排序，12题指标及失败门槛相符。敏感性、已知池覆盖和费用均从显式root重算；未重跑模型或全库检索。此前独立指标/41份盲审/235项引用审核结论保持，未发现本轮严重遗漏。

CLI夹具确认显式`--root`原样转交验证器且要求manifest；非原OUT不能使用`--workspace-check`。暂存路径位于root内、root祖先或root.parent之外均拒绝，仅允许新外部兄弟范围；测试用替代构建器确认参数转交，未执行实际重建。foreign root的package入口在写入前拒绝。历史open-holdout只回读已有回执，不运行新调用。

## 清单、打包和解压

原3项清单测试通过：完整清单成功，增删改、重复及逃逸路径拒绝。源码对manifest载荷逐项校验尺寸/SHA，并要求清单与实际文件等集；ZIP仅新建，解压前逐项检查解析后路径仍在新解压根内，完成后以该解压root启动标准库离线验证。

凭据/格式护栏修订后的独立小夹具通过：`.env`、`secret.pem`、未知后缀、`credentials.json`拒绝；普通scope标识允许；合成Windows reparse目录属性拒绝。实际目录junction创建被本环境拒绝（Access denied），故没有宣称实际junction创建测试通过。已枚举当前OUT与三个review输入树，未发现链接、常见凭据文件名或模型权重文件名；实际 `check_file_policy(OUT)` 返回True。

早先scope被key前缀扫描误判、运行锁非空及tests缓存拷贝的问题均已关闭：扫描增加左边界并统一入口；原运行锁不改，复制时排除lock；tests和review复制排除缓存目录。最后一项修改已静态确认。所有失败记录和未用于最终R控制版的付费响应仍在源产物中，不因排除运行锁/缓存而移除审计数据。

范围提示：review复制源当前无链接；通用复制使用默认跟随链接行为，若未来新增review链接，应在复制前对源树再次做链接预检，不能只依赖复制后检查。这不阻断本次已枚举的无链接输入树。

## 受审版本

- `package_release.py`：`e3697eb4b5db24dc21ea142293d65e07c05649509695150b598a1b973d3777d5`
- `verify_release.py`：`1351328a30f1e208f29203b8f0fea959614ac3b2cfc8849487e0905e5e048cae`
- `cli.py`：`8368577fa257c7d01cf6260855030f036ba40e24d8d988033c9c7947d94f6a6d`

本轮13项独立CLI/路径/策略夹具通过，另有3项现有清单测试通过。未修改生产代码或既有指标/参考。本报告不把模型银标、有限知识卡或已判Top20池覆盖表述为专家金标或全库召回。
