"""Final read-only K audit; actual expected is used only inside calculate()."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

WORK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(WORK))
import evaluate_k
from common import OUT

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def rows(p):return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    before=read(WORK/'code_review/K_integrity_before_sha.json')
    assert all(sha(p)==d for p,d in before.items())
    fresh=evaluate_k.calculate(OUT,WORK/'semantic_review')
    per=fresh.pop('per_query');retrieval=fresh.pop('retrieval')
    assert per==rows(OUT/'experiment_K/per_query_results.jsonl')
    assert retrieval==rows(OUT/'experiment_K/retrieval_per_query.jsonl')
    assert fresh==read(OUT/'experiment_K/metrics.json')
    evidence={}
    total_reviews=total_cases=total_laws=0
    totals=Counter()
    groups=read(OUT/'evaluation/group_split.json')
    for split in ['development','holdout']:
        maps=rows(OUT/'experiment_K'/f'judgment_map_{split}.jsonl')
        accepted=rows(OUT/'api'/f'K_{split}_judgment/accepted.jsonl')
        accepted_by={r['pair_id']:r['parsed'] for r in accepted}
        mapped={r['pair_id']:r for r in maps}
        blindmap=rows(OUT/'evaluation'/f'semantic_review_mapping_{split}.jsonl')
        reviews=rows(WORK/'semantic_review'/f'{split}_review.jsonl')
        by_decision={r['decision_id']:r for r in reviews}
        blind={r['decision_id']:r for r in rows(WORK/'semantic_review'/f'{split}_blind.jsonl')}
        assert len(blind)==len(blindmap)==len(reviews)==len(accepted)
        assert set(blind)==set(by_decision)=={m['decision_id'] for m in blindmap}
        case_count=law_count=0
        review_status=Counter()
        for m in blindmap:
            assert m['query_id']==mapped[m['pair_id']]['query_id'] and m['arm']==mapped[m['pair_id']]['arm']
            p=accepted_by[m['pair_id']];r=by_decision[m['decision_id']];b=blind[m['decision_id']]
            assert b['model_inputs_do_not_include_reference_answers'] is True
            assert all(b['decision'][k]==p[k] for k in b['decision'])
            cases=r['case_citation_reviews'];laws=r['law_citation_reviews']
            assert len(cases)==len({c['cite_id'] for c in cases}) and {c['cite_id'] for c in cases}==set(p['case_unit_ids'])
            assert len(laws)==len({c['cite_id'] for c in laws}) and {c['cite_id'] for c in laws}==set(p['legal_article_ids'])
            assert r['human_approved'] is False
            case_count+=len(cases);law_count+=len(laws)
            review_status.update(c['status'] for c in cases+laws)
        split_per=[r for r in per if r['split']==split]
        assert sum(p['facts_and_semantics_reviewed'] for p in split_per)==len(accepted)
        assert sum(p['accepted'] for p in split_per)==len(accepted)
        assert sum(not p['accepted'] for p in split_per)==24-len(accepted)
        for arm in ['K0','K1']:
            part=[r for r in split_per if r['arm']==arm]
            summary=fresh['summary'][split][arm]
            assert len(part)==summary['queries']==12
            assert summary['state_accuracy']==sum(r['state_correct'] for r in part)/12
            cases=[s for r in part for s in r['case_citation_statuses']]
            laws=[s for r in part for s in r['law_citation_statuses']]
            assert summary['case_citations']==len(cases) and summary['law_citations']==len(laws)
            assert summary['case_citation_counts']==dict(Counter(cases)) and summary['law_citation_counts']==dict(Counter(laws))
            assert summary['semantic_citation_support_rate']==(cases+laws).count('supported')/len(cases+laws)
            assert summary['semantic_boundary_error_decisions']==sum(bool(r['semantic_boundary_flags']) for r in part)
        qs={m['query_id'] for m in maps}
        story_counts=Counter(groups[q]['group_id'] for q in qs)
        assert len(qs)==12 and len(story_counts)==4 and set(story_counts.values())=={3}
        evidence[split]=dict(queries=12,story_groups=4,mapped_decisions=len(maps),accepted=len(accepted),format_failures=24-len(accepted),blind_reviews=len(reviews),case_citations=case_count,law_citations=law_count,citation_statuses=dict(review_status))
        total_reviews+=len(reviews);total_cases+=case_count;total_laws+=law_count;totals.update(review_status)
    h0=fresh['summary']['holdout']['K0'];h1=fresh['summary']['holdout']['K1']
    assert h0['state_correct']==12 and h1['state_correct']==11
    assert h0['semantic_boundary_error_decisions']==8 and h1['semantic_boundary_error_decisions']==9
    assert fresh['holdout_trial_gate']==dict(passed=False,state_correct_nondecrease=False,boundary_error_reduced=False,no_new_nonrisk_errors=True,citation_support_nondecrease=False)
    assert evidence['development']['accepted']==17 and evidence['development']['format_failures']==7
    assert evidence['holdout']['accepted']==24 and evidence['holdout']['format_failures']==0
    assert total_reviews==41
    assert all(sha(p)==d for p,d in before.items())
    result=dict(passed=True,calculate_equals_all_three_original_outputs=True,original_output_and_reference_sha_unchanged=True,
                protected_sha256=before,split_evidence=evidence,total_blind_reviews=total_reviews,total_case_citations=total_cases,
                total_law_citations=total_laws,total_citation_statuses=dict(totals),holdout_trial_gate=fresh['holdout_trial_gate'],
                evaluate_k_sha256=sha(WORK/'evaluate_k.py'),no_API=True,no_answers_emitted=True)
    (WORK/'code_review/K_final_integrity_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='protected_sha256'},ensure_ascii=False))

if __name__=='__main__':main()
