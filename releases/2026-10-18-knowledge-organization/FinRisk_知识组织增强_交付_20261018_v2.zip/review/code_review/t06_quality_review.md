# T06 代码与开发输入质量审查

日期：2026-10-18。身份：独立助手审查，`review_origin=current_session_model`，`human_approved=false`。

结论：本轮 K 代码修复和已准备的开发输入通过，无剩余实质阻断。24份 development judgment 与240份盲相关性请求可以按既有全轮2美元授权执行；不新增额度，不放行未审的 R 实际输入或其他新批次，不代表 T06结果或采用门槛已通过。

## 最初问题与修复复审

初审发现下游没有完整验证冻结输入/接受结果绑定，且 prepare_judgments 只检查最后共24个job；用11个development和真实holdout `KO_K004` 混合的12题夹具，曾成功生成development的24任务。另缺少holdout候选配置冻结和一次开启记录。主代理在下游付费判断前修复。

最新复审结果：

- `check_stage` 校验query/retrieval冻结；`rank`核对jobs与accepted SHA、完整1200 ID集合、逐响应bodySHA及validator，生成rankings冻结；`checked_rankings`在快照和请求生成前验证冻结、指定split的12个唯一qid、Top20唯一file/unit及原candidate_map绑定。
- 原混入holdout夹具现被 `ranking split/query set mismatch` 拒绝，且 `build_snapshot` 尚未调用。夹具显式mock了全库快照，未重复全库扫描。
- 以实际1200个接受结果及公开小型输入，在审查目录独立调用rank，成功生成12题、每题Top20唯一文件的排名；没有修改生产排名文件。
- holdout未开启时拒绝；显式open冻结候选代码、知识清单、协议、规则和原词表/router；重复open拒绝，修改候选冻结记录后拒绝。验证在审查目录公共小型夹具内执行，未读取实际private expected或重新哈希大索引。
- API执行端从真实query_text查询冻结split，phase必须为注册的K/R、development/holdout和任务种类；holdout文本即使换phase也须经过holdout门槛，均发生在凭据读取前。

## 实际24份两臂判断输入

- 精确12个development query，每题K0/K1各1份，24个唯一pair；未包含holdout。
- 每题两臂case完整文本和case_unit_ids逐字/逐项相同；仅知识文本改变；没有把机制卡支持案例加入模型实际案例。
- 每臂案例文字不超过4000 Unicode字符，法规/指引不超过4000；共同可用法规注册为67条。K0平铺解释和主条，K1按卡片与依赖组织；所有展示法条ID可解析。
- 用真实facade和同一Top20候选重新组装K1，每题案例文字、知识文字及included case IDs与实际job全等。
- current_text匹配冻结公开查询；必要条件ID及候选机制来自已冻结规则/router，不读取expected。router复用原auxiliary词表/函数，最多2个假设，无触发时退回4机制；并非按逐题参考调参。
- 两臂请求共享同一JUDGMENT_SYSTEM，历史证据、当前事实和解释身份分开；coverage明确适用范围未外部核准，未将缺项改成已满足。

## 实际240份盲相关性输入

- 精确12个development query，每题20个不同file，共240个唯一pair；全部文件属于该题真实排名Top20。
- 模型用户消息严格只有 `pair_id/current_text/source_paragraphs`；packet只含允许的span IDs。没有rank、arm、参考标签、目标答案或逐题预期字段。
- 所有段落的文字和坐标逐项匹配真实案例快照全文；source_text_sha256重算全等。使用共同RELEVANCE_SYSTEM，仅给评分准则，不给排名或答案。
- 当前开发案例快照实载665个单元、438份文书；读取器已按基础版本及固定manifest装载校验。没有把48份卡片选材当成全库召回范围。

## 其余规格核对

- retrieve_k先在全9639文书/65475结构化单元上执行BM25/BGE各Top100、RRF常数60/权重1:1；之后才收集实际候选来源做读取快照，未按48份选材或导航目录预过滤。
- retrieve_r源码同样在全库召回，仅替换指定表示的局部向量和稀疏表示，原向量以只读映射载入并在末尾复核SHA；本轮未重跑或验收其实际overlay/R结果，后续单独送审。
- 实际冻结group_split为8组三联体，每组不跨split，development/holdout各12。当前holdout_open仍不存在。
- ranking_metrics对未标文书抛错，不补0；`known_pool_recall`和`NDCG_pool`明确已判断候选池，`global_true_recall=false`。文件去重在重排后选每文件最佳单元；开发候选Top100实际每题55—83份不同文书。

## 实际验证与指纹

- `test_eval_protocol.py`：2项通过；`test_experiment_contracts.py`：1项通过；最新 `test_api_guard.py`：7项通过。未运行其他不相关测试。
- `t06_targeted_checks.json` 保存混split拒绝、实际1200评分排名绑定、holdout状态夹具结果。
- `t06_prepared_inputs_audit.json` 保存24判断、240盲相关性、预算、两臂SHA、原句及实际快照核验结果。
- `experiment_k.py` SHA256：`e16ac70762242cecc3a9bcfe8c53113171e6f6a24a5fb80db9b4b1b71238a07d`。
- 当前 `api_jobs.py` SHA256：`a539867187ea2b423c36b8085ec7e840056d6e598d9d4b13172573af93d01317`（包括runner源码存档及R prepare额外绑定检查）。
- 判断job SHA256：`66ebcc47bfbbfff13b2868ced05259d00ed9121fc8fb4f23e0e45a97f95144a2`。
- 盲相关性job SHA256：`5c5da52293b4a08b202951979f418b921cc6ee4dda6a582f4d29a17bf8b84c1d`。

本次未读取private expected、未读密钥、未调用网络或收费API、未重复全库召回，也未修改生产代码/OUT。实际判断与标注结果、最终指标、保留实验及R仍须另审，不能用本次输入审查代替。
