# R 查询向量控制版定向复审

日期：2026-10-18。身份：独立助手复审，`review_origin=current_session_model`，`human_approved=false`。

结论：通过，前轮查询向量控制变量 Important 已关闭。可用控制集合从全局 exact accepted cache 重新选分、去重、排序和复算，所需新 API 调用为0；不能直接照搬旧R整套排名或指标。本结论不表示R开发门槛或保留实验通过。

独立核验：

- `retrieve_r_controlled.py` 不实例化编码器、不发送API，按qid选取K原query_vectors行，复用原R的20个context向量，在同一冻结9639文书/65475单元上本地重算。新旧产物隔离，未修改K冻结源码或原R冻结。
- 直接解析实际NPY文件，12行查询向量的dtype、形状和每行字节与K对应development行完全一致。
- 对照实际路由：BM25全12题一致；RRF Top100候选集合11/12题一致。唯一 `KO_K014` 新增 `structured:F002607:V2:5e6051822b1b16f2ffc5dad828e105af92c0ce41e753ec800cd7f846ad73d9ca`，移除 `structured:F002034:V2:c8d7f2ff38993ce5fbe41fd3aa14a83fdb4542a5e847cbbb929308f1b7443085`。
- 控制版1200份packet中1199份与原R完整字典全等，另1份为新候选；全部packet文本SHA与candidate_map对应，unit均属于该题控制版RRF集合。
- 新packet为 `KO_b313dae84b1679af9aecae4f`；构造实际请求后body SHA为 `adac143133d8f09105a5d9d3e19648facf1b428ae6e50e42c4b95ef3e1905010`，与 `K_development_rerank` 已接受记录完全匹配；delta_jobs也与该构造结果全等。
- 全部1200份控制请求均通过现有结果校验器，已有exact缓存：1183份来自K、17份来自旧R。旧R曾新增的18次评分中1份未进入控制集合，其实际费用和原始结果仍须保留。
- 独立重新核对9个控制输出和32个小型公开输入的SHA；不重复大索引/原向量计算。结果与实现者 `r_control_task/verification.json` 的控制差异、零新增请求结论一致。

证据：`R_controlled_rereview.json`。

固定指纹：

- 控制脚本：`fdf4f9d9e0fb0326bfdc20cb607f7559d074ceb69e408c99f0cd4237fc59b8c0`。
- 控制retrieval_freeze：`aafd60e0c48f470d252b650f1d94863942abc43a179e600d62a86833d953e8ea`。
- 控制rerank_inputs：`e69b3b33cb3704425fea5a7903b734e09114ec7bd84901739a730c77a394ad42`。

未读private_reference，未读密钥，未调用网络、收费API或重新执行全库打分。后续结果应使用控制版实际候选重排，原R作为数值敏感性记录保留。
