"""Independent integrity fixtures; all answers here are synthetic."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

WORK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(WORK))
import evaluate_k

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def rows(p):
    return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]

def save(p,value,lines=True):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(json.dumps(v)+'\n' for v in value) if lines else json.dumps(value),encoding='utf-8')

def make_fixture(root):
    groups={f'Q{i:02}':dict(group_id=f'G{(i-1)//3:02}',split='development' if (i-1)//3%2==0 else 'holdout') for i in range(1,25)}
    save(root/'evaluation/group_split.json',groups,False)
    save(root/'private_reference/expected.jsonl',[dict(query_id=q,overall_state='risk',mechanism_ids=['M'],required_predicate_assessments=[]) for q in groups])
    for split in ['development','holdout']:
        qs=[q for q,g in groups.items() if g['split']==split]
        maps=[dict(query_id=q,arm=a,pair_id=f'{q}_{a}',case_chars=100,knowledge_chars=100) for q in qs for a in ['K0','K1']]
        accepted=[dict(pair_id=m['pair_id'],parsed=dict(pair_id=m['pair_id'],state='risk',mechanism_ids=['M'],predicates={})) for m in maps]
        if split=='development':
            missing={f'{q}_K0' for q in qs[:3]}|{f'{q}_K1' for q in qs[:4]}
            accepted=[a for a in accepted if a['pair_id'] not in missing]
        blind=[dict(pair_id=a['pair_id'],decision_id='D_'+a['pair_id']) for a in accepted]
        reviews=[dict(decision_id=b['decision_id'],boundary_error_flags=['boundary'] if b['pair_id'].endswith('K0') else [],case_citation_reviews=[dict(status='supported')],law_citation_reviews=[]) for b in blind]
        save(root/f'experiment_K/judgment_map_{split}.jsonl',maps)
        save(root/f'api/K_{split}_judgment/accepted.jsonl',accepted)
        save(root/f'evaluation/semantic_review_mapping_{split}.jsonl',blind)
        save(root/f'reviews/{split}_review.jsonl',reviews)
        save(root/f'experiment_K/qrels_{split}_effective.jsonl',[dict(query_id=q,file_id=f'F{i:02}',grade=3) for q in qs for i in range(20)])
        save(root/f'experiment_K/rankings_{split}.jsonl',[dict(query_id=q,ranking=[dict(file_id=f'F{i:02}') for i in range(20)]) for q in qs])

class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent,prefix='k_integrity_')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        make_fixture(self.root)

    def calculate(self):
        return evaluate_k.calculate(self.root,self.root/'reviews')

    def change(self,path,fn):
        data=rows(self.root/path)
        fn(data)
        save(self.root/path,data)

    def rejects(self):
        with self.assertRaises(ValueError):self.calculate()

    def test_complete_fixture_keeps_7_failures_in_12_per_arm(self):
        result=self.calculate()
        self.assertEqual(result['summary']['development']['K0']['state_accuracy'],9/12)
        self.assertEqual(result['summary']['development']['K1']['state_accuracy'],8/12)
        self.assertEqual(sum(result['summary']['development'][a]['format_failures'] for a in ['K0','K1']),7)
        self.assertTrue(result['holdout_trial_gate']['passed'])

    def test_missing_frozen_query_is_rejected(self):
        self.change('experiment_K/judgment_map_holdout.jsonl',lambda x:x.__delitem__(slice(-2,None)))
        self.rejects()

    def test_duplicate_query_arm_is_rejected(self):
        def mutate(x):x[-1]=dict(x[0],pair_id='OTHER')
        self.change('experiment_K/judgment_map_holdout.jsonl',mutate)
        self.rejects()

    def test_duplicate_pair_is_rejected(self):
        self.change('experiment_K/judgment_map_holdout.jsonl',lambda x:x[-1].update(pair_id=x[0]['pair_id']))
        self.rejects()

    def test_wrong_split_is_rejected(self):
        self.change('experiment_K/judgment_map_holdout.jsonl',lambda x:x[-1].update(query_id='Q01'))
        self.rejects()

    def test_invalid_arm_is_rejected(self):
        self.change('experiment_K/judgment_map_holdout.jsonl',lambda x:x[-1].update(arm='K2'))
        self.rejects()

    def test_incomplete_story_triplet_is_rejected(self):
        data=read(self.root/'evaluation/group_split.json');data['Q24']['group_id']='G01'
        save(self.root/'evaluation/group_split.json',data,False)
        self.rejects()

    def test_duplicate_accepted_is_rejected(self):
        self.change('api/K_holdout_judgment/accepted.jsonl',lambda x:x.append(copy.deepcopy(x[0])))
        self.rejects()

    def test_accepted_unknown_pair_is_rejected(self):
        self.change('api/K_holdout_judgment/accepted.jsonl',lambda x:x[-1].update(pair_id='OTHER'))
        self.rejects()

    def test_accepted_parsed_identity_is_rejected(self):
        self.change('api/K_holdout_judgment/accepted.jsonl',lambda x:x[-1]['parsed'].update(pair_id='OTHER'))
        self.rejects()

    def test_missing_blind_mapping_is_rejected(self):
        self.change('evaluation/semantic_review_mapping_holdout.jsonl',lambda x:x.pop())
        self.change('reviews/holdout_review.jsonl',lambda x:x.pop())
        self.rejects()

    def test_duplicate_blind_pair_is_rejected(self):
        self.change('evaluation/semantic_review_mapping_holdout.jsonl',lambda x:x.append(copy.deepcopy(x[0])))
        self.rejects()

    def test_duplicate_blind_decision_is_rejected(self):
        self.change('evaluation/semantic_review_mapping_holdout.jsonl',lambda x:x[-1].update(decision_id=x[0]['decision_id']))
        self.change('reviews/holdout_review.jsonl',lambda x:x.pop())
        self.rejects()

    def test_duplicate_review_is_rejected(self):
        self.change('reviews/holdout_review.jsonl',lambda x:x.append(copy.deepcopy(x[0])))
        self.rejects()

    def test_missing_review_is_rejected(self):
        self.change('reviews/holdout_review.jsonl',lambda x:x.pop())
        self.rejects()

    def test_extra_review_is_rejected(self):
        self.change('reviews/holdout_review.jsonl',lambda x:x.append(dict(x[0],decision_id='EXTRA')))
        self.rejects()

if __name__=='__main__':unittest.main()
