"""Independent read-only recomputation of final post-experiment small artifacts."""
from collections import Counter,defaultdict
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

WORK=Path(__file__).resolve().parents[1]
ROOT=WORK.parents[1]
OUT=ROOT/'outputs/FinRisk_知识组织增强_v1_20261018'
sys.path.insert(0,str(WORK/'code_review'))
from final_control_metrics_audit import independent_metrics

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def rows(p):return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def equal(a,b):
    if isinstance(a,float) or isinstance(b,float):return math.isclose(a,b,abs_tol=1e-12)
    return a==b

def sensitivity():
    reported=read(OUT/'reports/metadata_sensitivity.json')
    shared=rows(OUT/'experiment_R/qrels_development_shared.jsonl')
    effective={(q['query_id'],q['file_id']):q['grade'] for q in shared}
    mapping={r['pair_id']:r for r in rows(OUT/'experiment_K/relevance_map_development.jsonl')}
    initial=rows(OUT/'api/K_development_relevance/accepted.jsonl')
    assert len(initial)==239 and len({r['pair_id'] for r in initial})==239
    legacy={(mapping[r['pair_id']]['query_id'],mapping[r['pair_id']]['file_id']):r['parsed']['grade'] for r in initial}
    all_K={(m['query_id'],m['file_id']) for m in mapping.values()}
    extra={p:g for p,g in effective.items() if p not in all_K}
    assert len(all_K)==240 and len(extra)==5
    legacy.update(extra)
    assert len(legacy)==reported['original_shared_pairs']==244 and len(effective)==reported['first_valid_shared_pairs']==245
    changes=[dict(query_id=q,file_id=f,original_grade=g,effective_grade=effective[q,f]) for (q,f),g in legacy.items() if effective[q,f]!=g]
    assert sorted(changes,key=lambda r:(r['query_id'],r['file_id']))==sorted(reported['changes'],key=lambda r:(r['query_id'],r['file_id']))
    assert len(changes)==reported['changed_existing_grades']==reported['upward']==10 and reported['downward']==0
    ranks={a:{r['query_id']:[h['file_id'] for h in r['ranking']] for r in rows(OUT/p)} for a,p in [('R0','experiment_K/rankings_development.jsonl'),('R1','experiment_R_controlled/rankings_development.jsonl')]}
    assert set(ranks['R0'])==set(ranks['R1']) and len(ranks['R0'])==12
    excluded={q:sorted({f for a in ranks for f in ranks[a][q][:20] if (q,f) not in legacy}) for q in ranks['R0']}
    included=sorted(q for q in ranks['R0'] if not excluded[q])
    excluded={q:f for q,f in excluded.items() if f}
    assert included==reported['paired_complete_query_ids'] and len(included)==11
    assert excluded==reported['excluded_unjudged']=={'KO_K002':['F001918']}
    actual={(r['query_id'],r['arm'],r['reference'],r['K']):r for r in reported['per_query']}
    assert len(actual)==len(reported['per_query'])==176
    for name,ref in [('original',legacy),('first_valid',effective)]:
        byq=defaultdict(dict)
        for (q,f),g in ref.items():byq[q][f]=g
        for a in ranks:
            for k in [1,5,10,20]:
                part=[]
                for q in included:
                    m=independent_metrics(ranks[a][q],byq[q],k)
                    assert all(equal(v,actual[(q,a,name,k)][n]) for n,v in m.items())
                    part.append(m)
                summary=reported['summary'][name][a][str(k)]
                for n in ['P','MRR','Top1','known_pool_recall','NDCG_pool']:
                    vals=[p[n] for p in part if p[n] is not None]
                    assert equal(sum(vals)/len(vals) if vals else None,summary[n])
                assert summary['paired_queries']==11
    assert reported['unjudged_imputed_as_zero'] is False and 'not retrieval improvement' in reported['not_a_representation_gain']
    return dict(passed=True,original_K_pairs=239,first_valid_K_pairs=240,R_additional_pairs=5,paired_queries=11,excluded_unjudged=excluded,changed_existing_grades=10,upward=10,downward=0,per_query_rows=176,
                original_R0_NDCG20=reported['summary']['original']['R0']['20']['NDCG_pool'],original_R1_NDCG20=reported['summary']['original']['R1']['20']['NDCG_pool'],
                first_valid_R0_NDCG20=reported['summary']['first_valid']['R0']['20']['NDCG_pool'],first_valid_R1_NDCG20=reported['summary']['first_valid']['R1']['20']['NDCG_pool'])

def stage_coverage():
    reported=read(OUT/'reports/known_direct_stage_coverage.json')
    routes={a:{r['query_id']:r for r in rows(OUT/p)} for a,p in [('R0','experiment_K/routes.jsonl'),('R1','experiment_R_controlled/routes.jsonl')]}
    bind_rows=rows(OUT/'evaluation/stage_unit_file_bindings.jsonl')
    bindings={r['unit_id']:r['file_id'] for r in bind_rows}
    wanted={h['unit_id'] for data in routes.values() for r in data.values() for route in ['BM25','BGE','RRF'] for h in r[route]}
    assert len(bindings)==len(bind_rows) and set(bindings)==wanted
    assert all(u.split(':')[1]==f for u,f in bindings.items())
    direct=defaultdict(set)
    for r in rows(OUT/'experiment_R/qrels_development_shared.jsonl'):
        if r['grade']==3:direct[r['query_id']].add(r['file_id'])
    ranks={a:{r['query_id']:r['ranking'] for r in rows(OUT/p)} for a,p in [('R0','experiment_K/rankings_development.jsonl'),('R1','experiment_R_controlled/rankings_development.jsonl')]}
    actual={(r['query_id'],r['arm'],r['stage']):r for r in reported['per_query']}
    assert len(actual)==len(reported['per_query'])==120
    rebuilt=[]
    for a in ranks:
        for q,r in ranks[a].items():
            found={s:{bindings[h['unit_id']] for h in routes[a][q][s]} for s in ['BM25','BGE','RRF']}
            found['dual_union']=found['BM25']|found['BGE'];found['rerank_Top20']={h['file_id'] for h in r[:20]}
            for stage,files in found.items():
                gold=direct[q]
                m=dict(query_id=q,arm=a,stage=stage,known_direct=len(gold),found_known_direct=len(gold&files),known_pool_coverage=len(gold&files)/len(gold) if gold else None,missed_known_direct=sorted(gold-files),denominator='shared judged Top20 document union only',global_true_recall=False)
                assert m==actual[(q,a,stage)]
                rebuilt.append(m)
        for s in ['BM25','BGE','dual_union','RRF','rerank_Top20']:
            vals=[r['known_pool_coverage'] for r in rebuilt if r['arm']==a and r['stage']==s and r['known_pool_coverage'] is not None]
            assert equal(sum(vals)/len(vals),reported['summary'][a][s])
    assert 'not independent initial-retrieval recall or full-corpus recall' in reported['limitation']
    return dict(passed=True,stage_bindings=len(bindings),per_query_rows=120,valid_direct_queries=len({q for q in ranks['R0'] if direct[q]}),summary=reported['summary'],selection_biased_known_pool_only=True)

def cost_audit():
    reported=read(OUT/'reports/cost_audit.json')
    ledger=rows(OUT/'api/budget/ledger.jsonl')
    reserves={r['reservation_id']:r for r in ledger if r['event']=='reserve'}
    settled={r['reservation_id']:r for r in ledger if r['event']=='settle'}
    assert len(reserves)==len(settled)==3064 and len(ledger)==6128 and set(reserves)==set(settled)
    all_records=[r for p in (OUT/'api').glob('*/records.jsonl') for r in rows(p)]
    byrid={r['reservation_id']:r for r in all_records}
    assert len(byrid)==len(all_records)==3064 and set(byrid)==set(reserves)
    global_counts=Counter((r['kind'],r['pair_id'],r['base_payload_sha256']) for r in all_records)
    assert max(global_counts.values())<=3
    unknown=[]
    for rid,r in byrid.items():
        reservation,settle=reserves[rid],settled[rid]
        assert reservation['phase']==r['phase'] and reservation['pair_id']==r['pair_id']
        assert equal(r['reserved_usd'],reservation['amount'])
        if r['booked_peak_bound_usd'] is None:assert settle['unknown_cost'] is True
        else:assert equal(r['booked_peak_bound_usd'],settle['booked_usd'])
        if settle['unknown_cost']:
            assert equal(settle['booked_usd'],reservation['amount'])
            unknown.append(dict(phase=r['phase'],pair_id=r['pair_id'],status=r['status'],booked_usd=settle['booked_usd'],reservation_id=rid))
        else:
            u=r['response']['usage'];hit=u.get('prompt_cache_hit_tokens',u.get('prompt_tokens_details',{}).get('cached_tokens',0))
            independent=((u['prompt_tokens']-hit)*.3+hit*.006+u['completion_tokens']*1.2)/1e6
            assert equal(independent,settle['booked_usd'])
    total=sum(Decimal(str(s['booked_usd'])) for s in settled.values())
    assert math.isclose(float(total),reported['booked_peak_bound_usd'],abs_tol=1e-12) and total<Decimal('2')
    for phase,summary in reported['phases'].items():
        records=[r for r in all_records if r['phase']==phase]
        assert summary['recorded_attempts']==len(records)
        assert summary['statuses']==dict(Counter(r['status'] for r in records))
        assert summary['unique_paid_pairs']==len({r['pair_id'] for r in records})
        assert summary['maximum_attempts']==max(Counter(r['pair_id'] for r in records).values())
        assert equal(summary['booked_peak_bound_usd'],sum(settled[r['reservation_id']]['booked_usd'] for r in records))
        assert equal(summary['seconds_sum'],sum(r['seconds'] for r in records))
        assert equal(summary['median_attempt_seconds'],statistics.median(r['seconds'] for r in records))
        for key in ['prompt_tokens','completion_tokens','prompt_cache_hit_tokens','prompt_cache_miss_tokens']:
            assert summary['known_usage_tokens'][key]==sum((r.get('response') or {}).get('usage',{}).get(key,0) for r in records)
    assert len(unknown)==reported['unknown_cost_reservations']==2 and reported['unsettled_reservations']==0
    assert reported['actual_vendor_invoice_verified'] is False and reported['all_failed_and_unused_requests_retained'] is True
    assert equal(reported['remaining_bound_usd'],2-float(total))
    return dict(passed=True,reserved_recorded_settled=3064,unsettled=0,global_max_attempts=max(global_counts.values()),unknown_conservative_reservations=unknown,booked_peak_bound_usd=float(total),remaining_bound_usd=2-float(total),vendor_invoice_not_verified=True)

def main():
    protected=[OUT/'reports'/n for n in ['metadata_sensitivity.json','known_direct_stage_coverage.json','cost_audit.json']]+[OUT/'evaluation/stage_unit_file_bindings.jsonl']
    before={str(p):sha(p) for p in protected}
    result=dict(sensitivity=sensitivity(),stage_coverage=stage_coverage(),cost=cost_audit())
    assert all(sha(p)==h for p,h in before.items())
    result['read_only_protected_sha256']=before
    (WORK/'code_review/final_analysis_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='read_only_protected_sha256'},ensure_ascii=False))

if __name__=='__main__':main()
