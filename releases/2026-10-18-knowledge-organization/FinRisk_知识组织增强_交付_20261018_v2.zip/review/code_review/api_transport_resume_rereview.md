# 显式传输恢复政策定向复审

日期：2026-10-18。身份：独立助手复审，`review_origin=current_session_model`，`human_approved=false`。

结论：通过，无新增阻断。此修订允许在既有本轮授权内显式恢复传输不确定请求；不增加2美元总硬上限、3次总尝试、唯一任务或材料范围，不允许按评分重采样。T06下游输入/实验检查仍单独审查。

- `--resume-uncertain` 默认为false；未显式指定时，其他phase的unknown仍被拒绝。
- 显式标志要求读取 `transport_resume_policy.json` 并核对scope、3次上限、保留全部未知费用及原授权SHA；该验证发生在凭据读取前。
- 全scope历史次数继续累计；已发生1次unknown后显式恢复保留次数1，3次历史后仍拒绝第4次。
- unknown后已经有accepted时复用同pair/body缓存，不再请求；旧unknown记录及费用不删除。
- 实际账本中 reservation `f940187f8b7b49c68a9a15ca3ff9fffb` 的预留与结算均为 `$0.0028812`，`unknown_cost=true`；没有按0释放旧不确定费用。
- 新恢复调用继续走原共享总账预留、OS进程锁、固定输入校验和响应校验；未知费用与新尝试费用共同占用原2美元上限。

实际独立执行7项 `test_api_guard.py` 测试：全部通过，0.148秒，退出码0。另用纯函数核验默认拒绝、显式计数、第4次拒绝和unknown后的accepted缓存复用。未读取真实密钥，未执行网络或收费请求；账本检查为只读快照。

审查指纹：

- `api_jobs.py`：`2095729a7b8100e7881596244ba4b56701857270cbbd459e06f55b1e0c5ad70e`。
- 原授权：`fcd040db274cc5b4783d4bfdfdd0afe248ee7ceba0556a7a3b6898d00a10a4c3`。
- 恢复政策：`2b415604e638072dad5e6a8e402df722b11d5e48f3bb7e930116facaae7f48f3`。
