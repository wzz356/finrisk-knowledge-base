"""Offline independent small-file audit; never opens actual private references."""
import collections
import hashlib
import json
import math
from pathlib import Path
import sys

WORK = Path(__file__).resolve().parents[1]
ROOT = WORK.parents[1]
OUT = ROOT / 'outputs/FinRisk_知识组织增强_v1_20261018'
REVIEW = WORK / 'code_review'
sys.path.insert(0, str(WORK))
from api_jobs import rerank_job, validate_result
import evaluate_k

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def rows(p):
    return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]

def save(p, value, lines=False):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in value) if lines else json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def digest(body):
    return hashlib.sha256(json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def independent_metrics(ranking, grades, k):
    top = ranking[:k]
    assert len(top) == k and set(top) <= set(grades)
    direct = {f for f, grade in grades.items() if grade == 3}
    relevant = [i for i, f in enumerate(top, 1) if f in direct]
    dcg = sum((2 ** grades[f] - 1) / math.log2(i + 1) for i, f in enumerate(top, 1))
    ideal = sorted(grades.values(), reverse=True)[:k]
    idcg = sum((2 ** g - 1) / math.log2(i + 1) for i, g in enumerate(ideal, 1))
    return dict(P=len(relevant)/k, MRR=1/min(relevant) if relevant else 0, Top1=int(1 in relevant),
                known_pool_recall=len(relevant)/len(direct) if direct else None,
                NDCG_pool=dcg/idcg if idcg else None, global_true_recall=False,
                judged_pool_direct_documents=len(direct))

def close(a, b):
    if isinstance(a, float) or isinstance(b, float):
        return math.isclose(a, b, abs_tol=1e-12)
    return a == b

def audit_r():
    target = OUT / 'experiment_R_controlled'
    packets = rows(target/'rerank_inputs.jsonl')
    maps = rows(target/'candidate_map.jsonl')
    cached = rows(target/'cached_scores.jsonl')
    assert len(packets) == len(maps) == len(cached) == 1200
    assert len({p['pair_id'] for p in packets}) == 1200
    rules = (OUT/'experiment_R/rerank_rules.md').read_text(encoding='utf-8')
    records = [r for phase in ['K_development_rerank', 'R_development_rerank'] for r in rows(OUT/'api'/phase/'records.jsonl')]
    accepted = {r['reservation_id']: r for r in records if r['status'] == 'accepted'}
    by_pid = {r['pair_id']: r for r in cached}
    packet_by_pid = {r['pair_id']: r for r in packets}
    query_shas = {q['query_id']: q['text_sha256'] for q in rows(OUT/'evaluation/queries.jsonl')}
    source_counts = collections.Counter()
    used = set()
    for p in packets:
        c = by_pid[p['pair_id']]
        source = accepted[c['reservation_id']]
        job = rerank_job(p, rules)
        assert source['pair_id'] == c['pair_id'] and source['phase'] == c['source_phase']
        assert source['base_payload_sha256'] == c['body_sha256'] == digest(job['body'])
        value = validate_result(job, source['parsed'])
        response = source['response']
        assert response['choices'][0]['finish_reason'] == 'stop'
        raw_value = json.loads(response['choices'][0]['message']['content'])
        assert validate_result(job, raw_value) == value
        assert value['score'] == c['score'] and c['new_API_call'] is False
        used.add(source['reservation_id'])
        source_counts[source['phase']] += 1
    assert dict(source_counts) == {'K_development_rerank':1183, 'R_development_rerank':17}
    scores = {r['pair_id']: r['score'] for r in cached}
    grouped = collections.defaultdict(list)
    for m in maps:
        p = packet_by_pid[m['pair_id']]
        assert query_shas[m['query_id']] == p['query_text_sha256'] and m['unit_text_sha256'] == p['unit_text_sha256']
        grouped[m['query_id']].append(dict(m, score=scores[m['pair_id']]))
    ranks = rows(target/'rankings_development.jsonl')
    groups = read(OUT/'evaluation/group_split.json')
    dev = {q for q, g in groups.items() if g['split'] == 'development'}
    assert len(ranks) == 12 and {r['query_id'] for r in ranks} == dev
    for r in ranks:
        candidates = grouped[r['query_id']]
        assert len(candidates) == 100
        seen, rebuilt = set(), []
        for c in sorted(candidates, key=lambda c: (-c['score'], c['unit_id'])):
            if c['file_id'] in seen:
                continue
            seen.add(c['file_id'])
            rebuilt.append(dict(c, rank=len(rebuilt)+1))
        assert r['ranking'] == rebuilt and r['score_count'] == 100
        assert len(seen) == len(r['ranking']) and len(seen) >= 20
    base = rows(OUT/'experiment_K/rankings_development.jsonl')
    qrels = rows(OUT/'experiment_R/qrels_development_shared.jsonl')
    assert len(qrels) == len({(q['query_id'], q['file_id']) for q in qrels}) == 245
    existing = rows(OUT/'experiment_K/qrels_development_effective.jsonl')
    assert len(existing) == 240
    by_pair = {(q['query_id'], q['file_id']): q for q in qrels}
    assert all(by_pair[(q['query_id'], q['file_id'])] == q for q in existing)
    new_refs = [q for q in qrels if (q['query_id'], q['file_id']) not in {(e['query_id'], e['file_id']) for e in existing}]
    relevance_records = {r['pair_id']:r for r in rows(OUT/'api/R_development_relevance/accepted.jsonl')}
    relevance_jobs = {r['pair_id']:r for r in rows(OUT/'api_jobs/R_development_relevance.jsonl')}
    ref_map = {r['pair_id']:r for r in rows(OUT/'experiment_R/relevance_map_development.jsonl')}
    assert len(new_refs) == len(relevance_records) == len(ref_map) == 5
    for q in new_refs:
        a, m = relevance_records[q['pair_id']], ref_map[q['pair_id']]
        job = relevance_jobs[q['pair_id']]
        assert a['base_payload_sha256'] == digest(job['body'])
        assert validate_result(job,a['parsed']) == a['parsed']
        data = json.loads(job['body']['messages'][1]['content'])
        assert set(data) == {'pair_id','current_text','source_paragraphs'}
        assert data['source_paragraphs'] == [{k:p[k] for k in ['span_id','text']} for p in m['paragraphs']]
        assert a['parsed']['grade'] == q['grade'] and m['query_id'] == q['query_id'] and m['file_id'] == q['file_id']
        assert a['parsed']['evidence_span_ids'] == q['evidence_span_ids']
        spans={p['span_id']:p for p in m['paragraphs']}
        assert q['source_spans'] == [spans[s] for s in q['evidence_span_ids']]
    grades = collections.defaultdict(dict)
    for q in qrels:
        assert q['query_id'] in dev and type(q['grade']) is int and 0 <= q['grade'] <= 3
        grades[q['query_id']][q['file_id']] = q['grade']
    union = {(r['query_id'], h['file_id']) for rr in [base, ranks] for r in rr for h in r['ranking'][:20]}
    assert union <= set(by_pair)
    per = {(r['query_id'], r['arm'], r['K']):r for r in rows(target/'per_query_metrics.jsonl')}
    assert len(per) == 96
    metric_names = ['P','MRR','Top1','known_pool_recall','NDCG_pool']
    rebuilt_summary = {}
    for arm, arm_ranks in [('R0',base),('R1',ranks)]:
        assert len(arm_ranks) == 12 and {r['query_id'] for r in arm_ranks} == dev
        rebuilt_summary[arm] = {}
        for k in [1,5,10,20]:
            part = []
            for r in arm_ranks:
                fs = [h['file_id'] for h in r['ranking']]
                assert len(set(fs)) == len(fs)
                measured = independent_metrics(fs, grades[r['query_id']], k)
                assert all(close(measured[n], per[(r['query_id'],arm,k)][n]) for n in measured)
                part.append(measured)
            rebuilt_summary[arm][str(k)] = {n:sum(p[n] for p in part if p[n] is not None)/sum(p[n] is not None for p in part) if any(p[n] is not None for p in part) else None for n in metric_names}
            rebuilt_summary[arm][str(k)]['valid_queries'] = 12
    measured = read(target/'metrics.json')
    for arm, ks in rebuilt_summary.items():
        for k, vals in ks.items():
            assert all(close(v, measured['summary'][arm][k][n]) for n,v in vals.items())
    r0,r1 = rebuilt_summary['R0'],rebuilt_summary['R1']
    gate = r1['5']['P'] >= r0['5']['P']-1e-12 and r1['20']['NDCG_pool'] >= r0['20']['NDCG_pool']-1e-12 and (round((r1['1']['Top1']-r0['1']['Top1'])*12)>=1 or r1['20']['MRR']-r0['20']['MRR']>=.03-1e-12)
    assert gate is False and measured['numeric_gate_passed'] is False and measured['new_holdout_required'] is False
    old_r = [r for r in records if r['phase']=='R_development_rerank' and r['status']=='accepted']
    unused = [r for r in old_r if r['reservation_id'] not in used]
    assert len(old_r) == 18 and len(unused) == 1
    ledger = rows(OUT/'api/budget/ledger.jsonl')
    reserves = {r['reservation_id']:r for r in ledger if r['event']=='reserve'}
    settlements = {r['reservation_id']:r for r in ledger if r['event']=='settle'}
    for r in old_r:
        assert reserves[r['reservation_id']]['pair_id'] == r['pair_id']
        assert settlements[r['reservation_id']]['booked_usd'] == r['booked_peak_bound_usd'] > 0
    return dict(passed=True, exact_scores=1200, cache_sources=dict(source_counts), per_query_rows=96, shared_qrels=245,
                current_top20_union_pairs=len(union), old_R18_retained_in_ledger=True,
                unused_old_R_score=[dict(pair_id=r['pair_id'],reservation_id=r['reservation_id'],booked_usd=r['booked_peak_bound_usd']) for r in unused],
                numeric_gate=False, summary=rebuilt_summary)

def audit_k_static_fixture():
    f = REVIEW/'evaluate_k_independent_fixture'
    sem = f/'reviews'
    groups = {f'Q{i:02}':dict(group_id=f'G{(i-1)//3:02}',split='development' if (i-1)//3%2==0 else 'holdout') for i in range(1,25)}
    save(f/'evaluation/group_split.json',groups)
    refs=[dict(query_id=q,overall_state='risk',mechanism_ids=['M'],required_predicate_assessments=[]) for q in groups]
    save(f/'private_reference/expected.jsonl',refs,True)
    for split in ['development','holdout']:
        qs = [q for q,g in groups.items() if g['split']==split]
        maps=[dict(query_id=q,arm=arm,pair_id=f'{q}_{arm}',case_chars=100,knowledge_chars=100) for q in qs for arm in ['K0','K1']]
        accepted=[dict(pair_id=m['pair_id'],parsed=dict(state='risk',mechanism_ids=['M'],predicates={})) for m in maps]
        if split=='development':
            missing={f'{q}_K0' for q in qs[:3]} | {f'{q}_K1' for q in qs[:4]}
            accepted=[r for r in accepted if r['pair_id'] not in missing]
        blind=[dict(pair_id=m['pair_id'],decision_id='D_'+m['pair_id']) for m in maps]
        reviews=[dict(decision_id=b['decision_id'],boundary_error_flags=['boundary'] if b['pair_id'].endswith('K0') else [],case_citation_reviews=[dict(status='supported')],law_citation_reviews=[]) for b in blind]
        save(f/f'experiment_K/judgment_map_{split}.jsonl',maps,True)
        save(f/f'api/K_{split}_judgment/accepted.jsonl',accepted,True)
        save(f/f'evaluation/semantic_review_mapping_{split}.jsonl',blind,True)
        save(sem/f'{split}_review.jsonl',reviews,True)
        save(f/f'experiment_K/qrels_{split}_effective.jsonl',[dict(query_id=q,file_id=f'F{i:02}',grade=3) for q in qs for i in range(20)],True)
        save(f/f'experiment_K/rankings_{split}.jsonl',[dict(query_id=q,ranking=[dict(file_id=f'F{i:02}') for i in range(20)]) for q in qs],True)
    full = evaluate_k.calculate(f,sem)
    assert full['summary']['development']['K0']['queries']==full['summary']['development']['K1']['queries']==12
    assert full['summary']['development']['K0']['format_failures']==3 and full['summary']['development']['K1']['format_failures']==4
    assert full['summary']['development']['K0']['state_accuracy']==9/12 and full['summary']['development']['K1']['state_accuracy']==8/12
    assert full['holdout_trial_gate']['passed'] is True
    hold = [q for q,g in groups.items() if g['split']=='holdout']
    dropped = hold[-1]
    for relative, idfield, prefix in [
        ('experiment_K/judgment_map_holdout.jsonl','query_id',''),
        ('evaluation/semantic_review_mapping_holdout.jsonl','pair_id',''),
        ('reviews/holdout_review.jsonl','decision_id','D_')]:
        values = rows(f/relative)
        save(f/relative,[v for v in values if not v[idfield].startswith(prefix+dropped)],True)
    try:
        incomplete = evaluate_k.calculate(f,sem)
        incomplete_accepted=True
    except ValueError:
        incomplete_accepted=False
        incomplete={}
    actual_groups=read(OUT/'evaluation/group_split.json')
    actual={}
    for split in ['development','holdout']:
        maps=rows(OUT/'experiment_K'/f'judgment_map_{split}.jsonl')
        counts=collections.Counter((m['query_id'],m['arm']) for m in maps)
        expected={q for q,g in actual_groups.items() if g['split']==split}
        assert len(expected)==12 and len({actual_groups[q]['group_id'] for q in expected})==4
        assert set(collections.Counter(actual_groups[q]['group_id'] for q in expected).values())=={3}
        assert set(counts)=={(q,a) for q in expected for a in ['K0','K1']} and set(counts.values())=={1}
        actual[split]=dict(queries=len(expected),story_groups=4,mapped_decisions=len(maps))
    dev_accepted=rows(OUT/'api/K_development_judgment/accepted.jsonl')
    assert len(dev_accepted)==17
    return dict(actual_structure=actual,actual_development_accepted=17,actual_development_format_failures=7,
                synthetic_failure_denominator_pass=True,incomplete_holdout_rejected=not incomplete_accepted,
                incomplete_fixture_summary=incomplete.get('summary',{}).get('holdout'),
                incomplete_fixture_gate=incomplete.get('holdout_trial_gate'),
                no_actual_private_reference_opened=True)

if __name__=='__main__':
    result=dict(R=audit_r(),K=audit_k_static_fixture())
    save(REVIEW/'final_control_metrics_audit.json',result)
    print(json.dumps(result,ensure_ascii=False))
