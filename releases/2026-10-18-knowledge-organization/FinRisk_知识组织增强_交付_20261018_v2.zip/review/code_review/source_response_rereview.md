# 来源响应修复定向复审

日期：2026-10-18。身份：独立助手复审，`review_origin=current_session_model`，`human_approved=false`。

结论：通过，无阻断项。`quality_review.md` 中“读取结果丢失来源版本说明和实际效力截止日”的 Important 已关闭。本结论仅覆盖该修复与法规模块回归，不扩大为其他新模块或 T03 真实产物通过。

## 修复核对

`LegalRegistry.read_article()` 现在按本次返回的主条及依赖条文收集对应来源，新增 `sources` 字典，并对整个响应执行深拷贝。来源包含完整版本描述、axes、证据及原有使用限制，不用年份推定现行效力。

| 定向检查 | 实际结果 |
|---|---|
| L001-A0017 | `sources.L001.version=2015年修正文本`；`axes.current_validity.evidence_cutoff=2026-08-28`；`post_cutoff_amendment_coverage=not_exhaustively_established`，完整返回。 |
| L007-S01-I01 | `sources.L007.axes.current_validity.status=version_effective_clause_verified_current_status_pending`；`current_law_assertion_mode=pending_current_validity_do_not_assert_current`，未升级效力。 |
| L002-A0029 跨来源依赖 | 来源集合为 `ESIGN/L002`；ESIGN 的版本为 `2019年修正文本`，版本、效力轴和证据完整返回。 |
| 全 67 条来源集合 | 独立遍历全部读取响应，`sources` 恰好覆盖主条及实际返回依赖所需的来源，各记录与注册内容全等。 |
| 禁用依赖读取 | 全 67 条 `include_dependencies=False` 响应只包含主条来源，未混入未返回依赖的来源。 |
| 深拷贝 | 各返回来源及嵌套 axes 与内部注册对象不同；实际修改 ESIGN 的效力轴、证据位置并清空 L002 的证据列表后，内部来源及再次读取均不受影响。新增正式测试另核验主条、依赖正文和 coverage 不受调用方修改影响。 |

## 实际测试

独立执行：

```text
python -S -X utf8 -B -m unittest discover -s tests -p test_legal_registry.py -v
Ran 11 tests in 1.864s
OK
```

11 项法规测试全部通过，退出码 0。未运行其他开发中的测试。另读取实现者的 `source_response_red.txt`，确认新增用例在缺少 `sources` 时失败；其 `source_response_green.txt` 记录修复后通过。本复审以上述独立重跑及额外真实响应核验作为接受证据。

## 固定指纹与范围

- 法规 manifest SHA 保持 `371863431348bc80f8bb1cbc707ca5eb672c2ea6149b1379674f3bbcd16409ca`，复审加载使用该固定期望值。
- 复审代码 `legal_registry.py` SHA256：`7f5ceca4a04f2bd9c5a99aff5341682a36f5cbe2f7f60325adf9d85f16d72cc8`。
- 复审测试 `tests/test_legal_registry.py` SHA256：`18162e7205ef7a46144c0bd0bb10bcf3843726f4c646e493faf8115707b826ee`。
- 143/146 是既有保护资产与总冻结项的分类，上轮 146 项全部匹配，不存在指纹失配。
- 本次未修改生产代码或旧产物，未联网，未调用收费 API。法规全面现行有效及历史个案适用的原有限制继续保留。
