# 代码与真实数据质量审查

审查日期：2026-10-18。身份：独立助手审查，`review_origin=current_session_model`，`human_approved=false`。

结论：发现 1 项 Important 接口问题，修复并定向复审后才能将本轮 T01 读取契约判为通过。其余本次已核验项目未发现阻断项。主代理已采纳该问题；本次审查不修改生产代码。

## Important：读取结果丢失来源版本说明和实际效力截止日

- 位置：`WORK/legal_registry.py` 的 `LegalRegistry.read_article()`（审查版本 SHA256：`9688d9c85060ca25ea2d317c7cfb941771fc92deee0554beda939e8de360fd20`）。
- 复现：`read_article('L001-A0017')` 只返回 `article/dependencies/coverage`。对应来源 `L001` 的 `axes.current_validity.evidence_cutoff` 为 `2026-08-28`，并注明 `post_cutoff_amendment_coverage=not_exhaustively_established`；这些字段不在响应中。条文仅保留 `dated_directory_cutoff_must_be_displayed`，没有应显示的日期。
- 影响：只消费正式读取响应的调用方无法完整展示证据的时点限制；核心条文来源版本的人类可读描述也只存在于来源注册中。内部 `registry.sources` 有正确数据，因此不是法规正文或旧输入损坏。
- 最小修复：响应附带主条和已返回依赖的对应来源记录，或将其来源版本描述、现行状态轴、证据截止日和来源证据字段明确并入各条读取结果；保留 `production_active=false`、待核状态及原件缺失身份。不要让调用方自行按年份推定效力。
- 复审条件：用 L001 的具体截止日、L007 pending、ESIGN 版本及依赖来源做定向红绿测试；确认响应为深拷贝，随后重跑原法规测试。

## 已完成的独立验证

| 项目 | 实际结果 |
|---|---|
| 当前送审的既有 tests | `-S -X utf8 -B -m unittest discover -s tests -p test_*.py -v`：20 项，全部通过；完整输出在 `existing_tests.txt`。运行时仅有法规、冻结、导航、快照四组测试。主代理随后新增且预期为红的机制卡测试不属于本次送审范围。 |
| 冻结保护 | 143 个既有数据/发布文件加 3 个检索代码/方案输入，共 146 项，逐项重新计算 SHA 与 `input_freeze.json`、`protected_assets.json` 全等。 |
| 旧交付 | 旧根 manifest 的 129 个载荷 SHA/大小全等；另复验旧 protected_baseline 10 项、reader freeze 6 项、calibration freeze 5 项，合计覆盖 153 个不同冻结路径。 |
| 复制读取器 | `base_reader.py` 与旧封存 `code/kb_reader.py` 的 SHA 完全一致。 |
| 法规固定清单 | manifest SHA 为 `371863431348bc80f8bb1cbc707ca5eb672c2ea6149b1379674f3bbcd16409ca`；加载时使用该固定值，未采用现场计算值作为期望值。 |
| 法规条文 | 67 个唯一 ID 与旧 43+24 集合相同；逐条正文及 SHA 与旧输入一致；独立核验快照切片、字符区间、UTF-8 字节区间和补充条文去行号/空白变换。 |
| 来源 | 13 个来源、27 个来源证据文件 SHA 全部匹配；包含 ESIGN；L011/L012 仍隔离且无可读条文；L007 的现行状态仍 pending；各来源均未提升生产准入或声称取得原始 bytes。 |
| 依赖 | 76 条边与旧 `required_context_articles` 的有向边集合全等，全部为 `assistant_required_context`；对 67 条逐条调用读取接口，再用独立遍历计算闭包，全部集合一致且 complete，最大闭包 14 节点。 |
| 拒绝路径 | 既有测试覆盖 bool/负数/越界/反序坐标、重复 ID、错正文 SHA、错版本、隔离来源、清单指纹失配、载荷篡改、漏载荷、循环、缺依赖及 32 节点上限。另直接核验 6 种 Windows/便携路径逃逸、空/未知/隔离条文 ID 均拒绝。 |
| 收费权限 | 本轮配置 authorization_file 仍为 null；另构造同模型、同金额但旧 scope 的授权样本，`api_authorized()` 返回 false。审查无收费调用。 |
| 导航函数 | 正反向同源、共用法规、多角色链接、悬空法规/案例拒绝及未建相邻机制 pending 的 4 项测试通过；不宣称 T03 真实产物验收完成。 |
| 真实全库快照 | 从旧 544 单元验收子集外选中 `structured:F000000:V2:3f3d3a79bd976b1caa632c79c76635fd28f864a60ff7f8989f5352ed055f238d`；实际扫描 110878 单元、9639 候选、9639 全文，构建新 1 单元/1 文书快照并以固定锁实例化读取器，成功回读登记原句。快照仅写入本审查目录。 |

## 证据与边界

- `independent_audit.py` / `independent_audit.json`：独立数据审计及审查时生产代码 SHA。
- `article_read_audit.json`：67 条逐条正文 SHA、坐标模式和闭包 ID。
- `rejection_audit.json`：额外路径/ID/旧授权拒绝结果及 143/146 项分类。
- `snapshot_audit/case_reader/`：实际全库选取后构建的审查快照、锁及扫描回执；不属于生产 OUT。
- 未再次运行旧 baseline_check 测试或扫描其目录；本次直接复核旧 SHA 和现有正式回放回执，不重复联网取证。
- 以上结果证明载荷、文字和既有证据身份的一致性，不证明所有法规全面现行有效、历史个案适用、当前业务事实成立或全库相关性完整。
- 新机制卡、证据包、门面和真实导航产物尚未纳入本轮审查，须后续单独送审。
