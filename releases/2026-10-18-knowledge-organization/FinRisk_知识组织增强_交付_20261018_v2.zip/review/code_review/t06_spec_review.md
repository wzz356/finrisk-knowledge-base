# T06 实验规格静态审查

日期：2026-10-18。身份：独立助手审查，`review_origin=current_session_model`，`human_approved=false`。

范围仅为 retrieve_k.py、retrieve_r.py、eval_protocol.py、experiment_k.py 及已冻结的公开实验合同/输入。只读 query_freeze 的路径与SHA，不读取 private expected 或其他参考答案内容；不运行收费网络或重新执行全库召回。

规格可审查，无需扩展目标。K 的干预是知识组织：每题两臂共用同一案例排名及文本，两臂使用同一67条可用法规语料，各守4000案例字符与4000法规/指引字符；不因此宣称检索增益。

- 24题按8个故事组三联体分割，development与holdout各12题；故事组不能跨split。保留题仅在候选配置冻结后开启，已用状态须留档，不用于调参。
- 每次 judgment prepare 必须正好是指定split的12个唯一query，各K0/K1一份。案例来自全9639文书召回的实际单元，先按文件选最佳重排单元，Top20文件去重；额外加载卡片案例不能改变实际模型案例文本。
- 已冻结查询、检索输入、pair/body/文本SHA及接受结果之间的绑定必须在下游装配前成立；不能仅凭 completion.complete=true 信任任意缓存或排名文件。
- judgment prepare 不解析私有expected；relevance 请求只含当前话术和可核原文，不带rank、arm、参考标签、目标文件或逐题答案。
- 未标相关性不能补0；Recall仅称 known_pool_recall，NDCG以已判断候选池为分母。缺题/缺结果不能静默缩样本。
- R的源码审查限全库召回、上下文替换与冻结边界；其新增表示内容和实际实验数据须后续单独验收。

静态初审已发现下游split/输入绑定和holdout状态检查不足，具体结果写入本批质量报告。其余方向符合合同，继续做不触及私有参考的定向验证。
