# 第二批两项 Important 定向复审

日期：2026-10-18。身份：独立助手复审，`review_origin=current_session_model`，`human_approved=false`。

结论：两项 Important 均已关闭，本次定向复审通过，无剩余阻断。结合 `batch2_quality_review.md` 中已通过的真实数据及接口检查，本批 T02/T03/T04 送审范围通过；T03 分类覆盖台账合同已满足。此结论不包括最终根清单封存、后续评测或 Agent 在线接入。

## 1. 跨版本拼装拒绝：通过

- `KnowledgeFacade` 在载入案例包前，明确校验增强 schema、增强版本及增强 `base_versions == case_lock.versions`。
- 复用上一轮独立构造的 `batch2_cross_version_fixture/case_reader/alternative`，先单独实例化 `KnowledgeReader`，确认该案例包仍是自有固定指纹、能正常加载的有效单元快照，内容版本为 `review-different-content-version`。
- 再用原增强固定指纹实例化门面，现在收到明确 `ValueError: enhancement and case base version mismatch`。修复针对的是两个各自有效、彼此不兼容输入的组合，未依靠损坏案例载荷触发拒绝。
- 另在审查目录临时构造固定指纹匹配但 schema 或 enhancement_version 不支持的清单，均被 `unsupported enhancement version` 拒绝；实际合法的591单元 pilot 仍成功加载。

## 2. T03 分类覆盖台账：通过

审查 `coverage_report.py` 及实际 `OUT/reports/navigation_coverage.json`，并独立与标签字典、四卡和已冻结选材记录逐项比对：

- 27个官方标签恰好一条记录，未增、未漏、无重复；其中5项为 partial，22项为 uncovered_in_this_enhancement，均 `automatic_assignment=false`。每项机制映射与四卡候选标签精确一致，未把候选映射写成标签全面覆盖。
- 4个机制的 material_scope、9个必要 predicate、法规列表和待核/不可推断项与实际卡片一致；M11 的10/16、M01的5/8及解释层限制保留。可选的伪造记录条件未列入必要条件。
- 资料范围实算为48文书、45显见事件簇、62原句、78候选单元，与报告全等；9639文书/65475结构化单元只作为全库规模，`full_corpus_review_completed=false`。
- 读取依赖、规范适用未知和预算政策分别表述；明确并非每个预算都提供67条法规，当前输入未评估，整块省略必须 partial。
- M05 的待建状态仍由原 `navigation/coverage.json` 和导航索引保留；新报告补足分类台账，不改动已固定的18个 pilot 载荷。

本报告按已确定的封存安排纳入最终根清单；该最终清单本身尚不在本次定向复审范围。

## 实际回归与指纹

独立运行 `python -S -X utf8 -B -m unittest discover -s tests -p test_evidence_facade.py -v`：7项全部通过，5.920秒，退出码0。

- 增强 manifest SHA保持：`db408b8b99bde56dab6c1ead90432ba9b2cab2564aa20051537b78fcfd2fa940`。
- `knowledge_facade.py` SHA256：`6f3b7ec2642fc2e0ce85e0e76107fa21c9b3290f6ee295b9944656e393df38ee`。
- `coverage_report.py` SHA256：`36fcfa82b76e381b492c069f33bbd666317167450b108a621357749975427c10`。
- 实际覆盖报告 SHA256：`27b3a12eb0971ae6f156aa5cb6464c185d3b43a38181f2331359d6e3b635632b`。

本次未重扫全部旧输入，未修改生产代码或旧产物，未联网或调用收费 API。法规全面现行有效、历史个案适用和当前业务事实的原有限制继续保留。
