# 格式修订、元数据重放与 R 开发输入复审

日期：2026-10-18。身份：独立助手复审，`review_origin=current_session_model`，`human_approved=false`。

结论：格式修订与元数据重放通过；R 的请求授权、exact cache 和表示/向量绑定通过，但补充发现查询向量控制变量差异。R 科学对照的最终接受须补候选集合敏感性核验，不能直接宣称只有20个文书表示改变。此前R新18评分的先行结论据此增加该条件；费用护栏无新增问题，若已调用仍保留全部记录，不能按分数重跑。

## 一 开发输出截断与保留前格式修订

- 实际development判断24份中17份accepted、7份缺失；按臂为K0 9成功/3失败，K1 8成功/4失败。7份缺失都能在原响应看到finish_reason=length，原任务/结果保留，不补做开发API调用。
- `development_format_amendment.json` 在holdout尚未open时记录：holdout两臂统一用predicate状态/短quote二元数组、短reason/limitations及每类最多2项引用；max_tokens仍为1024，转回原status/quote对象。
- canonical转换后仍要求完整predicate ID集合、三态值、当前输入原句、风险必要条件及登记引用，不更改风险语义。
- P0仍按24开发+24保留的48逻辑判断计划，不以格式修订额外增加开发任务。最终开发统计必须保留7次失败，不能只用17个成功样本比较两臂；开发与保留格式不同须披露。

## 二 human_approved 元数据重放

- 当前程序仅在字段缺失时标注 `human_approved=false`，附 `human_approval_field_origin=program_annotation_no_human_review_performed`；已有true或无效值仍拒绝。这是审核身份注释，不是修改语义等级，也不构成人工/专家审核。
- 独立检查所有原记录与当前job的pair/bodySHA一致；按attempt/UTC遍历，要求模型身份、单个完整stop响应、同一语义schema和有效登记span，重新得到240/240，与effective输出逐条全等。
- 其中87份最早合格响应只缺human flag；原239个later accepted及原records保留。选择规则统一最早合格，不按分数选优，也未读取排名或private expected。
- **敏感性必须保留：10个等级变更全为上调，10升0降。** 即使重放选择规则正确，这种数据版本变化也不能算成知识组织或检索增益。最终指标应说明使用的qrels版本，保留原239版的敏感性及1个未标缺口；不能把该未标补0凑完整对照。
- `format_metadata_replay_audit.json` 保存10个具体pair及旧/新等级、87项元数据恢复和开发失败分臂计数。

## 三 R 开发输入与新增向量

已通过的检查：

- 实际1200个development rerank job中，按 `(pair_id, canonical body SHA)` 重算精确复用1182个、18个新逻辑评分；全部话术来自冻结development，body/packet与文本SHA一致，没有参考字段。
- 20个表示与 `context_cache_binding.json` 的有序记录逐项一致；6个绑定文件SHA闭合，新增矩阵为20×512 float32，所有元素有限且L2归一化；文书token审计20条顺序一致、均无截断且≤512 tokens。
- 用unit稳定ID中的外部原文SHA作pin，逐个重新调用make_prefix，20份结果与实际prefix全等。背景原句、来源、保留原文本及归责限制均不变。
- 原R retrieval_freeze未覆盖改写，新增context binding补充其向量/表示/审计闭环。R保留仍不能复用旧K保留题。

补充发现的控制变量问题：

- 独立逐行对比K缓存中12条development查询向量与R的12条query_vectors，全部不满足字节相同；最大单坐标绝对差为0.000125—0.000283。源码中R重新encode查询，而不是直接复用K查询向量。
- 因此BGE差异不能未经诊断就全部归于20个文书表示。差异虽小，可能影响近邻边界与候选集合；不能仅凭数值小判为无影响。
- 最小接受路径：复用K查询向量、保留现有20个context向量，只做本地dense/RRF敏感性重算；保留原R冻结和结果，另记修正。若每题RRF Top100 unit集合及相应job body不变，已有评分可继续exact复用；若改变，另建修正输入并复审，避免重复付费。中间名次/分数差异仍应留档。

## 实际测试与指纹

- 9项API guard测试、2项prefix测试独立全部通过，无网络。
- R job SHA：`2fc9b6ce287fc0df9eae0a27ddae41120b0df5c5e9ed78697f2c87d03b676c08`。
- 新context binding SHA：`220382b6cc83bc3e963c889d9e49d6891e9d8f150c0b8bca1cd3c7129dd29028`。
- 原R retrieval_freeze SHA：`1a1bca61a693820ec06adf030ea3c590ce9df5c4434edac5fb8b330da2bf4f56`。
- effective qrels SHA：`ef12b8dbd1d022fcbae765c34141e1dc35562ad5c8ef5df26aa85d6c761cfeab`。
- 元数据政策 SHA：`30926317abd61682d853e144780a5e95150daf072790d919c9d68ba226a6ae11`。
- 格式修订 SHA：`dcbb2c9e4c164dc0b20f2fed0e76cd5ed02a10b7d7f810d4b936fe139c39a5b8`。

本次未读private expected、未读密钥、未调用网络/收费API、未重跑模型编码或全库召回。最终采用结论和保留结果不在本次审查中。
