# K 最终完整性修复与结果核验

2026-10-18。本轮唯一生产改动为 `WORK/evaluate_k.py`；夹具、原脚本副本和审计证据均保留于 `code_review/`。没有调用 API、修改候选冻结代码或既有结果。经根代理明确授权，仅为审核离线读取实际 expected；未输出答案内容、未改参考。

**通过，前轮 Important 关闭；K 实验结论仍为未通过保留门槛。**

修复增加冻结集合和故事组三元组检查，严格要求每 split 12 查询×两臂共24条、pair及query-arm唯一、无跨split复用pair；accepted仅可来自本split且identity一致；blindmap严格覆盖accepted，decision及review唯一并完全对应。失败判断不伪造盲审，仍留在原24条map的分母中。

`code_review/test_evaluate_k_integrity.py` 修复前16项中13项出现预期失败，修复后16项全通过；现有 `test_eval_protocol.py` 2项、`test_experiment_contracts.py` 1项通过。实际 `calculate()` 返回值与既有 metrics、per_query_results、retrieval_per_query 三份产物逐值相等，三份输出及 actual expected 的前后SHA完全不变。没有运行会写结果的 main。

| 核验项 | 开发 | 保留 |
|---|---:|---:|
| 查询/故事组/判断map | 12/4/24 | 12/4/24 |
| accepted / 格式失败 | 17/7 | 24/0 |
| 独立盲审记录 | 17 | 24 |
| 案例/法规引用 | 126/30 | 46/33 |

开发两臂正确数分别9/12和8/12，含3+4次格式失败。保留两臂正确数12/12→11/12，边界错误8→9，引用支持率22/39→20/40；三项均不满足非下降/减少条件，`holdout_trial_gate.passed=false` 与实际结果一致。正常/信息不足题无新增错误，不能弥补其他门槛失败。

41份盲审逐pair/decision对应accepted，审查引用ID与模型实际引用完全等集且无重复；总172案例+63法规=235引用，supported107、partial118、unsupported10。此处核验盲审覆盖和计数，不把模型银标语义审查升级为专家金标。

修复后 `evaluate_k.py` SHA256：`7350acf71b36d466bc002a7628715da9aae55af8a0dfc5a3de9c79f8bb00aeb5`。

详细可重跑证据：`code_review/K_final_integrity_audit.py`、`code_review/K_final_integrity_audit.json`、`code_review/K_integrity_before_sha.json`。前轮 R 独立复算报告保留不变。
