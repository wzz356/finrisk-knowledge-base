"""Score all frozen queries, including format failures, against model-silver references."""
import argparse
from collections import Counter
from common import *
from eval_protocol import ranking_metrics

def avg(values):
    valid=[v for v in values if v is not None]
    return sum(valid)/len(valid) if valid else None

def calculate(root,semantic_root):
    root=Path(root);semantic_root=Path(semantic_root)
    refs={r['query_id']:r for r in rows(root/'private_reference/expected.jsonl')}
    groups=read(root/'evaluation/group_split.json');per=[];retrieval=[];summary={}
    for split in ['development','holdout']:
        maps=list(rows(root/'experiment_K'/f'judgment_map_{split}.jsonl'))
        accepted={r['pair_id']:r['parsed'] for r in rows(root/'api'/f'K_{split}_judgment/accepted.jsonl')}
        blindmap={r['pair_id']:r['decision_id'] for r in rows(root/'evaluation'/f'semantic_review_mapping_{split}.jsonl')}
        reviews={r['decision_id']:r for r in rows(semantic_root/f'{split}_review.jsonl')}
        if set(reviews)!=set(blindmap.values()):raise ValueError('missing or extra independent semantic reviews')
        for m in maps:
            ref=refs[m['query_id']];pred=accepted.get(m['pair_id']);review=reviews.get(blindmap.get(m['pair_id']))
            expected_preds={p['predicate_id']:p for mechanism in ref['required_predicate_assessments'] for p in mechanism['predicates']}
            wrong_positive=[];predicate_total=predicate_correct=0
            if pred:
                for pid,item in pred['predicates'].items():
                    expected=expected_preds[pid];predicate_total+=1;predicate_correct+=item['status']==expected['status']
                    if expected['required_for_risk'] and item['status']=='met' and expected['status']!='met':wrong_positive.append(dict(predicate_id=pid,expected=expected['status']))
            case_reviews=review['case_citation_reviews'] if review else []
            law_reviews=review['law_citation_reviews'] if review else []
            per.append(dict(split=split,query_id=m['query_id'],story_group=groups[m['query_id']]['group_id'],arm=m['arm'],
                expected_state=ref['overall_state'],predicted_state=pred['state'] if pred else 'format_failure',
                accepted=pred is not None,state_correct=bool(pred and pred['state']==ref['overall_state']),
                mechanism_set_exact=bool(pred and set(pred['mechanism_ids'])==set(ref['mechanism_ids'])),
                expected_mechanisms=ref['mechanism_ids'],predicted_mechanisms=pred['mechanism_ids'] if pred else None,
                wrong_positive_required_predicates=wrong_positive,predicate_correct=predicate_correct,predicate_total=predicate_total,
                semantic_boundary_flags=review['boundary_error_flags'] if review else [],
                case_citation_statuses=[r['status'] for r in case_reviews],law_citation_statuses=[r['status'] for r in law_reviews],
                literal_citation_registration_passed=pred is not None,case_chars=m['case_chars'],knowledge_chars=m['knowledge_chars'],
                facts_and_semantics_reviewed=review is not None,human_approved=False))
        qrels=list(rows(root/'experiment_K'/f'qrels_{split}_effective.jsonl'));grades={}
        for q in qrels:grades.setdefault(q['query_id'],{})[q['file_id']]=q['grade']
        for r in rows(root/'experiment_K'/f'rankings_{split}.jsonl'):
            for k in [1,5,10,20]:retrieval.append(dict(split=split,query_id=r['query_id'],K=k,**ranking_metrics([h['file_id'] for h in r['ranking']],grades[r['query_id']],k)))
        summary[split]={}
        for arm in ['K0','K1']:
            part=[r for r in per if r['split']==split and r['arm']==arm];confusion={}
            for r in part:confusion.setdefault(r['expected_state'],Counter())[r['predicted_state']]+=1
            cases=[s for r in part for s in r['case_citation_statuses']];laws=[s for r in part for s in r['law_citation_statuses']]
            allc=cases+laws
            summary[split][arm]=dict(queries=len(part),accepted=sum(r['accepted'] for r in part),format_failures=sum(not r['accepted'] for r in part),
                state_correct=sum(r['state_correct'] for r in part),state_accuracy=avg([int(r['state_correct']) for r in part]),
                by_state={state:dict(total=sum(r['expected_state']==state for r in part),correct=sum(r['state_correct'] for r in part if r['expected_state']==state)) for state in ['risk','no_clear_risk','insufficient_info']},
                mechanism_set_exact=sum(r['mechanism_set_exact'] for r in part),confusion={k:dict(v) for k,v in confusion.items()},
                required_positive_error_decisions=sum(bool(r['wrong_positive_required_predicates']) for r in part),
                semantic_boundary_error_decisions=sum(bool(r['semantic_boundary_flags']) for r in part),
                case_citations=len(cases),law_citations=len(laws),supported_citations=allc.count('supported'),
                semantic_citation_support_rate=allc.count('supported')/len(allc) if allc else None,
                case_citation_counts=dict(Counter(cases)),law_citation_counts=dict(Counter(laws)),
                mean_case_chars=avg([r['case_chars'] for r in part]),mean_knowledge_chars=avg([r['knowledge_chars'] for r in part]))
    h0,h1=summary['holdout']['K0'],summary['holdout']['K1']
    no_new_nonrisk_errors=all(not (a['state_correct'] and not b['state_correct']) for a in per for b in per if a['split']==b['split']=='holdout' and a['arm']=='K0' and b['arm']=='K1' and a['query_id']==b['query_id'] and a['expected_state']!='risk')
    citations_ok=h0['semantic_citation_support_rate'] is not None and h1['semantic_citation_support_rate'] is not None and h1['semantic_citation_support_rate']+1e-12>=h0['semantic_citation_support_rate']
    fewer_boundary=h1['semantic_boundary_error_decisions']<h0['semantic_boundary_error_decisions']
    gate=h1['state_correct']>=h0['state_correct'] and fewer_boundary and no_new_nonrisk_errors and citations_ok and h1['format_failures']==0
    return dict(schema='finrisk-K-result-v1',summary=summary,holdout_trial_gate=dict(passed=gate,
        state_correct_nondecrease=h1['state_correct']>=h0['state_correct'],boundary_error_reduced=fewer_boundary,
        no_new_nonrisk_errors=no_new_nonrisk_errors,citation_support_nondecrease=citations_ok),
        interpretation=dict(knowledge_organization_is_combined_intervention=True,retrieval_rankings_identical_between_K_arms=True,
            full_corpus_recall_measured=False,reference='independently reviewed model silver; synthetic inputs; 8 story groups',
            output_format_debugging='development 7 failures retained; compact holdout both arms same canonical schema and1024token cap',
            citation_semantics='separate blinded session review, not expert gold or guaranteed double blind'),
        per_query=per,retrieval=retrieval)

def main():
    result=calculate(OUT,WORK/'semantic_review')
    per=result.pop('per_query');retrieval=result.pop('retrieval')
    save(OUT/'experiment_K/per_query_results.jsonl',per,True);save(OUT/'experiment_K/retrieval_per_query.jsonl',retrieval,True)
    save(OUT/'experiment_K/metrics.json',result)
    print(json.dumps(dict(summary=result['summary'],gate=result['holdout_trial_gate']),ensure_ascii=False))

if __name__=='__main__':main()
