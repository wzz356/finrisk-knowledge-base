"""Independent review checks. Writes only beneath this review directory."""
import copy
import hashlib
import itertools
import json
import re
import sys
from collections import deque
from pathlib import Path

REVIEW = Path(__file__).resolve().parent
WORK = REVIEW.parent
sys.path.insert(0, str(WORK))
from common import BASE, CURRENT, OUT, P0OLD, V2, canonical_sha, read, rows, sha, textsha
from legal_registry import LegalRegistry
import case_snapshot
from base_reader import KnowledgeReader

PIN = '371863431348bc80f8bb1cbc707ca5eb672c2ea6149b1379674f3bbcd16409ca'


def must(condition, message):
    if not condition:
        raise AssertionError(message)


def normalized(value):
    return ''.join(re.sub(r'^L\d+:\s?', '', value, flags=re.MULTILINE).split())


def independent_closure(aid, adjacency):
    todo, done = deque([aid]), set()
    while todo:
        current = todo.popleft()
        if current in done:
            continue
        done.add(current)
        todo.extend(adjacency.get(current, []))
    return done


def main():
    result = {'review_origin': 'current_session_model', 'human_approved': False,
              'legal_manifest_sha256': sha(OUT / 'legal/manifest.json')}
    must(result['legal_manifest_sha256'] == PIN, 'pinned legal manifest changed')
    digests = {}
    for label, path in [('new_input_freeze', OUT / 'contracts/input_freeze.json'),
                        ('new_protected_assets', OUT / 'contracts/protected_assets.json'),
                        ('old_protected_baseline', P0OLD / 'protected_baseline.json'),
                        ('old_reader_freeze', P0OLD / 'reader/input_freeze.json'),
                        ('old_calibration_freeze', P0OLD / 'calibration/input_freeze.json')]:
        table = read(path)['sha256']
        for filename, expected in table.items():
            p = Path(filename).resolve()
            if p not in digests:
                digests[p] = sha(p)
            must(digests[p] == expected, label + ' changed: ' + str(p))
        result[label] = {'entries_verified': len(table), 'all_equal': True}
    old_manifest = read(P0OLD / 'manifest.json')
    for entry in old_manifest['files']:
        p = P0OLD / entry['path']
        must(sha(p) == entry['sha256'] and p.stat().st_size == entry['bytes'], 'old payload mismatch')
    result['old_release_manifest_payloads_verified'] = len(old_manifest['files'])
    result['unique_protected_paths_verified'] = len(digests)
    must(sha(WORK / 'base_reader.py') == sha(P0OLD / 'code/kb_reader.py'), 'legacy reader copy differs')
    result['base_reader_is_exact_legacy_copy'] = True
    must(read(WORK / 'config.json')['api']['authorization_file'] is None, 'API authorization changed')
    result['api_initial_authorization_is_null'] = True

    registry = LegalRegistry(OUT / 'legal', PIN)
    original = list(rows(P0OLD / 'reader/bundle/articles.jsonl')) + list(rows(P0OLD / 'law/supporting_articles.jsonl'))
    must(len(original) == 67 and len(registry.articles) == 67, 'article count mismatch')
    must({x['article_id'] for x in original} == set(registry.articles), 'article IDs differ')
    expected_edges = {(x['article_id'], dep) for x in rows(P0OLD / 'law/article_admission_overlay.jsonl')
                      for dep in x['required_context_articles']}
    actual_edges = {(e['from_article_id'], e['to_article_id']) for e in registry.edges}
    must(len(registry.edges) == 76 and actual_edges == expected_edges, 'dependency overlay differs')
    must(all(e['relationship_type'] == 'assistant_required_context' for e in registry.edges), 'edge identity differs')
    must(len(registry.sources) == 13 and 'ESIGN' in registry.sources, 'source inventory differs')
    evidence_count = 0
    for source in registry.sources.values():
        must(source['production_active'] is False and source['human_approved'] is False, 'source promoted')
        must(source['axes']['original_bytes']['acquired'] is False, 'source original bytes claim changed')
        for evidence in source['evidence']:
            must(sha(OUT / 'legal' / evidence['local_file']) == evidence['local_sha256'], 'source evidence hash differs')
            evidence_count += 1
    for sid in ['L011', 'L012']:
        must(registry.sources[sid]['research_reference_allowed'] is False, 'quarantined source admitted')
        must(all(a['source_id'] != sid for a in registry.articles.values()), 'quarantined source has article')
    must('pending' in registry.sources['L007']['axes']['current_validity']['status'], 'L007 promoted')
    audits = []
    for prior in original:
        aid = prior['article_id']
        article = registry.articles[aid]
        must(prior['text'] == article['text'] and prior['text_sha256'] == article['text_sha256'], aid + ' text changed')
        source = registry.sources[article['source_id']]
        must(article['version_id'] == source['version_id'], aid + ' version mismatch')
        provenance = article['provenance']
        snapshot = (OUT / 'legal' / provenance['snapshot_file']).read_bytes().decode('utf-8')
        span = provenance['span']
        start, end = span['start_char'], span['end_char']
        must(type(start) is int and type(end) is int and 0 <= start < end <= len(snapshot), aid + ' invalid character range')
        must(span['start_byte_utf8'] == len(snapshot[:start].encode()) and
             span['end_byte_utf8'] == len(snapshot[:end].encode()), aid + ' invalid UTF8 range')
        sliced = snapshot[start:end]
        must(textsha(sliced) == span['span_sha256'], aid + ' span hash mismatch')
        if 'source_reader_span' in prior:
            must(provenance['coordinate_system'] == 'reader_snapshot_char_and_utf8', aid + ' wrong coordinate mode')
            must(prior['source_reader_span'] == span, aid + ' old reader coordinates changed')
            must(normalized(sliced) == normalized(article['text']), aid + ' transformed slice differs')
            must(prior['source_version'] == source['version'], aid + ' verified version differs')
        else:
            must(provenance['coordinate_system'] == 'legacy_literal_char', aid + ' wrong legacy coordinate mode')
            must(sliced == article['text'], aid + ' literal slice differs')
        response = registry.read_article(aid)
        actual = {aid} | {x['article_id'] for x in response['dependencies']}
        expected = independent_closure(aid, registry.adjacency)
        must(actual == expected and response['coverage']['status'] == 'complete', aid + ' closure differs')
        must(response['coverage']['current_business_fact_proof'] is False and
             response['coverage']['historical_case_applicability_confirmed'] is False, aid + ' proof boundary differs')
        audits.append({'article_id': aid, 'text_sha256': article['text_sha256'], 'snapshot_file': provenance['snapshot_file'],
                       'coordinate_system': provenance['coordinate_system'], 'closure_size': len(actual),
                       'closure_article_ids': sorted(actual), 'status': 'passed'})
    result['legal'] = {'articles': 67, 'sources': 13, 'dependencies': 76, 'source_evidence_hashes_verified': evidence_count,
                       'all_independent_closures_equal': True, 'max_closure_size': max(x['closure_size'] for x in audits),
                       'cutoff_l001_in_read_response': '2026-08-28' in json.dumps(registry.read_article('L001-A0017'))}
    (REVIEW / 'article_read_audit.json').write_text(json.dumps(audits, ensure_ascii=False, indent=2), encoding='utf-8')

    legacy = {u['unit_id'] for u in rows(P0OLD / 'reader/bundle/units.jsonl')}
    chosen = next(u['unit_id'] for u in rows(V2 / 'indexes/all9639_final/structured.jsonl') if u['unit_id'] not in legacy)
    # Redirect only this process's output root into the review directory.
    case_snapshot.OUT = REVIEW / 'snapshot_audit'
    target = case_snapshot.OUT / 'case_reader/full_corpus_single_unit'
    lock = case_snapshot.build_snapshot([chosen], target)
    consumer = KnowledgeReader(target, expected_versions=lock['versions'], expected_manifest_sha256=lock['manifest_sha256'])
    evidence = consumer.read(chosen, layer='hit')
    must(chosen not in legacy and len(consumer.units) == 1, 'new snapshot silently reused legacy subset')
    must(evidence['segments'] and all(s['text'] for s in evidence['segments']), 'snapshot lost literal source text')
    receipt = read(target.with_name(target.name + '_receipt.json'))
    result['real_case_snapshot'] = {'requested_unit_id': chosen, 'outside_old_544_unit_subset': True,
                                    'file_id': evidence['file_id'], 'source_sha256': evidence['source_sha256'],
                                    'read_segments': len(evidence['segments']), 'receipt': receipt}
    result['production_code_hashes_at_review'] = {name: sha(WORK / name) for name in
        ['freeze_inputs.py', 'legal_registry.py', 'legal_task/build.py', 'navigation.py', 'case_snapshot.py', 'base_reader.py']}
    result['paid_external_API_calls'] = 0
    (REVIEW / 'independent_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
