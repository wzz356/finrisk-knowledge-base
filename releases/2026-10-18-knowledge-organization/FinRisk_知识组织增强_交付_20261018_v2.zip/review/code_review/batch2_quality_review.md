# 第二批质量审查：T02/T03/T04

日期：2026-10-18。身份：独立助手审查，`review_origin=current_session_model`，`human_approved=false`。

结论：当前批次有 2 项 Important 待修复，不能判为整批通过。案例文字、归责限制、source-only 阅读、固定案例预算和实际快照核验通过；初始的 M02 条款作用混同、新知识载荷未固定指纹、缺 coverage 接口问题已在本次审查中修正并定向核验。

## Important 1：增强基础版本未与案例包版本绑定

- 位置：`knowledge_facade.py` 初始化（本轮版本 SHA256：`3a6dc354e3d8ade0508e73c5b77ef42a598cb05f3888ef89cf08a9e6de994999`，第25—31行）。代码验证增强清单载荷和案例包各自的指纹，但没有比对增强清单的 `base_versions` 与 `case_lock.versions`。
- 已实证：审查目录 `batch2_cross_version_fixture/` 中保留原增强载荷、原固定增强 manifest，同时构造一个有真实来源、有效单元和新固定案例指纹的合法案例快照。该案例快照 `content` 版本为 `review-different-content-version`，与增强 manifest 的已冻结基础 content 版本不同，门面仍成功实例化。
- 这不是让旧损坏载荷绕过自己的 SHA，而是两个各自有效、彼此不兼容的输入被成功拼装；正是方案要求拒绝的跨版本情况。
- 复现程序及结果：`batch2_audit.py`，`batch2_audit.json.cross_version_fixture.rejected=false`。
- 最小修复：初始化读取增强 manifest 后，先严格要求其完整 `base_versions` 等于所传案例锁版本，并保留现有两个清单的固定指纹校验；新增不兼容但各自有效的版本拒绝测试。

## Important 2：T03 覆盖台账缺少承诺的分类明细

- 位置：`navigation.py` 第57—59行生成的 `navigation/coverage.json`。
- 当前只有4个机制ID、待建 M05、153个链接目标及 `all_official_27_labels_fully_covered=false`。没有27个官方标签逐项覆盖/未覆盖说明，也没有按资料、条件和待核项分类的覆盖记录。
- 实际四卡候选标签只涉及5项：客户信息不真实、回访违规、合同外利益、赠送利益、回扣返佣；其余22项没有可机器读取的未覆盖记录。不能将“有候选链接”误称该标签已全面覆盖。
- 实施方案 T03 明确要求覆盖清单按“机制、资料、条件、官方标签、待核项”分别计数，未涉及标签显示未覆盖。单个总布尔值不足以满足该验收。
- 最小修复：从四卡、原句/链接和27标签字典生成分类台账，逐标签保留候选映射和未涉及状态；带入 M11/M01 的实际支持缺口、必要/可选条件数、资料范围及 M05 等待核/待建项，再重新固定导航载荷指纹。

## 本轮已修正且验证通过

- M02.impersonation 的规范支持现只含 L002-A0035；L005-A0016 移入 `context_article_ids`，四卡及 claim_evidence 保留背景身份。M01 的 predicates 均标 `assistant_interpretation_of_registered_articles`。
- 新知识和导航共18个实际载荷已完整列入增强 manifest；对照磁盘目录无遗漏。固定增强指纹为 `db408b8b99bde56dab6c1ead90432ba9b2cab2564aa20051537b78fcfd2fa940`；门面拒绝缺失指纹及知识载荷篡改。
- 增加 `coverage(mechanism_id)`，返回材料、依赖、规范适用未知与未装配预算状态；read_mechanism 默认 L0；证据包兼容单 mechanism_id、budget_chars=8000，并约束分项总预算不超过总预算。

## 实际数据与接口核验

| 项目 | 实际证据 |
|---|---|
| 选材和原句 | 48份文书、45个显见事件簇、62个登记span。全部全文 SHA 与固定选材记录匹配，原句是对应全文的精确半开区间，正文 SHA、来源 SHA 与案例快照一致。 |
| 案例链接 | 88条链接、78个真实 unit。全部 file_id/span/actor_role/attribution_limit 对应一致；绑定 unit 属于对应文书且真实跨度相交；每个 candidate_associations 字段都能在原 unit 的关联中核对，不新增归责。 |
| 归责和边界 | 文书原句及限制区分机构、直接实施者、责任人员；M11五份主体/文书阶段不明材料未升为支持，M01不实状态未记载材料保持 ambiguous，F008983管理责任未转为亲自指导；F009689“涉嫌”和处罚结论、F000579未采纳合同申辩均分段保留。 |
| source-only | 8条无 unit 链接均为 `unit_id=null`、空 candidate_associations、`source_span_only_no_matching_unit`；分别经对应机制 L2 回读，结果与登记原句全等。 |
| 实际快照 | 591个 unit、398份文书全部 hit 回读成功。unit集合恰为旧544单元与本轮78单元的并集；旧544条完整字典与旧包逐条全等。 |
| 四卡边界 | M11.personal_record_falsified 的 required_for_risk=false；M01明确解释身份及 L011 待核；M02第16条仅背景；M04缺合同仍 unknown。M11支持10/目标16、M01支持5/目标8保留partial；不把48文书当48独立事件。 |
| 导航边 | 用实际卡片、法规、591单元和62span重建导航，与实际 index 全等；153个正反向目标均来自同一表；L0/L1文件存在；M05显式pending；hard_filter=false。 |
| 预算与固定案例 | 独立运行8000字默认分配、120字小预算、1/7999分配三种场景；两段文本均不超限，法规正文整块保留；所有省略明确partial； included case严格为请求case子集，没有自动加入卡片案例。 |
| 当前事实 | bundle 的 current_input_facts_assessed=false，所有 facts_to_check 状态均为not_assessed；coverage的规范适用为not_assessed_for_current_input。 |

## 实际测试与限制

- 机制卡4项、导航4项通过；稳定后的门面6项通过（独立重跑，5.562秒，退出码0）。早先在主代理增补pin的预期红阶段跑到的1失败/5错误，已由稳定后的6项通过替代，不另记为未修回归。
- 单机制兼容调用及六个承诺接口均已实际检查；新增 get_dependencies 作为额外辅助，不替代 coverage。
- `batch2_audit.py` / `batch2_audit.json` 保留数据核验、预算场景、代码 SHA 及跨版本复现。
- 本轮未再次全扫描法规模块及旧保护指纹，沿用上一批及定向复审结论；未联网、未调用收费 API、未修改生产代码或 OUT。
- 文字及载荷一致性不等于法规全面现行有效、历史适用或当前事实成立。上述2项修复后还需独立复审，不宜仅用现有测试通过替代。
