# 控制版 R 最终复算与 K 评估静态审查

审查日期：2026-10-18。只读相关小文件、原 API 记录和费用账本；未读取实际 `private_reference`，未联网、未重算全库、未运行付费调用。独立夹具的虚构 expected 文件仅在 `code_review/evaluate_k_independent_fixture/`。

## 结论

R 控制版通过最终复算，开发门槛确实未通过；停止 R，不开启新保留实验，与冻结协议相符。K 的 7 次开发失败会计入分母，实际两阶段各 12 查询、4 个故事组三元组、24 个臂记录完整；但 `evaluate_k.py` 的输入完整性检查有一项 Important，最终评价前应修复。引用语义和正在产生的保留审查不在本轮通过范围。

## R 复算证据

- 1200 条 cached scores 全部绑定原 accepted 的 pair、请求 body SHA、reservation、原响应正文与 validator；来源为 K 1183 条、旧 R 17 条，无新 API。
- 独立按 `(-score, unit_id)` 排序并按 file_id 留首条，12 个查询排名与实际输出逐字段全等，每查询 100 个候选，前 20 文书唯一。
- 245 条共享盲参考唯一且恰好等于 R0/R1 Top20 并集。原 K effective 240 条逐字典保留，新增 5 条与 R 原 blind jobs、accepted、source paragraphs 和 evidence spans 对应；没有缺标补零。
- 独立公式重算 96 条逐查询/K 指标和全部汇总，与实际产物相等（浮点容差 1e-12）。

| 指标 | R0 | R1 |
|---|---:|---:|
| Top1 正确数 | 7/12 | 7/12 |
| P@5 | 0.500000 | 0.500000 |
| MRR@20 | 0.669444 | 0.655556 |
| pool NDCG@20 | 0.929591 | 0.934506 |

Top1 无新增、MRR 未增 0.03，故开发数值门槛为 false；默认表示未启用，`new_holdout_required=false`。仍须保留“模型银标、pool 指标、前轮 10 条等级上调”的解释与敏感性限制。

旧 R 的 18 笔新评分均仍有 reserve/settle 账本记录；未用于控制版的 `KO_cf588290636d5f7beca64912`、reservation `18e81fe1be52491f80cba93295dc156e` 仍记费用 **$0.000223476**，未因弃用而冲销。

## Important：K 评估允许缺行后缩小冻结分母

位置：`evaluate_k.py:16-22,47-52,61-65`。

`calculate()` 直接遍历 judgment_map，再用实际行数作为分母，没有校验该 split 必须覆盖冻结的 12 查询 × K0/K1、每对唯一、四组三元组。盲审只检查 reviews ID 集合与 blindmap 的值集合相同，不能证明每个 judgment_map 均有唯一对应审查。

独立有效小夹具先验证完整 12×2 时开发 3+4 格式失败分别记为 9/12、8/12，随后删除保留集同一 qid 的两臂 map 及相应盲审映射/审查。现代码仍返回两臂 `queries=11`、`state_accuracy=1.0`、`holdout_trial_gate.passed=true`。这会让缺少冻结查询被当成更小的成功试验，而非拒绝或冻结分母中的失败。

最小修复：计算前核验 map 行数与唯一键、pair_id 唯一；`(query_id,arm)` 集合严格等于冻结 split 的查询集合 × `{K0,K1}`；split 为 12 查询、4 组且每组 3 条；blindmap 的 pair_id 与 map 完全等集、decision_id 唯一，reviews 同样无重复并完全匹配。缺少 accepted 仍按当前实现计为格式失败。新增缺行、重复、错 split、缺盲审的拒绝测试。

该缺陷不表示当前实际 maps 缺行：本轮已独立确认 development/holdout 均完整 24 条，开发 accepted=17、缺失=7。它阻断的是现评估器的完整性保证及最终门槛放行。

## 复现与版本

运行 `code_review/final_control_metrics_audit.py` 已退出 0，证据见 `code_review/final_control_metrics_audit.json`。该脚本没有打开实际私有 expected，也没有运行实际 K 最终评估。

- `evaluate_k.py` SHA256：`fe8faec002636d09e77ef646a8dfb4e539200b30ee0511de7f760e0eee1328d5`
- `finalize_r_control.py` SHA256：`76ff8a407af4ea66f1e48510f6103359836a5d6a26a7c80370fa2620759e280e`
- 控制版 `metrics.json` SHA256：`bc7a209e17b5aa69366486c8b1a9486d3bd09326ad26fb7e1f929d016b0f6d58`
