# 付费执行护栏定向审查

日期：2026-10-18。身份：独立助手审查，`review_origin=current_session_model`，`human_approved=false`。

结论：最新修复版护栏及当前 `K_development_rerank` 的1200个已准备任务通过，无剩余实质阻断。可按用户本轮既有总额2美元授权执行该批次；这不是新增预算授权，也不覆盖后续尚未审查的 T06/R 数据或其他新请求批次。审查者未读取真实密钥，未调用网络或收费 API。

## 最初发现与关闭

初版存在两项阻断：授权计划 SHA/唯一任务上限没有执行，以及 attempt/unknown 仅按 phase 管理。主代理在首次付费调用前修复；本次结论针对修复后的版本。

- `run()` 在凭据读取前验证当前 scope/model/金额/用户授权引用，核对实际请求计划 SHA 与授权 `request_plan_sha256`，核对三类唯一任务上限及最多3次尝试，再验证冻结输入和当前 job 文件。
- 全 scope 聚合各 phase 的 records；按 `(pair_id, base_payload_sha256)` 累计尝试、unknown 和 accepted cache。换 phase 不重置尝试次数，不自动重发其他 phase 的不确定结果；同一身份第二个 paid accepted 被拒绝。
- 三类任务分别严格核对授权唯一数量上限；当前批次及已记录任务一起计数后才读取凭据。

## 实际核验

| 项目 | 结果 |
|---|---|
| 正式护栏测试 | 独立执行 `python -S -X utf8 -B -m unittest discover -s tests -p test_api_guard.py -v`，5项通过，0.212秒，退出码0；这些测试不运行网络。 |
| 跨 phase 状态 | 另用纯函数历史记录核验：unknown 拒绝；已有3次 rejected 拒绝；rerank/judgment/relevance 各自0上限样本均拒绝。 |
| exact cache | 相同 pair/body 返回已接受缓存；改变协议正文后不复用原缓存；不按评分高低选择重跑。 |
| 当前授权 | scope为本轮，模型deepseek-flash，总硬上限2美元；授权计划 SHA 与实际请求计划一致；上限6000 rerank、84 judgment、1200 relevance，最多3次。 |
| 当前准备批次 | 1200个唯一 pair，freeze.tasks=1200，job文件 SHA与冻结表完全一致。逐条 body/packet/job pair一致、query/unit原文一致，两个文本 SHA重算一致。query_freeze 的7个路径重算SHA全等；实际 queries SHA匹配授权计划，全部1200条话术都属于冻结 queries。 |
| 输入泄漏 | 当前 body 用户消息只含 pair_id/query_text/unit_text；packet只另含对应文本SHA。1200条均通过参考字段拒绝检查，消息角色为system/user。未读取私有参考答案内容；未把其字段装入请求。 |
| 费用预留 | 每次 dispatch 前在共享锁内预留最坏费用并 fsync；超过剩余额度不发送。未知费用保留全部预留；明确未发送HTTP body才按0结算；已知 usage按冻结计划的峰值费率记账，真实账单仍标未确认。 |
| 失败和中断 | 发送结果无法确认时保留unknown；未结算历史reservation阻止继续。原始结果/错误先持久化，再结算；格式/传输失败最多3次，最早合格结果即返回。 |
| 凭据及传输 | 凭据访问位于授权、冻结、全scope历史和缓存检查之后；密钥不进入请求记录，错误/返回文本做脱敏；TLS使用默认验证上下文。未在本次审查执行该凭据读取或请求函数。 |
| 尚未付费 | 审查时 `OUT/api` 执行文件数为0。 |

## 固定审查指纹

- `api_jobs.py` SHA256：`88542bfe919e6b88140591e6d417dc8310c3205c5d1a1c4afa60576257a41c25`。
- `api_jobs/K_development_rerank.jsonl` SHA256：`013ce93e47cfb9eaaf051c9ed89abf84cd58cd434712f17ec3ccb525545225fc`。
- `authorization.json` SHA256：`fcd040db274cc5b4783d4bfdfdd0afe248ee7ceba0556a7a3b6898d00a10a4c3`。

本轮只审查执行护栏和这批已准备输入；`experiment_k.py`、后续实验组装及实验结果须另审，不以护栏通过代替数据/实验验收。
