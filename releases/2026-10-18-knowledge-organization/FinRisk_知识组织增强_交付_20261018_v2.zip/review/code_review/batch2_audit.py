"""Review-only checks for real cards, literal spans, navigation and facade."""
import copy
import json
import shutil
import sys
from pathlib import Path

REVIEW = Path(__file__).resolve().parent
WORK = REVIEW.parent
sys.path.insert(0, str(WORK))
from common import OUT, P0OLD, read, rows, sha, textsha, canonical_sha
from knowledge_facade import KnowledgeFacade, pack_whole
from navigation import build_navigation

PIN = 'db408b8b99bde56dab6c1ead90432ba9b2cab2564aa20051537b78fcfd2fa940'


def must(value, message):
    if not value:
        raise AssertionError(message)


def main():
    report = {'review_origin': 'current_session_model', 'human_approved': False}
    report['code_sha256'] = {n: sha(WORK / n) for n in ['build_cards.py', 'mechanism_cards.py', 'navigation.py', 'knowledge_facade.py']}
    must(sha(OUT / 'contracts/knowledge_manifest.json') == PIN, 'knowledge pin changed before review')
    manifest = read(OUT / 'contracts/knowledge_manifest.json')
    for name, meta in manifest['files'].items():
        must(sha(OUT / name) == meta['sha256'] and (OUT / name).stat().st_size == meta['bytes'], 'knowledge payload changed: ' + name)
    disk = {p.relative_to(OUT).as_posix() for folder in ['knowledge', 'navigation'] for p in (OUT / folder).rglob('*') if p.is_file()}
    must(disk == set(manifest['files']), 'knowledge/nav manifest omitted or added payload')
    report['pinned_enhancement_payloads'] = len(manifest['files'])
    lock = read(OUT / 'case_reader/pilot_lock.json')
    f = KnowledgeFacade(OUT, lock, expected_knowledge_manifest_sha256=PIN)
    selected = list(rows(WORK / 'source_analysis/selected_cases.jsonl'))
    must(sha(WORK / 'source_analysis/selected_cases.jsonl') == '1524ab9f0d4cc71d2a884e1e78551493e09f61a7c0cf444e0f7d7b6a7cef67b8', 'selection source changed')
    sources = {s['file_id']: s for s in rows(OUT / 'knowledge/source_documents.jsonl')}
    must(len(sources) == len(selected) == 48, 'source document count differs')
    for record in selected:
        source = sources[record['file_id']]
        must(source['source_sha256'] == record['source_sha256'] and textsha(source['full_text']) == record['text_sha256'], 'source provenance mismatch')
        must(source['full_text'] == f.cases.sources[record['file_id']]['full_text'], 'pilot source text differs')
    for sid, span in f.spans.items():
        source = sources[span['file_id']]
        must(source['full_text'][span['start']:span['end']] == span['text'] and textsha(span['text']) == span['text_sha256'], 'literal span mismatch')
        must(source['source_sha256'] == span['source_sha256'], 'span source identity differs')
        must(span['current_business_fact_proof'] is False and span['human_approved'] is False, 'span proof identity changed')
    for link in f.links:
        span = f.spans[link['span_id']]
        must(link['file_id'] == span['file_id'] and link['actor_role'] == span['actor_role'] and link['attribution_limit'] == span['attribution_limit'], 'link changed actor attribution')
        if link['unit_id'] is None:
            must(not link['candidate_associations'] and link['binding_status'] == 'source_span_only_no_matching_unit', 'source-only link fabricated association')
        else:
            unit = f.cases.units[link['unit_id']]
            must(unit['file_id'] == link['file_id'], 'case link crosses source')
            must(any(p['start'] < span['end'] and span['start'] < p['end'] for p in unit['source_spans']), 'linked quote has no source-span overlap')
            for association in link['candidate_associations']:
                must(any(all(actual.get(k) == v for k, v in association.items()) for actual in unit['associations']), 'link forged candidate association')
    all_links = [l for c in f.cards.values() for l in c['supporting_case_links'] + c['adjacent_case_links']]
    must(sorted(map(canonical_sha, all_links)) == sorted(map(canonical_sha, f.links)), 'card links differ from canonical case links')
    original_units = {u['unit_id'] for u in rows(P0OLD / 'reader/bundle/units.jsonl')}
    linked_units = {l['unit_id'] for l in f.links if l['unit_id']}
    must(set(f.cases.units) == original_units | linked_units, 'pilot unit set differs from actual original-plus-selected union')
    for uid in f.cases.units:
        f.read_case(uid)
    source_only = [l for l in f.links if l['unit_id'] is None]
    must(len(source_only) == 8, 'source-only count differs')
    for link in source_only:
        got = {s['span_id']: s for s in f.read_mechanism(link['mechanism_id'], 'L2')['case_evidence']}
        must(got[link['span_id']] == f.spans[link['span_id']], 'source-only span unreadable')
    report['data'] = {'source_documents': len(sources), 'event_groups': len({r['event_group_id'] for r in selected}),
                      'spans': len(f.spans), 'case_links': len(f.links), 'linked_units': len(linked_units),
                      'source_only_spans_read': len(source_only), 'pilot_units_read': len(f.cases.units),
                      'pilot_documents': len(f.cases.sources), 'literal_and_candidate_association_checks': 'passed'}
    expected_nav = build_navigation(list(f.cards.values()), set(f.legal.articles), set(f.cases.units), set(f.spans))
    must(expected_nav == f.navigation, 'navigation differs from real registered links')
    for entry in f.navigation['mechanisms']:
        must((OUT / 'navigation' / entry['L0']).is_file() and (OUT / 'navigation' / entry['L1']).is_file(), 'navigation target file missing')
    report['navigation'] = {'same_table_rebuild_equal': True, 'link_targets': len(f.navigation['reverse_links']),
                            'pending_mechanisms': f.navigation['pending_mechanism_ids'], 'hard_filter': f.navigation['hard_filter']}
    m11 = f.cards['M11']
    must(next(p for p in m11['predicates'] if p['predicate_id'] == 'M11.personal_record_falsified')['required_for_risk'] is False, 'M11 added falsification prerequisite')
    must(all(p['support_kind'] == 'assistant_interpretation_of_registered_articles' for p in f.cards['M01']['predicates']), 'M01 interpretation identity missing')
    m02 = next(p for p in f.cards['M02']['predicates'] if p['predicate_id'] == 'M02.impersonation')
    must(m02['support_article_ids'] == ['L002-A0035'] and m02['context_article_ids'] == ['L005-A0016'], 'M02 background treated as direct support')
    must('unknown' in f.cards['M04']['scope_axes']['exception'], 'M04 unknown lost')
    report['mechanism_boundaries'] = 'M11 optional fact / M01 interpretation / M02 context-only / M04 unknown preserved'
    uid = next(iter(f.cases.units))
    for total, cb, lb in [(8000, 4000, 4000), (120, 20, 100), (8000, 1, 7999)]:
        bundle = f.get_evidence_bundle(['M11', 'M01', 'M02', 'M04'], [uid], budget_chars=total, case_budget=cb, law_budget=lb)
        must(len(bundle['case_text']) <= cb and len(bundle['law_and_guide_text']) <= lb, 'bundle budget exceeded')
        must(set(bundle['included_case_unit_ids']) <= {uid}, 'bundle added card-linked case')
        must(bundle['current_input_facts_assessed'] is False and all(p['status'] == 'not_assessed' for p in bundle['facts_to_check']), 'bundle assessed current input')
        must(bundle['coverage']['status'] == 'partial', 'omitted items not reported partial')
        for aid in bundle['included_legal_and_guide_ids']:
            if not aid.startswith('GUIDE:'):
                must(f.legal.articles[aid]['text'] in bundle['law_and_guide_text'], 'legal article cut mid-unit')
    for mid in f.cards:
        must(f.coverage(mid)['normative_applicability']['status'] == 'not_assessed_for_current_input', 'coverage assessed facts')
    report['bundle'] = {'three_budget_scenarios': 'passed', 'whole_legal_texts_preserved': True,
                       'fixed_case_not_expanded': True, 'six_contract_methods_exist': all(callable(getattr(f, n, None)) for n in
                           ['list_mechanisms', 'read_mechanism', 'read_article', 'read_case', 'get_evidence_bundle', 'coverage'])}

    # A separately pinned valid case bundle must still match the enhancement's base versions.
    isolated = REVIEW / 'batch2_cross_version_fixture'
    isolated.mkdir(exist_ok=False)
    for folder in ['knowledge', 'navigation', 'contracts', 'legal']:
        shutil.copytree(OUT / folder, isolated / folder)
    alternative = isolated / 'case_reader/alternative'
    shutil.copytree(REVIEW / 'snapshot_audit/case_reader/full_corpus_single_unit', alternative)
    alternative_manifest = read(alternative / 'manifest.json')
    alternative_manifest['versions']['content'] = 'review-different-content-version'
    alternative_manifest.pop('scope_subdir', None)
    (alternative / 'manifest.json').write_text(json.dumps(alternative_manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    different_lock = {'bundle': 'case_reader/alternative', 'versions': alternative_manifest['versions'],
                      'manifest_sha256': sha(alternative / 'manifest.json')}
    try:
        unexpected = KnowledgeFacade(isolated, different_lock, expected_knowledge_manifest_sha256=PIN)
    except ValueError as exc:
        report['cross_version_fixture'] = {'rejected': True, 'message': str(exc)}
    else:
        report['cross_version_fixture'] = {'rejected': False, 'enhancement_base_content': manifest['base_versions']['content'],
                                           'accepted_case_content': unexpected.cases.versions['content']}
    must(report['code_sha256'] == {n: sha(WORK / n) for n in report['code_sha256']}, 'production code changed during review')
    (REVIEW / 'batch2_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
