# 知识组织增量维护手动步骤

本轮 T09 交付依赖登记、变化影响和暂存输入验证。当前记录属于 T07 前准备，不是已发布版本；未运行 BM25、embedding 或前缀生成，不切换默认读取路径，不创建计划任务。正式封存应在 T07 完成后重新核对输入指纹。

## 实际覆盖与文件

`maintenance/dependencies.jsonl` 登记 3950 个节点、104 个已有载荷，实际范围为 67 条法规、48 份案例全文、62 个原句片段、398 个 pilot 来源、591 个 pilot 单元及 M11/M01/M02/M04 四张卡。每个输入保留文件原始 SHA256 和字段投影 SHA256；依赖节点还保存直接依赖输入的摘要。

`maintenance/coverage.json` 保存逐文件指纹、节点类别计数及完整 pending 队列。其余 8 机制、全库 9639 文书的知识组织审核、官方 27 标签的完整边界、历史适用确认及 T08 实际计算没有被本轮覆盖。覆盖这些目录不等于审核全部业务事实。

`maintenance/simulation_report.json` 和 `maintenance/scenarios/` 保存真实副本上的变化结果；对应副本及暂存回执位于 WORK 下的 `maintenance_task/s/`。模拟文本带“仅副本变更模拟”标记，不能作为新增法规或案例事实使用。

## 1. 冻结候选版本

先完成 T07 的代表性案例和已知失败例回归，确认候选读取包及五项旧版本保护不变。保存法规、卡片、导航、原句、检索文本、模型与索引配置的指纹。当前 `maintenance/coverage.json` 中的输入指纹只证明本次登记时的状态；T07 后如有变化，须建立新的维护登记目录，不覆盖这份记录。

在 WORK 的新目录复制候选载荷后操作，不直接修改冻结输入。保留旧版本全文、时间范围、产品、主体、地域与业务环节；新规则或新解释另建版本，不能用“保留最新”抹掉历史依据。

## 2. 检查变化影响

先指定真实候选副本的绝对路径。以下命令只读取候选，输出影响清单；主程序的相应子命令可转交此模块。

```powershell
$kbPy = 'C:/Users/11051/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$kbWork = 'C:/Users/11051/Documents/Codex/2026-10-09/c-users-11051-desktop-agent-ai/work/finrisk_knowledge_organization_v1_20261018'
$kbOut = 'C:/Users/11051/Documents/Codex/2026-10-09/c-users-11051-desktop-agent-ai/outputs/FinRisk_知识组织增强_v1_20261018'
$candidateRoot = "$kbWork/maintenance_task/s/a/in"
& $kbPy -S -X utf8 -B "$kbWork/dependency_build.py" impact --graph "$kbOut/maintenance/dependencies.jsonl" --root "$candidateRoot"
```

检查 `changed`、`direct_affected`、`affected`、`pending_nodes`、`observation_errors`。闭包包含变化节点本身；顺序满足先依赖后产物。循环、重复节点、缺失依赖和错误输入指纹会被拒绝。

条文正文或原始证据快照变化会传播到对应条文、关联卡片、导航及未来前缀。片段正文变化会传播到对应单元的检索表示、BM25 和 embedding。来源效力、版本及范围元数据变化会触发阅读状态和卡片复核，不会仅因文件字节变化而重新编码向量。`physical_file_changed_but_projection_unchanged` 是同文件其他字段/记录变化的审计信息，不等于检索文本变化。

## 3. 暂存受影响输入

`--stage` 必须是一个从未存在的新目录。已存在目录会被拒绝，失败后换新的目录重试，保留失败证据。

```powershell
$stageRoot = "$kbWork/maintenance_task/manual_stage_001"
& $kbPy -S -X utf8 -B "$kbWork/dependency_build.py" rebuild-affected --graph "$kbOut/maintenance/dependencies.jsonl" --root "$candidateRoot" --stage "$stageRoot"
```

默认只将现有输入的字段投影写入暂存区，`stage_kind=input_projection_only`。这不是重新提取原句、重写卡片、重建索引或生成向量。缺少重建器的产物保持 pending；BM25、embedding、contextual embedding 在当前模块中始终保持 pending，普通回调的“成功”对象不能冒充真实编码结果。

检查 `receipt.json` 中的构建失败、待处理节点、逐文件输入前后指纹及实际输出 SHA。失败结果为 `failed`，未完成结果为 `pending`，即使无变化或所有暂存完成，本模块也始终返回 `activation_allowed=false`，保留 T07/正式发布门禁。

## 4. 完成真实重建和回归

按影响顺序另行完成正文与原句回源、坐标和哈希验证、法规效力及冲突限定复核，再生成对应卡片与阅读产物。仅更正元数据时重做读取/范围检查，保留未变化的检索文本与向量；实际索引输入变化时，必须在已核验检索运行时重新生成 BM25/向量，并记录输入文本 SHA、模型与配置、输出 SHA 和回归结果。当前任务没有执行这些计算，不能将 pending 手工改为成功。

复核 L007 的待核效力、L011/L012 隔离、原件数量 0 及全部生产禁用标记。历史案例与当前业务判断分别记录；当前业务事实没有被案例存在或法规文本自动证明。

发布前复跑四机制代表性案例、原有已知失败例及读取拒绝测试；确认受影响的法规/覆盖层、卡片、导航、BM25 和向量属于同一候选版本。只有实际重建、审查、回归及发布条件都完成后，才交由独立的发布流程处理。本模块没有激活接口。

## 5. 回滚

保留上个完整候选包。回滚时同时选择该版本的法规注册、覆盖层、卡片、导航、检索文本、BM25、向量及其运行时指纹；核验读取清单和代表性案例后再切换。不能只回滚卡片而继续使用新索引，也不能在旧包内原位覆盖文件。

## 接口与复现

- `DependencyGraph.snapshot(root, specs)`：生成带输入 SHA 的登记；`DependencyGraph(nodes)`：拒绝不完整依赖及循环。
- `verify_inputs(root)`：严格核对基线文件与投影 SHA；`closure(changed)`：计算有序传递影响；`impact(root)`：比较候选并导出影响。
- `rebuild_affected(graph, root, stage, builders=None)`：仅暂存，记录失败与 pending，永不激活。
- `maintenance_task/register.py` 的 `register(root)` 返回图和覆盖清单；首次脚本运行使用排他创建输出，后续应保存到新版本目录。
- `maintenance_task/simulate.py` 重现条文、片段、效力元数据、无关文件及受控失败五个场景；它要求新的副本目录，不能覆盖既有证据。

验证命令：`python -S -X utf8 -B -m unittest discover -s tests -p test_dependency_build.py -v`。本轮审查来源为助手，`review_origin=current_session_model`，`human_approved=false`。
