# FinRisk 知识组织增强交付

先阅读 [验收报告](验收报告.md)。新增12张机制卡、67条法规读取与分层导航可选使用；K／R实验均未通过默认采用门槛，原检索配置继续保留。

## 快速复核

将压缩包解压到新目录，安装Python 3.11或以上即可运行标准库复核。以PowerShell为例，把路径替换为实际解压目录：

```powershell
$kbRelease = 'C:/路径/FinRisk_知识组织增强_交付_20261018'
python -S -X utf8 -B "$kbRelease/code/cli.py" verify --root "$kbRelease"
python -S -X utf8 -B "$kbRelease/code/cli.py" bundle-check --root "$kbRelease" --profile expanded --mechanisms M11 M02
python -S -X utf8 -B "$kbRelease/code/cli.py" impact --root "$kbRelease"
```

`verify`检查完整载荷清单，读取67条法规、12机制、732单元，回放旧960位置，并复算已保存K／R结果、参考敏感性、阶段覆盖、预算和维护基线。返回 `API_calls=0`。它复核保存的实际结果，不重新编码全库、调用模型或测全库真实Recall。

`bundle-check`不传案例ID时只组装指定机制的知识资料，不自动加入卡片例子。需要历史案例时传 `--unit-ids`，ID来自真实排名的Top20或读取快照。字符预算不足会保留整块、列出省略项并返回partial。

## 读取接口

```python
from pathlib import Path
from common import read
from kb_facade import KnowledgeFacade

root = Path('实际解压目录')
case_lock = read(root / 'case_reader/final_lock.json')
pin = read(root / 'expanded/contracts/knowledge_lock.json')['manifest_sha256']
kb = KnowledgeFacade(root, case_lock,
    expected_knowledge_manifest_sha256=pin, profile='expanded')
overview = kb.list_mechanisms()
card = kb.read_mechanism('M11', level='L2')
article = kb.read_article('L002-A0029', include_dependencies=True)
```

运行自己的脚本时把 `code/` 加入Python模块路径。版本和预算合同见 [read_api.md](contracts/read_api.md)。可选pilot为4卡，expanded为12卡；实验K冻结在pilot，不用expanded事后替换实验输入。

## 文件入口

| 路径 | 内容 |
|---|---|
| `expanded/knowledge/`、`expanded/navigation/` | 12机制资料、来源与覆盖台账 |
| `legal/` | 67条法规、来源身份、快照、阅读依赖 |
| `case_reader/final/` | 732单元／481文书便携验收快照，非全库服务索引 |
| `experiment_K/` | K排名、判断映射、冻结、盲参考、48行结果及指标 |
| `experiment_R_controlled/` | 正式R对照，原查询向量复用、缓存绑定、排名和指标 |
| `experiment_R/` | 早期R结果与245对共享参考，保留过程证据 |
| `api_jobs/`、`api/` | 实际请求正文、响应、失败记录与预算账本，不含密钥 |
| `semantic_review/`、`private_reference/` | 匿名语义审核输入／结果与模型银标参考；推理请求不含参考 |
| `reports/`、`review/` | 敏感性、费用、回放、独立助手审核和实施记录 |
| `maintenance_final/` | 最新4313节点依赖登记、影响与副本验证 |
| `code/`、`manifest.json` | 实际源码与全部载荷SHA清单 |

## 维护与复现实验的边界

`cli.py`提供 `status`、`verify`、`evaluate`、`cards`、`legal`、`navigation`、`bundle-check`、`impact`、`rebuild-affected`、`freeze`、`open-holdout`、`package`。已结束的实验只读重放；`open-holdout`返回既有开启回执，不重开保留集。`freeze`仅在原工作区检查146个外部原始输入，便携包使用 `verify`。

变更实验须在副本上进行；`rebuild-affected --stage`要求一个尚不存在的相邻目录，暂存受影响输入投影，未实现的计算保留pending，不自动发布。详见 [最终维护说明](reports/update_runbook_final.md)。

完整生成代码也保留在 `code/`，其中原检索／构建／API脚本依赖原工作区、9639全文／候选／索引、既有BGE运行时及向量缓存；便携包不包含这些大型资产。不得把源码存在表述为解压后可重新生成整个全库。新增付费实验需要新输入冻结及相应授权，不能沿用本轮已结束的额度许可。

源码测试记录在 `reports/`；多数契约测试只需标准库，涉及原工作区资产的测试应在原工作区运行。解压后的正式验收入口是 `cli.py verify`，不需访问原路径或密钥。

## 采用与回滚

默认检索继续为BM25＋BGE、RRF等权1:1、deepseek-flash重排。新增分层资料可供另一窗口Agent按需接入，本轮没有修改Agent工具调用策略或验证在线闭环。

停用新增读取层即可回到原默认。修改资料后应新建版本并重做清单、来源与代表性回归，不在已封存目录中直接覆盖文件。本轮没有上传GitHub。
