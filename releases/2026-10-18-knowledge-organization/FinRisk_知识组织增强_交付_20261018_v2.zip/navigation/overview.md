# 风险机制导航

按机制阅读概览，再按登记ID读取法规和案例原句。机制只是候选，不是当前输入事实。

- [M11 销售代替当事人确认订立合同文书](mechanisms/M11/overview.md)
- [M01 指导本人作不实回访答复](mechanisms/M01/overview.md)
- [M02 非本人冒名完成回访](mechanisms/M02/overview.md)
- [M04 合同外成交利益](mechanisms/M04/overview.md)
